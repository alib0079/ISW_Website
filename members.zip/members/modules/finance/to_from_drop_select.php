

<?

$to_from = $db_object->query("SELECT  * FROM finance_to_from WHERE `account_id` =$_SESSION[account_id] ");

	if (DB::isError($to_from)) {
		echo"I can't get the to_from";
	}

$numRows  = $to_from->numRows();
if($numRows > 0){
?>
<select name="to_from_user_id">

<option value="" >Select To/From </option>

<option value="" ></option>
<?
for($i=0;$i<$numRows;$i++){
	$_to_from= $to_from->fetchRow();




$users = $db_object->query("SELECT  * FROM users WHERE `id` =$_to_from[user_id]");

	if (DB::isError($users)) {
		echo"I can't get the user info";
	}


	$_users= $users->fetchRow();

echo "<option value=\"$_users[id]\">$_users[firstname] $_users[lastname]</option>";




}

?>
</select>

<?}?>

