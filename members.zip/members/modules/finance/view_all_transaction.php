<?
if ($logged_in !== 1) { exit;}
 
if($finance_tablename){

 ?>


<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1">
  <tr>
    <td width="12%" align="center"><font color="#000080"><b>Reference#</b></font></td>
    <td width="38%" align="center"><font color="#000080"><b>Description</b></font></td>
    <td width="25%" align="center"><font color="#000080"><b>Amount</b></font></td>
    <td width="25%" align="center"><font color="#000080"><b>Balance</b></font></td>
  </tr>

<?



$Where_string = "WHERE  `date` >= '$Qperiod' " ;



$selectbalance = $db_object->query("SELECT  * FROM $finance_tablename  $Where_string ORDER BY `time` DESC LIMIT 0 , 30 ");

	if (DB::isError($selectbalance)) {
		echo"I can't get the balance please contact the webmaster";
	}

$numRows  = $selectbalance->numRows();


for($i=0;$i<$numRows;$i++){
 
	$_row= $selectbalance->fetchRow();
$reference = $_row['reference'];
$description = $_row['description']; 
$to_from_user_id = $_row['to_from_user_id']; if($to_from_user_id !== 0 ){  $users = $db_object->query("SELECT  * FROM users WHERE `id` =$to_from_user_id "); if (DB::isError($users)) {echo"I can't get the user info";} }
$_users= $users->fetchRow();
$to_from_name="$_users[firstname] $_users[lastname]";
$amount=  $_row['amount'];     
$balance = $_row['balance'];
$date = $_row['date'];
?>

<tr>
    <td width="12%" align="center"><font color="#000080"><? echo "$reference";?></font></td>
    <td width="38%" align="center"><font color="#000080"><? echo "$description <br>"; if($to_from_user_id > 0 ){  if($amount < 0){echo"<b>to</b>";}if($amount > 0 ){echo"<b>From</b>";} echo" $to_from_name"; }?></font></td>
    <td width="25%" align="center"><font color="#000080"><? echo "$amount";?></font></td>
    <td width="25%" align="center"><font color="#000080"><? if($i==0){echo "<b> Current balance: ";}echo "$balance";?></font></td>
  </tr>



<?}?>
</table>
<?}else{echo "<br><br><b>Please Select an account</b>";} ?>