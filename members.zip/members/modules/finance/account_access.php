<?
if ($logged_in !== 1) { exit;} 

//configuration

$accounts_access_tablename='finance_accounts_access';
$accounts_tablename='finance_accounts';



// query the accounts table and see what we got for this user



$accounts_access = $db_object->query("SELECT  * FROM $accounts_access_tablename WHERE `user_id` ='$_SESSION[userid]' ");

	if (DB::isError($accounts_access)) {
		echo"I can't get the balance please contact the webmaster";
	}

$numRows  = $accounts_access->numRows();

?>


<form> 
<select name="account_id">
<option value="<? if($_GET[account_id]){ echo "$_GET[account_id]";}else{echo "$_SESSION[account_id]";}?>" > Select an Account </option>
<?
for($i=0;$i<$numRows;$i++){
$_accounts_access= $accounts_access->fetchRow();

$accounts_info = $db_object->query("SELECT  * FROM $accounts_tablename WHERE `account_id` ='$_accounts_access[account_id]' ");

	if (DB::isError($accounts_info)) {
		echo"I can't get the balance please contact the webmaster";
	}

$num  = $accounts_info->numRows();
for($j=0;$j<$num;$j++){

$_accounts_info= $accounts_info->fetchRow();



?>
<option value="<? echo "$_accounts_info[account_id]";?>" > <? echo "$_accounts_info[account_name]"; ?> </option>
<?}}?> 
</select> 
<input type=hidden name=content value=<? echo "$_GET[content]";?> >
<input type="submit" name="submit" value="go" > 
</form>
<?
if($_GET[account_id]){

$varifie_get = $db_object->query("SELECT  * FROM $accounts_access_tablename WHERE `user_id` ='$_SESSION[userid]' AND `account_id` ='$_GET[account_id]' LIMIT 1 ");

	if (DB::isError($varifie_get)) {
		echo"I can't get varifie get";
	
}
$_varifie_get= $varifie_get->fetchRow();

$_SESSION[account_access]="$_varifie_get[access_type]";





$oneaccount = $db_object->query("SELECT  * FROM $accounts_tablename WHERE `account_id` ='$_varifie_get[account_id]'  ");

	if (DB::isError($oneaccount)) {
		echo"I can't get the selected account";
	}

$_oneaccount= $oneaccount->fetchRow();

$_SESSION[account_name]="$_oneaccount[account_name]";

$_SESSION[account_table]="finance_$_oneaccount[account_id]";

$_SESSION[account_id]="$_oneaccount[account_id]";
}

$finance_tablename="$_SESSION[account_table]";


?>
