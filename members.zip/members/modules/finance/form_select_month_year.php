<center><form action="" style="padding: 0px; margin-top: 0pt;" target="_parent">
<select name="month">
<option value="<? if($_GET[month]){echo "$_GET[month]";}else{$month= date("m");  echo "$month";}?>">More History</option>
<option value="01">Jan</option>
<option value="02">Feb</option>
<option value="03">Mar</option>
<option value="04">Apr</option>
<option value="05">May</option>
<option value="06">Jun</option>
<option value="07">Jul</option>
<option value="08">Aug</option>
<option value="09">Sep</option>
<option value="10">Oct</option>
<option value="11">Nov</option>
<option value="12">Dec</option>
<option value="">- Year -</option>
</select>
<select class="aws_formfield" name="year">
<option value="2006">2006</option>
<option selected="true" value="2007">2007</option>
</select>
<input name="content" value="<?echo "$_GET[content]";?>" type="hidden">
<input name="period" value="new" type="hidden">
 <? if($_GET[action]){?><input name="action" value="<? echo "$_GET[action]";?>" type="hidden"><?}?>
<input value=" OK " type="submit">
</form>
</center>