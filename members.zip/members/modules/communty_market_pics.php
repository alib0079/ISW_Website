<?
echo "<b>Album Collection: </b>";
$path='../pics/community_market_pics';
$dh = opendir($path);
while (($file = readdir($dh)) !== false) {
if($file!== '.' AND $file!='..'){
   echo "<a href=\"?content=$_GET[content]&&content_title=$_GET[content_title]&cat=$_GET[cat]&cat_name=$_GET[cat_name]&album=$path/$file\" > [$file] </a> &nbsp;&nbsp; ";

}
}
closedir($dh);


if($_GET[album]){
?>

<br><br>
<iframe
 src="<? echo "$_GET[album]"; ?>" FRAMEBORDER="0"
  width="100%" height="800"  ></iframe>
<?}else{ echo "<br><br><b>Select an Album</b>";}?>