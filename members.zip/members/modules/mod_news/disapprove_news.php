<? 
if ($_POST[submit]){




$update = $db_object->query(" UPDATE `news` SET `approved` = '0' WHERE `sid` =$_GET[sid] LIMIT 1 ; ");

if (DB::isError($update)) {
		echo "I can not do update";
	}

echo "This News story  was disapproved";

}



if(!$_POST[submit] OR $error ){

?>
<form action="" method="POST">
<input name="submit" value="Confirm: Disapprove  Story id# <?echo "$_GET[sid]";?> " type="submit"> </td>
</form>
<?}?>