<table style="width: 100%; text-align: left;" border="1" cellpadding="2"
cellspacing="2">
<tbody>
<tr>
<td class="tabletop">Images
</td>

<td class="tabletop">News
</td>
<td class="tabletop">Author
</td>
<td class="tabletop">Contact
</td>
<td class="tabletop">Action
</td>
</tr>
<?
function stripslashes_deep($value)
{
   $value = is_array($value) ?
               array_map('stripslashes_deep', $value) :
               stripslashes($value);

   return $value;
}







$result = $db_object->query("SELECT  * FROM news WHERE `approved` =0 AND `archive`= 0 ");

	if (DB::isError($result)) {
		echo"I can't get main categories";
	}

$numRows  = $result->numRows();

if ($numRows > 0 ){

for($i=0;$i<$numRows;$i++){
	$_result= $result->fetchRow();

$_result = stripslashes_deep($_result);

?>
<tr>
<td style="vertical-align: top;"><a href="../?content=mod_news&sid=<? echo "$_result[sid]";?>">
<? if($_result[image]){?>
<img alt="Image Story" src="http://www.islamicsocietyofwichita.com/pics/news/<?echo "$_result[image]";?>" style="width: 100px;  border: 0px">
<?}else{echo "No Image Story";}?>
</a>
</td>
<td style="vertical-align: top;"> 
<a href="../?content=mod_news&sid=<? echo "$_result[sid]";?>"><? echo "<b>$_result[title]</b><br>$_result[brief]";?><a> <br>

</td>
<td style="vertical-align: top;"> <? echo "$_result[author]";?> <br>
</td>
<td style="vertical-align: top;"> <? echo "$_result[contact]";?> <br>
</td>
<td style="vertical-align: top;">
<a href="?content=mod_news&amp;action=approve_news&amp;sid=<? echo "$_result[sid]";?>&approve=1"> Approve</a>  <br><br>
<a href="?content=mod_news&amp;action=delete_news&amp;sid=<? echo "$_result[sid]";?>"> Delete</a>  <br>
</td>
</tr>

<?



}
}else{echo "</table>no news submitted<br>----------------------------------";}
?>
</tbody>
</table>
<br>
<br>
</body>
</html>