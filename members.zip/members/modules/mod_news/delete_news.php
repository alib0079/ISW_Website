<?
if($_POST[submit]){ 

$update = $db_object->query(" UPDATE `news` SET `archive`= '1' WHERE `sid` =$_POST[sid] LIMIT 1 ; ");

if (DB::isError($update)) {
		echo "I can not do update";
	}

echo "This news was archive";


}


if(!$_POST[submit]){
?>
<form action="" method="POST" >
<input type="hidden" value="<? echo "$_GET[sid]";?>" name="sid">
<input name="submit" value="Confirme deleting/archiving   News Story id # <? echo "$_GET[sid]";?>  " type="submit"> 
</form>
<?}?>