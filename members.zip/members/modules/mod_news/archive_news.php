<table style="width: 100%; text-align: left;" border="1" cellpadding="2"
cellspacing="2">
<tbody>
<tr>
<td class="tabletop">Images
</td>

<td class="tabletop">News
</td>
<td class="tabletop">Author
</td>
<td class="tabletop">Contact
</td>
<td class="tabletop">Action
</td>
</tr>
<?

$result = $db_object->query("SELECT  * FROM news WHERE `approved` =1 AND `archive`= 1 ORDER BY `created` ASC ");

	if (DB::isError($result)) {
		echo"I can't get main categories";
	}

$numRows  = $result->numRows();

if ($numRows > 0 ){

for($i=0;$i<$numRows;$i++){
	$_result= $result->fetchRow();

?>
<tr>
<td style="vertical-align: top;"><a href="../?content=mod_news&sid=<? echo "$_result[sid]";?>">
<? if($_result[image]){?>
<img alt="Image Story" src="http://www.islamicsocietyofwichita.com/pics/news/<?echo "$_result[image]";?>" style="width: 100px; border: 0px">
<?}else{echo "No Image Story";}?>
</a>
</td>
<td style="vertical-align: top;"> 
<a href="../?content=mod_news&sid=<? echo "$_result[sid]";?>"><? echo "<b>$_result[title]</b><br>$_result[brief]";?><a> <br>

</td>
<td style="vertical-align: top;"> <? echo "$_result[author]";?> <br>
</td>
<td style="vertical-align: top;"> <? echo "$_result[contact]";?> <br>
</td>
<td style="vertical-align: top;">
<a href="?content=mod_news&amp;action=disapprove_news&amp;sid=<? echo "$_result[sid]";?>&approve=0">Disapprove </a>  <br><br>
<a href="?content=mod_news&amp;action=delete_news&amp;sid=<? echo "$_result[sid]";?>"> Delete</a>  <br>
</td>
</tr>

<?



}
}else{echo "</table>no news <br>----------------------------------";}
?>
</tbody>
</table>
<br>
<br>
</body>
</html>