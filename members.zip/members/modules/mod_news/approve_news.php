<script language="JavaScript" src="./scripts/ts_picker.js">
</script>
<? 
if ($_POST[submit]){
if ($_POST[submit] AND $_POST[contact] AND $_POST[timestamp] AND $_POST[title] AND $_POST[brief] AND $_POST[story]){

//$_POST[contact]= addslashes($_POST[contact]);
//$_POST[title]=addslashes($_POST[title]);
//$_POST[story]= addslashes($_POST[story]);
//$_POST[story]=addslashes($_POST[story]);



$update = $db_object->query("
UPDATE `news` SET `author` = '$_POST[author]',
`contact` = '$_POST[contact]',
`title` = '$_POST[title]',
`brief` = '$_POST[brief]',
`story` = '$_POST[story]',
`modified` = CURRENT_TIMESTAMP,
`expiretion` = '$_POST[timestamp]',
`approved` = '1' WHERE `sid` =$_GET[sid] LIMIT 1 ; ");

if (DB::isError($update)) {
		echo "I can not do update";
	}

echo "This news story was added to the news page thanks";
}else{ echo "Missing required field";
unset($_POST[submit]);
}
}
// display news

if(!$_POST[submit] OR $error ){

$result = $db_object->query(" SELECT * FROM `news` WHERE `sid` =$_GET[sid] LIMIT 1 ");

if (DB::isError($result)) {
		echo "I can not do result";
	}

$_result= $result->fetchRow();


if ($error){echo "<b>You are Missing a Required Field</b>";}


$_POST[contact]= stripslashes($_POST[contact]);
$_POST[title]=stripslashes($_POST[title]);
$_POST[story]= stripslashes($_POST[story]);
$_POST[brief]=stripslashes($_POST[brief]);
$_POST[author]=stripslashes($_POST[author]);





?>


<form action="" method="POST" name="tstest">
<table style="width: 100%; text-align: left;" border="0" cellpadding="2"
cellspacing="2">
<tbody>
<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">News expiration date:*</span><br>
</td>
<td style="vertical-align: top;">

<input type="Text" name="timestamp" value="<? echo "$_POST[timestamp]"; ?>">
  <a href="javascript:show_calendar('document.tstest.timestamp', document.tstest.timestamp.value);"><img src="./scripts/cal.gif" width="16" height="16" border="0" alt="Click Here to Pick up the timestamp"></a> 
  <font size="1">Click here to open calendar </font> </td>
</tr>
<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Author's Contact:</span><br>
</td>
<td style="vertical-align: top;"><input size="32" value="<?if($_POST[contact]){echo "$_POST[contact]";}else{ echo "$_result[contact]"; }?>"
name="contact">
</td>
</tr>

<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Author's Name:*</span><br>
</td>
<td style="vertical-align: top;"><input size="32" value="<?if($_POST[author]){echo "$_POST[author]";}else{ echo "$_result[author]"; }?>"
name="author"></td>
</tr>
<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Story Title:*</span><br>
</td>
<td style="vertical-align: top;"><input size="32" value="<?if($_POST[title]){echo "$_POST[title]";}else{ echo "$_result[title]"; }?>"
name="title"></td>
</tr>
<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">News brief (no HTML Please) :*</span><br>
</td>
<td style="vertical-align: top;"><textarea maxlength="200"
rows="5" name="brief" cols="50">
<?if($_POST[brief]){echo "$_POST[brief]";}else{ echo "$_result[brief]";}?>
</textarea></td>
</tr>

<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">New or Story:*</span><br>
</td>
<td style="vertical-align: top;"><textarea maxlength="200"
rows="20" name="story" cols="50" id="news" >
<?if($_POST[story]){echo "$_POST[story]";}else{ echo "$_result[story]";}?>
</textarea>
<script language="javascript1.2">
  generate_wysiwyg('news');
</script>


</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: right;"><br>
</td>
<td style="vertical-align: top;"><input 
name="submit" value="Approve this News Story " type="submit"> </td>
</tr>
</tbody>
</table></form>
<?}?>