<?if($_GET[datatype]){?><a href="?content=<? echo "$_GET[content]"; ?>&datatype=audio&change_cat=true">Audio</a> | &nbsp;&nbsp;
<a href="?content=<? echo "$_GET[content]"; ?>&datatype=video&change_cat=true">Video</a> | &nbsp;&nbsp; 
<a href="?content=<? echo "$_GET[content]"; ?>&datatype=flash">Flash</a> | &nbsp;&nbsp;


<? 
//end links start display
if($_GET[index]){
$andstring1= "AND `index`=$_GET[index]";
}
if($_GET[language]){
$andstring2= "AND `language` LIKE '$_GET[language]'";

}
if($_GET[subject]){
$andstring3= "AND `subject` LIKE '$_GET[subject]'";

}

$result = $db_object->query(" SELECT * FROM `isw_library_data` WHERE `datatype` LIKE '$_GET[datatype]' $andstring1 $andstring2 $andstring3   LIMIT 30 ");

if (DB::isError($result)) {
		echo "I can not do result";
	}

$numRows  = $result->numRows();

if ($numRows > 0 ){

for($i=0;$i<$numRows;$i++){
	$_result= $result->fetchRow();

?>
<div style="text-align: left;">
<br>
<hr style="width: 100%; height: 1px;">

<? if($_result[image]){?>
<img alt="No Image"
src="http://www.islamicsocietyofwichita.com/pubinformation/pics/news/<? echo "$_result[image]";?>" align="left">
<?}?>
<h5 style="text-align: left;">
<a href="?content=<? echo "$_GET[content]"; ?>&datatype=<? echo "$_GET[datatype]";?>&index=<? echo "$_result[index]";?>"><? echo "$_result[title]";?></a>

</h5>
<? if($_GET[index]){

echo "<center>$_result[location]</center>";
}?>
<br>
<small> 
<b>By :</b> <? echo "$_result[author]";?> |
<b> Language :</b>
<a href="?content=<? echo "$_GET[content]"; ?>&datatype=<? echo "$_GET[datatype]";?>&language=<? echo "$_result[language]"; if($_GET[subject]){echo "&subject=$_GET[subject]";} ?>"><? echo "$_result[language]";?></a> | 

<b>Subject:</b>
 
<a href="?content=<? echo "$_GET[content]"; ?>&datatype=<? echo "$_GET[datatype]";?>&subject=<? echo "$_result[subject]"; if($_GET[language]){echo "&language=$_GET[language]";} ?>"><? echo "$_result[subject]";?></a> | 

</small>

<?
}}
?>
</div>
<hr style="width: 100%; height: 1px;">
<?}else{include("$_GET[content]/home.php");}?>