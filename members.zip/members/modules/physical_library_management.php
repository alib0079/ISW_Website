<table style="width: 100%; text-align: left;" border="0" cellspacing="2">
<tbody>
<tr>
<td class=tablelinks>
<a href="?content=<? echo "$_GET[content]"; ?>&action=view_materials&change_cat=true">View Materials</a> | &nbsp;&nbsp;
<a href="?content=<? echo "$_GET[content]"; ?>&action=add_content&change_cat=true">Add Materials</a> | &nbsp;&nbsp; 
<a href="?content=<? echo "$_GET[content]"; ?>&action=add_category">Add Category</a> | &nbsp;&nbsp;


</td>
</tr>
<tr>
<td><br></td>
</tr>

<tr>
<td style="vertical-align: top;">




<?

if($_GET[action]){@include("physical_library_management/$_GET[action].php");}else{@include("physical_library_management/home.php");}
?>

</td>
</tr>
</tbody>
</table>

