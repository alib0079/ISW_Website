<div style="text-align: left;"><b>Add Content: > </b></div><br>
<?
//change listing

if($_GET[change_cat]){
unset($_SESSION[id_category]);
}
//select category
if(!$_SESSION[id_category]){
include("add_content_select_category.php");

}

if($_SESSION[id_category]){

if(!$_POST[add_content]){
include("add_content_form.php");
}
if($_POST[add_content]=='Add Content'){

//check an query 
if($_POST[title]&&$_POST[author]&&$_POST[datatype]&&$_POST[language]&&$_POST[location]){

$insertdata = $db_object->query("  
INSERT INTO `isw_library_data` ( `index` , `datatype` , `language` , `cat_id` , `title` , `qt` , `subject` , `author` , `isbn` , `publisher` , `edition` , `location` , `publishdate` , `adddate` , `optionzero` )
VALUES (
NULL , '$_POST[datatype]', '$_POST[language]', '$_POST[id_category]', '$_POST[title]', '', '$_SESSION[id_category_name]', '$_POST[author]', NULL , NULL , NULL , '$_POST[location]' , NULL , NULL , '0'
)");

if (DB::isError($insertdata)) {
		echo"I can't add this data now";
	}else{ echo "listing succesful------------- OK <br>";}

$returen_id = mysql_insert_id();
echo "listing # $returen_id---------- OK<br>";


}else{
echo "All fields are required";

include("add_content_form.php");
}
//end check and query

}
}



