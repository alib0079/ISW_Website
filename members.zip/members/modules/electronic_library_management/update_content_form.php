<script language="javascript"><!--
function popupWindow(url) {
  window.open(url,'popupWindow','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=yes,copyhistory=no,width=500,height=300,screenX=150,screenY=150,top=150,left=150')
}
//--></script>
<form method="post">
<table
style="background-color: rgb(255, 255, 153); width: 100%; text-align: left;"
border="1" cellpadding="2" cellspacing="0">
<tbody>
<tr>
<td><b>ID #</b></td>
<td><b>Material Title</b></td>
<td><b>Author</b></td>
<td style="vertical-align: top;"><span
style="font-weight: bold;">Category</span><br>
</td>

</tr>
<tr>
</tr>
<tr>
<td><span style="font-weight: bold;"> </span><input
size="1" style="font-weight: bold;" readonly="readonly" name="id" value="<? echo "$_result1[index]"; ?>"><span
style="font-weight: bold;"> </span><br style="font-weight: bold;">
</td>
<td><span style="font-weight: bold;" > </span>
<input size="30" style="font-weight: bold;" name="title" value="<?echo "$_result1[title]";?>"> 
<span
style="font-weight: bold;"> </span><br style="font-weight: bold;">
</td>
<td><span style="font-weight: bold;"> </span> <input
size="30" style="font-weight: bold;" name="author" value="<?echo "$_result1[author]";?>"><span
style="font-weight: bold;"></span></td>
<td style="vertical-align: top;">

<? 
//needs index to work

include("update_content_select_category.php"); ?>

</td>


</tr>
<tr>
</tr>
<tr>
</tr>
</tbody>
</table>

<table
style="background-color: rgb(255, 255, 153); width: 100%; text-align: left;"
border="1" cellpadding="2" cellspacing="0">
<tbody>
<tr>
<td style="vertical-align: top;"><b>HTML Code OR Link : <small>(Make embed code: <a href="javascript:popupWindow('./modules/electronic_library_management/make_embed_code_mp3.php')">MP3 and RM</a>.)</small></b><br><br>



<textarea maxlength="200" rows="10" name="location" cols="40" > <? echo "$_result1[location]";?> </textarea>

</td>

<td style="vertical-align: top;"><b>Specification in this Category:</b><br><br>
<b>Content Data Type:</b><select  name="datatype" >
<option value="<? echo"$_result1[datatype]";?>" selected="selected"><? echo"$_result1[datatype]";?></option>
<option value="" ></option>
<option value="Audio" >Audio</option>
<option value="Video" >Video</option>
<option value="Flash" >Flash</option>
<option value="ebook" >ebook</option>
</select>
<br>
<br>
<b>Content Language:</b><select  name="language">
<option value="<?echo "$_result1[language]";?>" selected="selected"><?echo "$_result1[language]";?></option>
<option value="" ></option>
<option value="Arabic" >Arabic</option>
<option value="English" >English</option>
<option value="Spanish" >Spanish</option>
</select>

--------------------------------------------------------

</td>

</tr>
</tbody>
</table>
<br>











&nbsp; <input name="update_content" style="font-weight: bold;" value="Update Content" type="submit"></form>
<br>
