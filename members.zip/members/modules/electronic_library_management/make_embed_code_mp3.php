<b>Past MP3 or RM audio link here:</b><br>
<form method="post">
<input size="65"  name="link" value="<? echo "$_POST[link]"; ?>">
<input name="update_content" style="font-weight: bold;"
value="Make Embed Code" type="submit"></form>
<br>
<b>Copy Embeding Code:</b><br>
<? if($_POST[link]){?>
<textarea  rows="8"  cols="50">
&lt;embed src="<? echo "$_POST[link]";?>" type="audio/x-pn-realaudio-plugin"
console="155" name="155" controls="ControlPanel,StatusBar"
autostart="false" height="60" width="315"&gt;
</textarea>
<?}?>