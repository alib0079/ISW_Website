<script language="javascript"><!--
function popupWindow(url) {
  window.open(url,'popupWindow','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=yes,copyhistory=no,width=500,height=300,screenX=150,screenY=150,top=150,left=150')
}
//--></script>

<form method="post">
<table
style="background-color: rgb(255, 255, 153); width: 100%; text-align: left;"
border="1" cellpadding="2" cellspacing="0">
<tbody>
<tr>
<td><b>ID #</b></td>
<td><b>Content Title</b></td>
<td><b>Scholar</b></td>
<td style="vertical-align: top;"><span
style="font-weight: bold;">Category</span><br>
</td>
</tr>
<tr>
</tr>
<tr>
<td><span style="font-weight: bold;"> </span><input
size="1" style="font-weight: bold;" readonly="readonly" name="stock" value="<? echo "$_POST[stock]"; ?>"><span
style="font-weight: bold;"> </span><br style="font-weight: bold;">
</td>
<td><span style="font-weight: bold;" > </span><input
size="30" style="font-weight: bold;" name="title" value="<?echo "$_POST[title]";?>"> <span
style="font-weight: bold;"> </span><br style="font-weight: bold;">
</td>
<td><span style="font-weight: bold;"> </span> <input
size="30" style="font-weight: bold;" name="author" value="<?echo "$_POST[author]";?>"><span
style="font-weight: bold;"></span></td>
<td style="vertical-align: top;">
<input type=hidden size="10" style="font-weight: bold;" name="id_category" value="<?echo "$_SESSION[id_category]";?>">
<input size="10" style="font-weight: bold;" name="id_category_name" readonly="readonly" value="<?echo "$_SESSION[id_category_name]";?>"> 
<a href="?content=<?echo "$_GET[content]";?>&action=<? echo "$_GET[action]";?>&change_cat=true">Change</a>
</td>


</tr>
<tr>
</tr>
<tr>
</tr>
</tbody>
</table>

<table
style="background-color: rgb(255, 255, 153); width: 100%; text-align: left;"
border="1" cellpadding="2" cellspacing="0">
<tbody>
<tr>
<td style="vertical-align: top;"><b>HTML Code OR Link : <small>(Make embed code: <a href="javascript:popupWindow('./modules/electronic_library_management/make_embed_code_mp3.php')">MP3 and RM</a>.)</small></b><br><br>


<textarea maxlength="200" rows="10" name="location" cols="40" > <? echo "$_POST[location]";?></textarea>

</td>
<td style="vertical-align: top;"><b>Specification in this Category:</b><br><br>
<b>Content Data Type:</b><select  name="datatype"   >
<option value="" selected="selected">------------</option>
<option value="Audio" >Audio</option>
<option value="Video" >Video</option>
<option value="Flash" >Flash</option>
<option value="ebook" >ebook</option>
</select>
<br>
<br>
<b>Content Language:</b><select  name="language"   >
<option value="" selected="selected">------------</option>
<option value="arabic" >Arabic</option>
<option value="english" >english</option>
<option value="Spanish" >Spanish</option>
</select>
<? @include("add_special_fields_form.php");?>
--------------------------------------------------------

</td>

</tr>
</tbody>
</table>
<br>










&nbsp; <input name="add_content" style="font-weight: bold;" value="Add Content"
type="submit"></form>
<br>
