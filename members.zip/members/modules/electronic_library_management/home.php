<?
if($_POST[id_category]){
 
$maincat = $db_object->query("SELECT  cat_name FROM isw_library_categories WHERE cat_id= $_POST[id_category]; ");

	if (DB::isError($maincat)) {echo"I can't get  cat name";}
$_maincat= $maincat->fetchRow();

$cat_name =$_maincat[cat_name];
}
?>




<form method="post">
<b>Select a Category:</b> 
<select  name="id_category" >


<?
$maincat = $db_object->query("SELECT  * FROM isw_library_categories WHERE  cat_parent=0 AND cat_type='e'");

	if (DB::isError($selectbalance)) {
		echo"I can't get main categories";
	}
$numRows  = $maincat->numRows();

for($i=0;$i<$numRows;$i++){
	$_maincat= $maincat->fetchRow();

print "<option value=\"$_maincat[cat_id]\" selected=\"selected\" style=\"font-weight: bold;\"><b>$_maincat[cat_name]</b></option>";

$subcat = $db_object->query("SELECT  * FROM isw_library_categories WHERE  cat_parent=$_maincat[cat_id] ");

	if (DB::isError($subcat)) {
		echo"I can't get  categories";
	}
$num  = $subcat->numRows();
if($num > 0){
for($j=0;$j<$num;$j++){
	$_subcat= $subcat->fetchRow();

print "<option value=\"$_subcat[cat_id]\" selected=\"selected\"> -->$_subcat[cat_name] </option>";

}
}
}

?>

<option value="" selected="selected">--------------------</option>
<option value="<? echo  "$_POST[id_category]"; ?>" selected="selected"><? echo "$cat_name"; ?></option>
</select>
<b>Sort By:</b> 
<select  name="sortby" >
<option value="<? echo "$_POST[sortby]";?>" selected="selected"><? echo "$_POST[sortby]"; ?></option>
<option value="" ></option>
<option value="qt">Qt</option>
<option value="title">Title</option>
<option value="author">Author</option>
<option value="language">Language</option>


</select>
<input name="select_category" style="font-weight: bold;" value="View Materials" type="submit">
</form><br><br>




<table style="width: 100%; text-align: left;" border="1" cellpadding="2"
cellspacing="2">
<tbody>
<tr>
<td class="tabletop">Qt
</td>

<td class="tabletop">Title
</td>
<td class="tabletop">Author
</td>
<td class="tabletop">Language
</td>
<td class="tabletop">Action
</td>
</tr>
<?

if($_POST[id_category]){ $where= "WHERE cat_id= $_POST[id_category]";
//orderby
if($_POST[sortby]){ $orderby = "ORDER BY `$_POST[sortby]` ASC"; }

$result = $db_object->query("SELECT  * FROM isw_library_data $where $orderby ;");

	if (DB::isError($result)) {echo"I can't get  list";}
$numRows  = $result->numRows();
if($numRows > 0){
for($j=0;$j<$numRows;$j++){

$_result= $result->fetchRow();

?>
<tr>
<td style="vertical-align: top;"><a href="../?content=mod_Dawa_center&sid=<? echo "$_result[sid]";?>"><? echo "$_result[qt]";?>
</td>
<td style="vertical-align: top;"> 
<a href="../?content=mod_Dawa_center&sid=<? echo "$_result[sid]";?>"><? echo "<b>$_result[title]</b><br>$_result[brief]";?><a> <br>

</td>
<td style="vertical-align: top;"> <? echo "$_result[author]";?> <br>
</td>
<td style="vertical-align: top;"> <? echo "$_result[language]";?> <br>
</td>
<td style="vertical-align: top;">
<a href="?content=<? echo "$_GET[content]";?>&amp;action=update_content&amp;library_data_id=<? echo "$_result[index]";?>&approve=0">update</a>  <br><br>
<a href="?content=<? echo "$_GET[content]";?>&amp;action=delete_content&amp;library_data_id=<? echo "$_result[index]";?>"> Delete</a>  <br>
</td>
</tr>

<?
}
}else{echo "</table>empty <br>----------------------------------";}}
?>
</tbody>
</table>
<br>
<br>
</body>
</html>
