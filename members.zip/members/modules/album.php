<script src="./modules/spgm/spgm.js" type="text/javascript"></script>
<script src="./modules/spgm/contrib/overlib410/overlib.js" type="text/javascript"></script>

<center>
<br><br><br><?

require("spgm/spgm.php");

?>
</center>