<iframe src="http://ksdeals.com/ads/admin/index.php"
   FRAMEBORDER="0" height="700px" width="100%"></iframe>