

<center><TABLE cellSpacing=0 cellPadding=0 width="80%"  border=0>
<TBODY>
<TR>
<TD><br><br>
<?php
include("album_management/webmin_v2.0.php");
?>
<BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR>
</TD></TR></TBODY></TABLE></center>
