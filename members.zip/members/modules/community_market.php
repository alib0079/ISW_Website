<?
if ($logged_in !== 1) { exit;}
$username="$_SESSION[username]";
$pass="iswcm1";
?>

<BR><Br><a href="http://www.islamicsocietyofwichita.com/community_market/">view community market</a><br>

</b>Use the form below to manage inventory and listings</b><br>
<?
include("community_market/almars_login.php");
?>