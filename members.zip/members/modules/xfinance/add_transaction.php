<script language="JavaScript" src="./scripts/ts_picker.js">
</script>

<?
if ($logged_in !== 1) { exit;}
 echo "<big><font color=\"#008000\"><b>Account # $_SESSION[account_id] : $_SESSION[account_name]</b></font></big><br><br>"; 



//action insert transaction
if($finance_tablename){
$selectbalance = $db_object->query("SELECT  * FROM $finance_tablename ORDER BY `time` DESC LIMIT 0 , 1");

	if (DB::isError($selectbalance)) {
		echo"I can't get the balance please contact the webmaster";
	}

$numRows  = $selectbalance->numRows();
for($i=0;$i<$numRows;$i++){
	$_balances= $selectbalance->fetchRow();
$lastbalance[] = $_balances['balance'];
}



if ($_POST[submit]){
if($_SESSION[account_access]=='w') {
if( $_POST[type]=='+' OR  $_POST[type]=='-'  ){
if($_POST[amount]){
if($_POST[description]){
if($_POST[timestamp]){
$description="$_POST[description] on ($_POST[timestamp])";
$amount="$_POST[type]$_POST[amount] ";
if($_POST[type]=='+'){
$balance= $lastbalance[0] + $_POST[amount] ;
}elseif($_POST[type]=='-'){
$balance= $lastbalance[0] - $_POST[amount] ;
}
//$date = date("y.m.d");
$date= $_POST[timestamp];
$to_from_user_id="$_POST[to_from_user_id]";

$query="INSERT INTO `$finance_tablename` ( `reference` , `description` ,`to_from_user_id`, `amount` , `balance`,`date` )VALUES ('', '$description','$to_from_user_id', '$amount', '$balance','$date')";
if (!mysql_query ($query) )
						{
						echo"This charge was not counted please do it again";
						}else{unset($_POST); echo "<big><b>Transaction was Added succecfuly</b></big>";}
}else{echo "<font color=\"#FF0000\">You forgot the date</font> ";}
}else{echo "<font color=\"#FF0000\">You forgot, Please Write a small description</font>";}
}else{echo "<font color=\"#FF0000\">The amount needs to be more than $0.00</font>";}
}else{echo "<font color=\"#FF0000\">Is the amount Debit(-) Or Credit(+)</font>";}
}else{echo "<font color=\"#FF0000\">You are not allowed to add transactions to this account.";}
}
?>

<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1">
  <tr>
    <td width="100%">
    <form enctype="multipart/form-data" action="" method="POST" name="tstest" >
    <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber2" bgcolor="#C0C0C0" height="54">
    <tr>
    <td width="13%" align="center"><font color="#000080"><b>Type</b></font></td>
      <td width="48%" align="center"><font color="#000080"><b>Description</b></font></td>
      <td width="13%" align="center"><font color="#000080"><b>Amount</b></font></td>
     <td width="150px" align="center"><font color="#000080"><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></td>

    </tr>
    <tr>
      <td width="1%"><select size="1" name="type">
      <option >Choose one</option>
      <option value="-">Expenses(-)</option>
      <option value="+">Income(+)</option>
      </select></td>
      <td width="60%">
      <p align="center"><input type="text" name="description" size="57" value="<?if($_POST[description]){echo "$_POST[description]";}?>" >
<br><br><? include("to_from_drop_select.php"); ?><br><br>
</td>
      <td width="13%">
      <p align="center"><input type="text" name="amount" size="7" value="<?if($_POST[amount]){echo "$_POST[amount]";}?>"></td>
      <td width="38%">
      <p align="center">
      <input size="10" type="Text" name="timestamp" value="<? if($_POST[timestamp]){echo "$_POST[timestamp]"; }else{ print date("Y-m-d H:i:s"); } ?>"><a href="javascript:show_calendar('document.tstest.timestamp', document.tstest.timestamp.value);"><img src="./scripts/cal.gif" width="16" height="16" border="0" alt="Click Here to Pick up the timestamp"></a> 
      <font size="1">open calendar </font>
     </td>
    </tr>
  </table>
  <p><input type="submit" value="Submit" name="submit" style="float: right"></p>
  </form>
  </td>
  </tr>
</table>

<?
}else{echo "<br><br><b>Select and account please</b>";}

?>

