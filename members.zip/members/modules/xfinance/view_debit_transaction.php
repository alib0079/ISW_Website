<?
if ($logged_in !== 1) { exit;} 
if($finance_tablename){
?>

<form method="POST" action="">
<? 
include("to_from_drop_select.php");

?>

<input type="submit" value="Submit" name="submit" >
</form>
<br>





<? echo "<big><font color=\"#008000\"><b>Account # $_SESSION[account_id] : $_SESSION[account_name]</b></font></big>"; ?>

<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1">
  <tr>
    <td width="12%" align="center"><font color="#000080"><b>Reference#</b></font></td>
    <td width="38%" align="center"><font color="#000080"><b>Description</b></font></td>
    <td width="25%" align="center"><font color="#000080"><b>Amount</b></font></td>
    
  </tr>

<?

if($_POST[to_from_user_id]){$and_to_from = "AND to_from_user_id=$_POST[to_from_user_id]";}

$selectbalance = $db_object->query("SELECT  * FROM $finance_tablename WHERE `amount` <0 $and_to_from ORDER BY `time` DESC LIMIT 0 , 30 ");

	if (DB::isError($selectbalance)) {
		echo"I can't get the balance please contact the webmaster";
	}

$numRows  = $selectbalance->numRows();


for($i=0;$i<$numRows;$i++){
 
	$_row= $selectbalance->fetchRow();
$reference = $_row['reference'];
$description = $_row['description']; 
$amount=  $_row['amount'];     
$balance = $_row['balance'];
$date = $_row['date'];
$total+=$_row[amount];
?>

<tr>
    <td width="12%" align="center"><font color="#000080"><?echo "$reference";?></font></td>
    <td width="38%" align="center"><font color="#000080"><?echo "$description";?></font></td>
    <td width="25%" align="center"><font color="#000080"><?echo "$amount";?></font></td>
      </tr>



<?}?>
<tr>
    <td width="12%" align="center"><font color="#000080"></font></td>
    <td width="38%" align="center"><font color="#000080"><b>Total Debit For This period:</b></font></td>
    <td width="25%" align="center"><font color="#000080"><?echo "<b>$total</b>";?></font></td>
      </tr>


</table>
<?}else{ echo "<br><br><b>Please Select an Account</b>";}?>
