<table style="width: 100%; text-align: left;" border="0" cellspacing="2">
<tbody>
<tr>
<td class=tablelinks>
<a href="?content=<? echo "$_GET[content]"; ?>&action=submitted_news">Submitted News</a> | &nbsp;&nbsp; 
<a href="?content=<? echo "$_GET[content]"; ?>&action=approved_news">Approved News</a> | &nbsp;&nbsp;
<a href="?content=<? echo "$_GET[content]"; ?>&action=archive_news">News Archives</a> | &nbsp;&nbsp;
<a href="../?content=<? echo "mod_news"; ?>&action=submit_news">Submit News</a> | &nbsp;&nbsp;
</td>
</tr>
<tr>
<td><br></td>
</tr>

<tr>
<td style="vertical-align: top;">




<?

if($_GET[action]){@include("mod_news/$_GET[action].php");}else{@include("mod_news/home.php");}
?>

</td>
</tr>
</tbody>
</table>

