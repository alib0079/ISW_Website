
<body bgcolor="#f0f8ff" link="#0000ff" vlink="#ff0000">
<a name="top"></a>
<div width="100%" align="center"><!-- Outer Table- 1 Col- span 2-3 -->
<table border="0" bordercolor="#000000" cellpadding="0" cellspacing="0"
 width="100%">
  <tbody>
    <tr>
      <td valign="top"><!-- Inner Table- 2/3 Col do not add rules=none here or mozilla mac shows no cell spacing -->
      <table border="0" bordercolor="#000000" cellpadding="0"
 cellspacing="5" width="100%">
<!-- End page_header -->
        <tbody>
<!-- Start Row 2 / Menu Left Column / Content Area -->
          <tr>
            <td colspan="2" align="center" valign="top" width="100%">
<!-- Start content -->
            <table style="width: 449px; height: 141px;" border="0"
 cellpadding="0" cellspacing="0">
              <tbody>
                <tr bgcolor="#000000">
                  <td bgcolor="#000000">
                  <table style="width: 457px; height: 141px;" border="0"
 cellpadding="5" cellspacing="1">
                    <tbody>
                      <tr class="BLK_DEF_TITLE" valign="middle">
                        <td class="BLK_IT_TITLE" colspan="2">Invoice
System Specail Login<br>
                        </td>
                      </tr>
                      <tr class="BLK_DEF_ENTRY">
                        <td class="BLK_IT_ENTRY" colspan="2">
                        <table border="0" cellpadding="5"
 cellspacing="0" width="100%">
                          <tbody>
                            <tr>
                              <td align="center">
                              <form
 action="http://www.ksdeals.com:80/invoice/coin_includes/session_admin.php"
 method="post" name="login">
                                <table
 style="width: 405px; height: 76px;" cellpadding="1" cellspacing="0">
                                  <tbody>
                                    <tr>
                                      <td class="TP3SML_NR" width="30%">
                                      <b>User Name:&nbsp;</b>
                                      </td>
                                      <td class="TP3SML_NL" width="70%">
                                      <input readonly="readonly"
 value="invoicesys" maxlength="16" size="16" name="username"
 class="PSML_NL"></td>
                                    </tr>
                                    <tr>
                                      <td class="TP3SML_NR" width="30%">
                                      <b>Password:&nbsp;</b>
                                      </td>
                                      <td class="TP3SML_NL" width="70%">
                                      <input readonly="readonly"
 value="inv35789" maxlength="16" size="16" name="password"
 class="PSML_NL" type="password"></td>
                                    </tr>
                                    <tr>
                                      <td class="TP3SML_NR" width="30%">
                                      <input name="w" value="admin"
 type="hidden"><input name="o" value="login" type="hidden">
                                      <input name="op" value=""
 type="hidden"><br>
                                      </td>
                                      <td class="TP3SML_NL" width="70%">
                                      <input name="b_login" id="b_login"
 class="button_form" value="Log In"
 onmouseover="setClassName('b_login','button_form_h');"
 onmouseout="setClassName('b_login','button_form');" type="submit"><input
 name="b_reset" id="b_reset" class="button_form" value="Reset"
 onmouseover="setClassName('b_reset','button_form_h');"
 onmouseout="setClassName('b_reset','button_form');" type="reset"></td>
                                    </tr>
                                  </tbody>
                                </table>
                              </form>
                              </td>
                            </tr>
                            <tr>
                              <td align="right"><a
 href="login.php?w=user&amp;o=login"><img
 src="http://www.ksdeals.com:80/invoice/coin_themes/classic/images/nav/cl_med_clients.gif"
 alt="Clients" name="Log In" align="middle" border="0"></a>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  </td>
                </tr>
              </tbody>
            </table>
            <br>
            </td>
          </tr>
<!-- End Content Area : End Row 2 -->
<!-- Start Footer Row --><tr>
            <td colspan="2" valign="top">
            <div valign="middle" align="center">
            <table border="0" cellpadding="0" cellspacing="0"
 width="100%">
              <tbody>
                <tr>
                  <td>
                  <table border="0" cellpadding="5" cellspacing="1"
 width="100%">
                    <tbody>
                      <tr>
                        <td class="BLK_FTR_CLEAR_C" valign="middle">Copyright
                        <center><a href="http://almars.net">Almars.net</a></center>
2003-2004, all rights reserved
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  </td>
                </tr>
              </tbody>
            </table>
            </div>
            </td>
          </tr>
<!-- End Footer Row -->
<!-- Start Powered By Row -->
<!-- End Powered By Row --><!-- Close Out Inner/Outer Table and Page Tags -->
        </tbody>
      </table>
      </td>
    </tr>
  </tbody>
</table>
</div>
</body>
</html>
