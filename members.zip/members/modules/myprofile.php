<table style="width: 100%; text-align: left;" border="0" cellspacing="2">
<tbody>
<tr>
<td class=tablelinks>
<a href="?content=<? echo "$_GET[content]"; ?>&action=home_myprofile">My profile</a> | &nbsp;&nbsp;
<a href="?content=<? echo "$_GET[content]"; ?>&action=edit_myprofile">Edit Myprofile</a> | &nbsp;&nbsp; 
</td>
</tr>
<tr>
<td><br></td>
</tr>

<tr>
<td style="vertical-align: top;">




<?

if($_GET[action]){@include("myprofile/$_GET[action].php");}else{@include("myprofile/home_myprofile.php");}
?>

</td>
</tr>
</tbody>
</table>

