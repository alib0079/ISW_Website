<?
if($_POST[delete_project]){


//update project in database


$update = $db_object->query(" UPDATE `isw_projects` SET 
`archive` = '1'
WHERE `project_id` = '$_POST[project_id]' AND `project_owner`= '$_SESSION[userid]' LIMIT 1  ");

if (DB::isError($update)) {
		echo"I can't update this";
	}



echo "The project $_POST[project_id] was deleted from the list thanks";


}









if(!$_POST[delete_project] ){



$result = $db_object->query("SELECT  * FROM isw_projects WHERE `project_id`=$_GET[proid] AND `project_owner`= $_SESSION[userid] AND `archive`= 0 ");

	if (DB::isError($result)) {
		echo"I can't get main categories";
	}


	$_result= $result->fetchRow();


?>


<form method="post">
 <input  type=hidden readonly="readonly" style="font-weight: bold;"  name="project_id" value="<? echo "$_result[project_id]"; ?>"> 
 <input name="delete_project" style="font-weight: bold;" value="delete project # <? echo "$_result[project_id]";?>" type="submit"></form>

<?}?>