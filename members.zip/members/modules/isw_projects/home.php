<table style="width: 100%; text-align: left;" border="1" cellpadding="2"
cellspacing="2">
<tbody>
<tr>
<td class="tabletop">ID
</td>

<td class="tabletop">Project
</td>
<td class="tabletop">Scale
</td>
<td class="tabletop">Status
</td>

<td class="tabletop">Action
</td>
</tr>
<?
function stripslashes_deep($value)
{
   $value = is_array($value) ?
               array_map('stripslashes_deep', $value) :
               stripslashes($value);

   return $value;
}







$result = $db_object->query("SELECT  * FROM isw_projects WHERE  `project_owner`= $_SESSION[userid] AND `archive`= 0");

	if (DB::isError($result)) {
		echo"I can't get main categories";
	}

$numRows  = $result->numRows();

if ($numRows > 0 ){

for($i=0;$i<$numRows;$i++){
	$_result= $result->fetchRow();

$_result = stripslashes_deep($_result);

?>
<tr>
<td style="vertical-align: top;">
<? echo "$_result[project_id]";?>
</td>
<td style="vertical-align: top;"> 
<a href="../?content=mod_viewproject&proid=<? echo "$_result[project_id]";?>"><? echo "<b>$_result[project_name]"; ?></b><a> <br>

</td>

<td style="vertical-align: top;"> <? echo "$_result[project_scale]";?> <br>
</td>

<td style="vertical-align: top;"> <? echo "$_result[project_status]";?> <br>
</td>

<td style="vertical-align: top;">
<a href="?content=<?echo "$_GET[content]";?>&amp;action=update_project&amp;proid=<? echo "$_result[project_id]";?>">update</a>  <br>
<a href="?content=<?echo "$_GET[content]";?>&&amp;action=delete_project&amp;proid=<? echo "$_result[project_id]";?>">delete</a>  <br>
<a href="?content=<?echo "$_GET[content]";?>&&amp;action=publish_project&amp;proid=<? echo "$_result[project_id]";?>">publish</a>  <br>
</td>
</tr>

<?



}
}else{echo "</table>table empty<br>----------------------------------";}
?>
</tbody>
</table>
<br>
<br>
</body>
</html>