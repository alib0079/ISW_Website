<?
if($_POST[add_project]){
if($_POST[project_name] AND $_POST[project_status]){

//add project in database


$add = $db_object->query(" INSERT INTO `isw_projects` ( `project_id` , `project_name` , `project_description` , `project_status` , `project_scale` , `project_owner` , `archive`  )
VALUES (
'null', '$_POST[project_name]', '$_POST[project_description]', '$_POST[project_status]', '$_POST[project_scale]', '$_SESSION[userid]', '0'
);  ");

if (DB::isError($add)) {
		echo"I can't add this";
	}



echo "The project $_POST[project_id] was added thanks";


}else{$error="Missing required field (*)"; }






}


if(!$_POST[add_project] OR $error){


echo "$error <br><br>";


?>


<form method="post">
<table
style="background-color: rgb(255, 255, 153); width: 100%; text-align: left;"
border="1" cellpadding="2" cellspacing="0">
<tbody>
<tr>
<td><b>ID #</b></td>
<td><b>Project Name*</b></td>
<td><span style="font-weight: bold;">Scale</span><br>
</td>
<td style="vertical-align: top;"><span
style="font-weight: bold;">Status*</span><br>
</td>
</tr>
<tr>
</tr>
<tr>
<td><span style="font-weight: bold;"> </span> <input readonly="readonly"
style="font-weight: bold;" size="5" name="project_id" value="<? echo "$_POST[project_id]"; ?>"> <span
style="font-weight: bold;"> </span><br style="font-weight: bold;">
</td>
<td><span style="font-weight: bold;"> </span><input size="30"
style="font-weight: bold;" name="project_name" value="<? echo "$_POST[project_name]"; ?>"><span
style="font-weight: bold;"> </span><br style="font-weight: bold;">
</td>
<td><span style="font-weight: bold;"> </span>

<select  name="project_scale" >
<option value="<? echo "$_POST[project_scale]"; ?>" selected="selected"><? echo "$_POST[project_scale]"; ?></option>
<option value="" ></option>
<option value="1" >1</option>
<option value="2" >2</option>
<option value="3" >3</option>
<option value="4" >4</option>
<option value="5" >5</option>
</select>

<span style="font-weight: bold;"> </span><br style="font-weight: bold;">
</td>
<td><span style="font-weight: bold;"> </span>

<select  name="project_status" >
<option value="<? echo "$_POST[project_status]"; ?>" selected="selected"><? echo "$_POST[project_status]"; ?></option>
<option value="" ></option>
<option value="Active" >Active</option>
<option value="On Hold" >On Hold</option>
<option value="Completed" >Completed</option>
<option value="Transferred" >Transferred</option>
</select>

<span style="font-weight: bold;">

</span></td>
</tr>
<tr>
</tr>
<tr>
</tr>
</tbody>
</table>
<table
style="background-color: rgb(255, 255, 153); width: 100%; text-align: left;"
border="1" cellpadding="2" cellspacing="0">
<tbody>
<tr>
<td style="vertical-align: top;"><b>Description:</b><br>
<textarea maxlength="200" rows="10" name="project_description"
cols="70">
<? echo "$_POST[project_description]";?>
</textarea> </td>
</tr>
</tbody>
</table>
<br>
&nbsp; <input name="add_project" style="font-weight: bold;"
value="Add project" type="submit"></form>

<?}?>