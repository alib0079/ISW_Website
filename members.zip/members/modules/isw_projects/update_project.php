<?
if($_POST[update_project]){
if($_POST[project_name] AND $_POST[project_status]){

//update project in database


$update = $db_object->query(" UPDATE `isw_projects` SET 
`project_name` = '$_POST[project_name]',
`project_description` = '$_POST[project_description]',
`project_status` = '$_POST[project_status]',
`project_scale` = '$_POST[project_scale]'
WHERE `project_id` = '$_POST[project_id]' AND `project_owner`= '$_SESSION[userid]' LIMIT 1  ");

if (DB::isError($update)) {
		echo"I can't update this";
	}



echo "The project $_POST[project_id] was updated thanks";


}else{$error="Missing required field (*)"; }






}


if(!$_POST[update_project] OR $error){


echo "$error <br><br>";

$result = $db_object->query("SELECT  * FROM isw_projects WHERE `project_id`=$_GET[proid] AND `project_owner`= $_SESSION[userid] AND `archive`= 0 ");

	if (DB::isError($result)) {
		echo"I can't get main categories";
	}


	$_result= $result->fetchRow();


?>


<form method="post">
<table
style="background-color: rgb(255, 255, 153); width: 100%; text-align: left;"
border="1" cellpadding="2" cellspacing="0">
<tbody>
<tr>
<td><b>ID #</b></td>
<td><b>Project Name*</b></td>
<td><span style="font-weight: bold;">Scale</span><br>
</td>
<td style="vertical-align: top;"><span
style="font-weight: bold;">Status*</span><br>
</td>
</tr>
<tr>
</tr>
<tr>
<td><span style="font-weight: bold;"> </span> <input readonly="readonly"
style="font-weight: bold;" size="5" name="project_id" value="<? echo "$_result[project_id]"; ?>"> <span
style="font-weight: bold;"> </span><br style="font-weight: bold;">
</td>
<td><span style="font-weight: bold;"> </span><input size="30"
style="font-weight: bold;" name="project_name" value="<? echo "$_result[project_name]"; ?>"><span
style="font-weight: bold;"> </span><br style="font-weight: bold;">
</td>
<td><span style="font-weight: bold;"> </span>
<select  name="project_scale" >
<option value="<? echo "$_result[project_scale]"; ?>" selected="selected"><? echo "$_result[project_scale]"; ?></option>
<option value="" ></option>
<option value="1" >1</option>
<option value="2" >2</option>
<option value="3" >3</option>
<option value="4" >4</option>
<option value="5" >5</option>
</select>

<span
style="font-weight: bold;"> </span><br style="font-weight: bold;">
</td>
<td><span style="font-weight: bold;"> </span>

<select  name="project_status" >
<option value="<? echo "$_result[project_status]"; ?>" selected="selected"><? echo "$_result[project_status]"; ?></option>
<option value="" ></option>
<option value="Active" >Active</option>
<option value="On Hold" >On Hold</option>
<option value="Completed" >Completed</option>
<option value="Transferred" >Transferred</option>
</select>



<span style="font-weight: bold;"></span></td>
</tr>
<tr>
</tr>
<tr>
</tr>
</tbody>
</table>
<table
style="background-color: rgb(255, 255, 153); width: 100%; text-align: left;"
border="1" cellpadding="2" cellspacing="0">
<tbody>
<tr>
<td style="vertical-align: top;"><b>Description:</b><br>
<textarea maxlength="200" rows="10" name="project_description"
cols="70">
<? echo "$_result[project_description]";?>
</textarea> </td>
</tr>
</tbody>
</table>
<br>
&nbsp; <input name="update_project" style="font-weight: bold;"
value="Update project" type="submit"></form>

<?}?>