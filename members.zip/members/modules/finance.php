
<? if ($logged_in !== 1) { exit;} ?>
<table style="width: 100%; text-align: center;" border="0" cellspacing="2">
<tbody>
<tr>
<td class=tablelinks>
<a href="?content=<? echo "$_GET[content]"; ?>&action=view_all_transaction&change_cat=true">View All Transaction</a> | &nbsp;&nbsp;
<a href="?content=<? echo "$_GET[content]"; ?>&action=view_credit_transaction&change_cat=true">View Income</a> | &nbsp;&nbsp; 
<a href="?content=<? echo "$_GET[content]"; ?>&action=view_debit_transaction&change_cat=true">View Expenses</a> | &nbsp;&nbsp;
<a href="?content=<? echo "$_GET[content]"; ?>&action=history_transaction&change_cat=true&period=all">History Transaction</a> | &nbsp;&nbsp;
<a href="?content=<? echo "$_GET[content]"; ?>&action=add_transaction&change_cat=true">Add Transaction</a> | &nbsp;&nbsp;

</td>
</tr>
<tr>
<td style=" text-align: center;">
---------------------------------------------------------------------------------------------------------------------
<div style="text-align: left;">

<table >

<tr>
<td style="vertical-align: top;"><? include("finance/account_access.php"); ?>
</td>
<td style="vertical-align: top;"><? include("finance/form_select_month_year.php"); ?>
</td>
<td style="vertical-align: top;"><? 
//include ("finance/to_from_drop_select.php"); 
?>
</td>
</tr>

</table>


<?

  echo "<font color=\"#008000\"><b> [Account # $_SESSION[account_id]</b> $_SESSION[account_name]<b>] [Action :</b> $_GET[action] <b>]</b>   "; 

if($_GET[period]){  $year=$_GET[year]; $month=$_GET[month]; $Month=$_GET[month]; }else{$year= date("Y"); $month= date("m"); $Month=date("M");  }

$Qperiod="$year-$month-00";

$Dperiod="$Month-$year";





echo "[ Period : </b>$Dperiod<b>]</b>"; 




?>
</div>
</td>
</tr>

<tr>
<td style="vertical-align: top;">




<?

if($_GET[action]){@include("finance/$_GET[action].php");}else{@include("finance/view_all_transaction.php");}
?>

</td>
</tr>
</tbody>
</table>

