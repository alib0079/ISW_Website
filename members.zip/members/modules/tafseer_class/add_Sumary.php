<?
if(eregi ("\." , "$_POST[class_num]")){ echo "Please us incrementale class numbers no points ";  unset($_POST[class_num]); }




if( $_POST[file_uploaded] AND $_POST[class_num] AND $_POST[surah] AND $_POST[title] ){


include("check_duplicat_class_sumary.php");












$location = "http://www.islamicsocietyofwichita.com/wiki/tafseer_class/tafseer_class_sumary/$_POST[class_num]";

$title="<b>Summary #</b> $_POST[class_num] <b>| Surah :</b> $_POST[surah] <b> | Title:</b> $_POST[title]";

if($_POST[update]){ 




$update = $db_object->query("
 UPDATE `library_data` SET `title` = '$title',
`location` = '$location',
`publishdate` = '$_POST[timestamp]'
WHERE `isw_library_data`.`index` =$_POST[data_id] LIMIT 1 ;
");

if (DB::isError($update)) {
		echo"I can't update this data now";
	}else{ echo "update succesful------------- OK <br>";}



}else{

$insertdata = $db_object->query("  
INSERT INTO `isw_library_data` ( `index` , `datatype` , `language` , `cat_id` , `title` , `qt` , `subject` , `author` , `isbn` , `publisher` , `edition` , `location` , `publishdate` , `adddate` , `optionzero` )
VALUES (
NULL , 'ebook', 'english', '72', '$title', '', 'Tafseer Class Summary', 'SH.Hilali', NULL , NULL , NULL , '$location' , '$_POST[timestamp]' , NULL , '$_POST[class_num]'
)");

if (DB::isError($insertdata)) {
		echo"I can't add this data now";
	}else{ echo "listing succesful------------- OK <br>";}

$returen_id = mysql_insert_id();

}
$uploaddir="../wiki/tafseer_class/tafseer_class_sumary/";
$imagename="$_POST[class_num]";
//$imagename.= basename($_FILES['uploadedfile']['name']);


$uploadfile = $uploaddir . $imagename;

if (move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $uploadfile)) {

  echo "<br><b>The class # $_POST[class_num] was uploaded</b><br><br>";

}else{echo "Image was not copied";}
exit;
}
?>

<script language="JavaScript" src="./scripts/ts_picker.js">
</script>

<form enctype="multipart/form-data" action="" method="POST" name="tstest" >

<input type="hidden" name="file_uploaded" value="true" >

<input type="hidden" name="slide_name" value="<? echo "$_GET[content]";?>" >
<table style="width: 100%; text-align: left;" border="1" cellpadding="2"
cellspacing="0">
<tbody>
<tr>
<td style="vertical-align: top;"><br>
<b>Summary # </b><input type="text" name="class_num" size="2" value="<? echo "$_POST[class_num]";?>" ><br><br>
</td>

<td style="vertical-align: top;">
<br>
<b>Class Date :</b> <input type="Text" name="timestamp" value="<? echo "$_POST[timestamp]"; ?>">
  <a href="javascript:show_calendar('document.tstest.timestamp', document.tstest.timestamp.value);"><img src="./scripts/cal.gif" width="16" height="16" border="0" alt="Click Here to Pick up the timestamp"></a> 
  <font size="1">Click here to open calendar </font>
<br><br>
 </td>
</tr>
<td style="vertical-align: top;">
<br><b> Surah : </b><input type="text" name="surah" size="20" value="Aali-Imran" ><br>
<br></td> 
<td style="vertical-align: top;">
<br> <b>Title : <input type="text" name="title" size="30" value="<? echo "$_POST[title]";?>" ></b>

<br></td> 


</tr>
</tbody>
</table>
<table style="width: 100%; text-align: left;" border="1" cellpadding="2"
cellspacing="0">
<tr>
<td style="vertical-align: top;"><b>Upload a text or html file only:</b><br><br>
<input size=70 name="uploadedfile" type="file" />
<input type="submit" name="uploaded"  size="70" value="Upload File"><br><br>
</td>
</tr>


</table>
</form> 

