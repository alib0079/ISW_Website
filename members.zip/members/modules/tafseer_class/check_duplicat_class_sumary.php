<?
//check if class_num is valid number

if(is_numeric($_POST[class_num])){}else{  echo "Please us a valid class number only use 0 to 9 ";  exit;}
if(is_float($_POST[class_num])){ echo "Please us a valid class number only use 0 to 9 ";  exit;}


// check if class_num exist


$result = $db_object->query(" SELECT * FROM `library_data` WHERE `datatype` LIKE 'ebook' AND `subject` LIKE 'Tafseer Class Summary' AND `optionzero`=$_POST[class_num]  ");

if (DB::isError($result)) {
		echo "I can not do result";
	}

$numRows  = $result->numRows();

if ($numRows > 0 AND !$_POST[update]){
$_result= $result->fetchRow();
?>
<b>Class # <? echo "$_POST[class_num]"; ?> Already exist 
To replace it please upload the file again and hit replace or Go Back</b>
<form enctype="multipart/form-data"  action="" method="POST">
<input type="hidden" name="data_id" size="2" value="<? echo "$_result[index]"; ?>" >
<input type="hidden" name="class_num" size="2" value="<? echo "$_POST[class_num]"; ?>" >
<input type="hidden" name="timestamp" size="2" value="<? echo "$_POST[timestamp]"; ?>" >
<input type="hidden" name="surah" size="2" value="<? echo "$_POST[surah]"; ?>" >
<input type="hidden" name="title" size="2" value="<? echo "$_POST[title]"; ?>" >
<input type="hidden" name="file_uploaded" value="true" >
<input type="hidden" name="update" value="true" >
<input size=70 name="uploadedfile" type="file" />
<input type="submit" name="uploaded"  size="70" value="Replace">
<form>
<?
exit;
}
?>