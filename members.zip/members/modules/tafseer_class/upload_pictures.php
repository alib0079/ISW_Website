<head>

<style type="text/css">
@import './style/DOMinclude.css';
#g{position:absolute;top:1em;right:1em}
</style>

<script type="text/javascript" 
  src="./scripts/DOMinclude_config.js"></script>
<script type="text/javascript" 
  src="./scripts/DOMinclude.js"></script>


</head>

<? 
$uploaddir="../pics/amir/";
$dir="pics/amir";

if( $_POST[uploaded]){


//$imagename="$_POST[class_num]";
$imagename.= basename($_FILES['uploadedfile']['name']);


$uploadfile = $uploaddir . $imagename;

if (move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $uploadfile)) {

  echo "<br><b>Image uploaded</b><br><br>";

}else{echo "Image was not copied";}

}
?>
<form enctype="multipart/form-data" action="" method="POST" name="tstest" >
<input size=70 name="uploadedfile" type="file" />
<input type="submit" name="uploaded"  size="70" value="Upload Picture">
<br>
<br>
<b>Current Pictures :</b><br>
<?

//Looks into the directory and returns the files, no subdirectories 
     
//The path to the style directory 
    $dirpath = "$uploaddir"; 
    $dh = opendir($dirpath); 
       while (false !== ($file = readdir($dh))) { 
 //Don't list subdirectories

 
          if (!is_dir("$dirpath/$file") && $file != "." && $file != ".." ) { 

         $_file[]=$file;

	} //end !is_dir
} //end while readdir
     closedir($dh); 
 
 $_file[]=sort($_file);
$count=count($_file);

include("print_page.php");
echo "<ul>";
for($i=0;$i<$count-1;$i++){

echo "<br><br><li><a href=\"$uploaddir$_file[$i]\" class=\"DOMpop\"> $_file[$i] </a><br>";



echo "  Image Location: <input size=\"60\" type=\"text\" value=\"http://$_SERVER[HTTP_HOST]/$dir/$_file[$i] \" ></li>";

}
echo "</ul>";




?>