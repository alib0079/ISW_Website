<table id="tblNewest"
style="text-align: left; margin-left: auto; margin-right: auto; width: 100%; "
border="0" cellpadding="0" cellspacing="0">

<?php
      

	  $listings_per_page=15;
        $config['showProducts'] = 3;
	  $dimensions[0]=100;
	  $dimensions[1]=150;
       
$total_num_page = ceil($count/ $listings_per_page );


for ($a=0; $a<=$total_num_page-1; $a++)
	{
	$page_jump = $a +1;
	
         print "<a href=\"?content=$_GET[content]&cat_name=$_GET[cat_name]&cat=$cat&page=$a\"><font size=4>$page_jump</font></a>  ";

	}
  echo "</div><br><br>";

if($count< 1 ){echo "No Pictures Available";}

 $cur_page="$_GET[page]";


for($i=1;$i<$count;$i++){


if (($i - 1) % $config['showProducts'] == 0){     
          echo "<tr>";
          }



// Output the Cell Header
          echo "<td style=\"vertical-align: middle; text-align: center;\"> Delete <br>";

$j=$i-1;
                      
echo "<a href=\"$uploaddir$_file[$j]\" class=\"DOMpop\"><img  src=\"http://www.islamicsocietyofwichita.com/pics/thumb.php?src=$_file[$j]&x=100&y=100&f=0&dir=$_SESSION[userid]\"></a>";




//Output the Cell end
echo "</td>";




          
          // Show the Closing Table Row
          if ( $i % $config['showProducts'] == 0 ){

            echo "</tr>";
            }
       
 }// end count

 // Close the Table Row Properly
        if (($i - 1) % $config['showProducts'] != 0)
          echo "<td colspan=\"" . ($i - (($i - 1) % $config['showProducts'])) . "\"></td></tr>";




      ?>

 </table>
    
