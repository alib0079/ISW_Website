<?
if($_POST[id_category] OR $_SESSION[id_category]){
$maincat = $db_object->query("SELECT  cat_name FROM isw_library_categories WHERE cat_id=$_POST[id_category] AND cat_type='p' ");

	if (DB::isError($maincat)) {echo"I can't get  cat name";}
$_maincat= $maincat->fetchRow();

$_SESSION[id_category_name]=$_maincat[cat_name];

$_SESSION[id_category]=$_POST[id_category];

}else{


?>




<form method="post">
<b>Select a Category:</b> 
<select  name="id_category"   >


<?
$maincat = $db_object->query("SELECT  * FROM isw_library_categories WHERE  cat_parent=0 AND cat_type='p'");

	if (DB::isError($selectbalance)) {
		echo"I can't get main categories";
	}
$numRows  = $maincat->numRows();

for($i=0;$i<$numRows;$i++){
	$_maincat= $maincat->fetchRow();

print "<option value=\"$_maincat[cat_id]\" selected=\"selected\" style=\"font-weight: bold;\"><b>$_maincat[cat_name]</b></option>";

$subcat = $db_object->query("SELECT  * FROM isw_library_categories WHERE  cat_parent=$_maincat[cat_id] ");

	if (DB::isError($subcat)) {
		echo"I can't get main categories";
	}
$num  = $subcat->numRows();
if($num > 0){
for($j=0;$j<$num;$j++){
	$_subcat= $subcat->fetchRow();

print "<option value=\"$_subcat[cat_id]\" selected=\"selected\"> -->$_subcat[cat_name] </option>";

}
}
}

?>

<option value="" selected="selected">-----------------------------------------------------</option>
</select>
<input name="select_category" style="font-weight: bold;" value="Select Category "type="submit">
</form><br><br>
<?}?>