<form method="post">
<table
style="background-color: rgb(255, 255, 153); width: 100%; text-align: left;"
border="1" cellpadding="2" cellspacing="0">
<tbody>
<tr>
<td><b>ID #</b></td>
<td><b>Material Title</b></td>
<td><b>Author</b></td>
<td style="vertical-align: top;"><span
style="font-weight: bold;">Category</span><br>
</td>

</tr>
<tr>
</tr>
<tr>
<td><span style="font-weight: bold;"> </span><input
size="1" style="font-weight: bold;" readonly="readonly" name="id" value="<? echo "$_result1[index]"; ?>"><span
style="font-weight: bold;"> </span><br style="font-weight: bold;">
</td>
<td><span style="font-weight: bold;" > </span>
<input size="30" style="font-weight: bold;" name="title" value="<?echo "$_result1[title]";?>"> 
<span
style="font-weight: bold;"> </span><br style="font-weight: bold;">
</td>
<td><span style="font-weight: bold;"> </span> <input
size="30" style="font-weight: bold;" name="author" value="<?echo "$_result1[author]";?>"><span
style="font-weight: bold;"></span></td>
<td style="vertical-align: top;">

<? include("update_content_select_category.php"); ?>

</td>


</tr>
<tr>
</tr>
<tr>
</tr>
</tbody>
</table>

<table
style="background-color: rgb(255, 255, 153); width: 100%; text-align: left;"
border="1" cellpadding="2" cellspacing="0">
<tbody>
<tr>
<td style="vertical-align: top;"><b>Location :</b><br>
Current location :<? echo "$_result1[location]"; ?>
<br>


<b>Shelf :</b><select  name="shelf"   >
<option value="<? echo "$_POST[shelf]"; ?>" selected="selected"><? echo "$_POST[shelf]"; ?></option>
<option value=""></option>
<option value="A" >A</option>
<option value="B" >B</option>
<option value="C" >C</option>
<option value="D" >D</option>
<option value="E" >E</option>
<option value="F" >F</option>
<option value="G" >G</option>
<option value="K" >K</option>
</select>

<br><br>
<b>Section :</b><select  name="section"   >
<option value="<? echo "$_POST[section]"; ?>" selected="selected"><? echo "$_POST[section]"; ?></option>
<option value=""></option>
<option value="1" >1</option>
<option value="2" >2</option>
<option value="3" >3</option>
<option value="4" >4</option>
<option value="5" >5</option>
<option value="6" >6</option>
<option value="7" >7</option>
<option value="8" >8</option>
</select>

</td>
<td style="vertical-align: top;"><b>Content Specification in this Category:</b><br><br>
<b>Qt:</b>
<input size="5" style="font-weight: bold;" name="qt" value="<?echo "$_result1[qt]";?>"> 
<br>
<br>
<b>ISBN:</b>
<input size="30" style="font-weight: bold;" name="isbn" value="<?echo "$_result1[isbn]";?>"> 
<br>
<br>
<b>Content Language:</b><select  name="language"   >
<option value="" selected="selected">------------</option>
<option value="<? echo "$_result1[language]";?>" selected="selected"><? echo "$_result1[language]";?></option>
<option value="" ></option>
<option value="arabic" >Arabic</option>
<option value="english" >english</option>
<option value="Spanish" >Spanish</option>
</select>
<? @include("add_special_fields_form.php");?>
<br>
--------------------------------------------------------

</td>

</tr>
</tbody>
</table>
<br>










&nbsp; <input name="update_content" style="font-weight: bold;" value="Update Content"
type="submit"></form>
<br>
