<?
if($_result1[cat_id]){
$maincat = $db_object->query("SELECT  cat_name FROM isw_library_categories WHERE cat_id=$_result1[cat_id]  ");

	if (DB::isError($maincat)) {echo"I can't get  cat name";}
$_maincat= $maincat->fetchRow();
?>
<input size="30" type="hidden" name="cat_name" value="<?echo "$_maincat[cat_name]";?>">
<?
}
if($_POST[id_category]){
$newcat = $db_object->query("SELECT  cat_name FROM isw_library_categories WHERE cat_id=$_POST[id_category]  ");

	if (DB::isError($newcat)) {echo"I can't get  cat name";}
$_newcat= $newcat->fetchRow();
?>
<input size="30" type="hidden" name="cat_name" value="<?echo "$_newcat[cat_name]";?>">
<?
}


?>





<select  name="id_category"   >


<?
$option = $db_object->query("SELECT  * FROM isw_library_categories WHERE  cat_parent=0 AND cat_type='p'");

	if (DB::isError($selectbalance)) {
		echo"I can't get main categories";
	}
$numRows  = $option->numRows();

for($i=0;$i<$numRows;$i++){
	$_option= $option->fetchRow();

print "<option value=\"$_option[cat_id]\" selected=\"selected\" style=\"font-weight: bold;\"><b>$_option[cat_name]</b></option>";

$subcat = $db_object->query("SELECT  * FROM isw_library_categories WHERE  cat_parent=$_option[cat_id] ");

	if (DB::isError($subcat)) {
		echo"I can't get main categories";
	}
$num  = $subcat->numRows();
if($num > 0){
for($j=0;$j<$num;$j++){
	$_subcat= $subcat->fetchRow();

print "<option value=\"$_subcat[cat_id]\" selected=\"selected\"> -->$_subcat[cat_name] </option>";

}
}
}

?>
<option ></option>
<option ></option>

<option value="<? echo "$_result1[cat_id]";?>" selected="selected"><? echo " Currently in : $_maincat[cat_name]";?></option>
<option ></option>
<?if ($_POST[id_category]){?><option value="<? echo "$_POST[id_category]";?>" selected="selected"><? echo "$_newcat[cat_name]";?></option><?}?>

</select>

