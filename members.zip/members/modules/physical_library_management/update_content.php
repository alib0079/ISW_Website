<div style="text-align: left;"><b>update Content: > </b></div><br>
<?

if($_GET[library_data_id]){
 
$result1 = $db_object->query("SELECT * FROM isw_library_data WHERE `index`=$_GET[library_data_id] ; ");

	if (DB::isError($result1)) {echo"I can't get result";}
$_result1= $result1->fetchRow();

}



//check an query 
if($_POST[update_content]){

if($_POST[shelf] && $_POST[section]){ $_POST[location]="Shelf: $_POST[shelf] Section: $_POST[section]";}
$_POST[datatype]="onshelf";

if($_POST[title]&&$_POST[author]&&$_POST[datatype]&&$_POST[language]&&$_POST[location]&&$_POST[qt]){

$update = $db_object->query("
 UPDATE `isw_library_data` SET `datatype` = '$_POST[datatype]',
`language` = '$_POST[language]',
`cat_id` = '$_POST[id_category]',
`title` = '$_POST[title]',
`qt` = '$_POST[qt]',
`subject` = '$_POST[cat_name]',
`author` = '$_POST[author]',
`isbn` = '$_POST[isbn]',
`publisher` = '$_POST[publisher]',
`edition` = '$_POST[edition]',
`location` = '$_POST[location]',
`publishdate` = '$_POST[publishdate]',
`adddate` = '$_POST[adddate]' WHERE `index` =$_GET[library_data_id] LIMIT 1 ;

");

	if (DB::isError($update)) {echo"I can't get result";}


echo "<br>Data has been updated";




}else{ $ERROR="All fields are required"; }

}//end if post update_content
if(!$_POST[update_content] OR $ERROR){
echo "$ERROR";
include("update_content_form.php");
}
?>


