<div style="text-align: left;"><b>Add Category: > </b></div><br>
<?
if($_POST[add_category]){
if($_POST[id_parent] AND $_POST[cat_name]){
if($_POST[id_category]=='Home'){$_POST[id_category]=0; }

$insertdata = $db_object->query("  
INSERT INTO `isw_library_categories` ( `cat_id` ,`cat_type`, `cat_name` , `cat_parent` , `cat_count` , `form_file` , `description` , `cat_pic` , `cat_count_admin` )
VALUES (
NULL ,'p', '$_POST[cat_name]', '$_POST[id_parent]', NULL , NULL , '$_POST[description]', NULL , NULL
)");

if (DB::isError($insertdata)) {
		echo"I can't add this data now";
	}else{ echo "listing succesful------------- OK <br>";}

$returen_id = mysql_insert_id();
echo "listing # $returen_id---------- OK<br>";









}else{ $ERROR="All fields are required";}
}

if(!$_POST[add_category] OR $ERROR){
echo "$ERROR";
?>




<form method="post">
<b> Categroy Name:</b>
<input size="30" style="font-weight: bold;" name="cat_name" value="<?echo "$_POST[cat_name]";?>">
<br><br>
<b>Select a Parent Category:</b> 
<select  name="id_parent"   >
<option value="Home" style="font-weight: bold;">Home</option>
<option value="0" style="font-weight: bold;"></option>
<?
$maincat = $db_object->query("SELECT  * FROM isw_library_categories WHERE  cat_parent=0 AND cat_type='p' ");

	if (DB::isError($selectbalance)) {
		echo"I can't get main categories";
	}
$numRows  = $maincat->numRows();

for($i=0;$i<$numRows;$i++){
	$_maincat= $maincat->fetchRow();

print "<option value=\"$_maincat[cat_id]\" selected=\"selected\" style=\"font-weight: bold;\" ><b>$_maincat[cat_name]</b></option>";

$subcat = $db_object->query("SELECT  * FROM isw_library_categories WHERE  cat_parent=$_maincat[cat_id] AND cat_type='p' ");

	if (DB::isError($subcat)) {
		echo"I can't get main categories";
	}
$num  = $subcat->numRows();
if($num > 0){
for($j=0;$j<$num;$j++){
	$_subcat= $subcat->fetchRow();

print "<option value=\"$_subcat[cat_id]\" selected=\"selected\"> -->$_subcat[cat_name] </option>";

}
}
}

?>

<option value="" selected="selected">-----------------------------------------------------</option>
</select>
<input name="add_category" style="font-weight: bold;" value="Add Category "type="submit">
</form><br><br>
<?}?>
