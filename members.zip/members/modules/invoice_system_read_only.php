<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta content="text/html; charset=ISO-8859-1"
 http-equiv="content-type">
  <title>invicesys</title>
</head>
<body>
<table
 style="margin-left: auto; margin-right: auto; text-align: left; width: 448px; height: 173px;"
 border="0" cellpadding="2" cellspacing="2">
  <tbody>
    <tr>
      <td style="vertical-align: top;"> <span
 style="font-weight: bold; color: rgb(0, 0, 153);">Invoice System
Special Login :</span><br>
      </td>
    </tr>
    <tr>
      <td style="vertical-align: top;">
      <form
 action="http://www.ksdeals.com:80/invoice/coin_includes/session_admin.php"
 method="post" name="login">
        <table
 style="background-color: rgb(153, 255, 153); width: 405px; height: 129px;"
 cellpadding="1" cellspacing="0">
          <tbody>
            <tr>
              <td style="vertical-align: top;"><br>
              </td>
              <td style="vertical-align: top;"><br>
              </td>
            </tr>
            <tr>
              <td class="TP3SML_NR" width="30%"> <b>User Name:&nbsp;</b>
              </td>
              <td class="TP3SML_NL" width="70%"> <input
 readonly="readonly" value="readonly" maxlength="16" size="16"
 name="username" class="PSML_NL"></td>
            </tr>
            <tr>
              <td class="TP3SML_NR" width="30%"> <b>Password:&nbsp;</b>
              </td>
              <td class="TP3SML_NL" width="70%"> <input
 readonly="readonly" value="rea35789" maxlength="16" size="16"
 name="password" class="PSML_NL" type="password"></td>
            </tr>
            <tr>
              <td class="TP3SML_NR" width="30%"> <input name="w"
 value="admin" type="hidden"><input name="o" value="login" type="hidden">
              <input name="op" value="" type="hidden"><br>
              </td>
              <td style="width: 70%;" class="TP3SML_NL"> <input
 name="b_login" id="b_login" class="button_form"
 value="Invoicesys Login"
 onmouseover="setClassName('b_login','button_form_h');"
 onmouseout="setClassName('b_login','button_form');" type="submit"></td>
            </tr>
          </tbody>
        </table>
      </form>
      </td>
    </tr>
  </tbody>
</table>
<br>
<br>
</body>
</html>
