<head>

<style type="text/css">
@import './style/DOMinclude.css';
#g{position:absolute;top:1em;right:1em}
</style>

<script type="text/javascript" 
  src="./scripts/DOMinclude_config.js"></script>
<script type="text/javascript" 
  src="./scripts/DOMinclude.js"></script>


</head>
<br><br>
<div style="text-align: left;">
<? 
$uploaddir="../pics/$_SESSION[userid]/";
$dir="pics/$_SESSION[userid]";

if( $_POST[uploaded]){


//$imagename="$_POST[class_num]";
$imagename.= basename($_FILES['uploadedfile']['name']);


$uploadfile = $uploaddir . $imagename;

if (move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $uploadfile)) {


echo "<A HREF=\"../pics/index.php?pic=$imagename&f=$_SESSION[userid]&return=http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]\" ><img alt=\"Continue\" src=\"../pics/buttons/continue.gif\" style=\"width: 73px;  border: 0px  height: 19px;\"> </A>";


exit;

  echo "<br><b>Image uploaded</b><br><br>";

}else{echo "Image was not copied";}

}
?>
<form enctype="multipart/form-data" action="" method="POST" name="tstest" >
<input size=70 name="uploadedfile" type="file" />
<input type="submit" name="uploaded"  size="70" value="Upload Picture">
<br>
<br>
<b>Current Pictures :</b><br>
<?

//Looks into the directory and returns the files, no subdirectories 
     
//The path to the style directory 
    $dirpath = "$uploaddir"; 
    $dh = opendir($dirpath); 
       while (false !== ($file = readdir($dh))) { 
 //Don't list subdirectories

 
          if (!is_dir("$dirpath/$file") && $file != "." && $file != ".." ) { 

         $_file[]=$file;

	} //end !is_dir
} //end while readdir
     closedir($dh); 
 
 $_file[]=sort($_file);
$count=count($_file);

$halfcount=$count / 2 ;


for($i=0;$i<$halfcount-1;$i++){

$tb_file="tb_$_file[$i]";



echo "<br><br><a href=\"$uploaddir$_file[$i]\" class=\"DOMpop\"><img  src=\"$uploaddir$tb_file\"></a> ";



echo "<br><br>Image Location:<input size=\"60\" type=\"text\" value=\"http://$_SERVER[HTTP_HOST]/$dir/$_file[$i] \" >";

echo "<br>Image Tag:<input size=\"60\" type=\"text\" value=\" &lt;img src=http://$_SERVER[HTTP_HOST]/$dir/$_file[$i]&gt; \">";

echo "<br>Thumbnail Tag:<input size=\"60\" type=\"text\" value=\" &lt;img src=http://$_SERVER[HTTP_HOST]/$dir/tb_$_file[$i]&gt; \" >";

}





?>
</div>