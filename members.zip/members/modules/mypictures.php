<table style="width: 100%; text-align: left;" border="0" cellspacing="2">
<tbody>
<tr>
<td class=tablelinks>
<a href="?content=<? echo "$_GET[content]"; ?>&action=spgm/spgm">My Albums</a> | &nbsp;&nbsp; 
<a href="?content=<? echo "$_GET[content]"; ?>&action=album_management/webmin_v2.0">Albums Management</a> | &nbsp;&nbsp;

</td>
</tr>
<tr>
<td><br></td>
</tr>

<tr>
<td style="vertical-align: top;">




<?

if($_GET[action]){@include("$_GET[action].php");}else{@require("./modules/spgm/spgm.php");}
?>

</td>
</tr>
</tbody>
</table>


