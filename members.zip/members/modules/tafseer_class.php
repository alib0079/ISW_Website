<table style="width: 100%; text-align: left;" border="0" cellspacing="2">
<tbody>
<tr>
<td class=tablelinks>
<a href="?content=<? echo "$_GET[content]"; ?>&action=add_class_questions">Add Class Main Points</a> | &nbsp;&nbsp; 
<a href="?content=<? echo "$_GET[content]"; ?>&action=add_Sumary">Add Sumary</a> | &nbsp;&nbsp;
</td>
</tr>
<tr>
<td><br></td>
</tr>

<tr>
<td style="vertical-align: top;">




<?

if($_GET[action]){@include("tafseer_class/$_GET[action].php");}else{@include("tafseer_class/home.php");}
?>

</td>
</tr>
</tbody>
</table>

