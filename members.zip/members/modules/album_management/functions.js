// for cropping
var x1=x2=y1=y2=imgx=imgy=w=h=-1;
var box;
function crop(e) {
	if(x2>0||y2>0) {
		box.style.visibility = 'hidden';
		document.getElementById('button').disabled = true;
		x1=x2=y1=y2=imgx=imgy=w=h=px=py=-1;
		return false;
	}

	if(imgx==-1&&imgy==-1) {
		obj=document.getElementById('pic');
		while(obj.offsetParent) {
			imgy=obj.offsetTop;
			imgx=obj.offsetLeft;
			obj=obj.offsetParent;
		}
	}

	if(x1==-1&&y1==-1) {
		box=document.getElementById('box');
		x1=e.offsetX?e.offsetX:e.layerX;
		y1=e.offsetY?e.offsetY:e.layerY;
	}
	else {
		x2=e.offsetX?e.offsetX:e.layerX;
		y2=e.offsetY?e.offsetY:e.layerY;

		if(x1>x2) {
			var t=x2;
			x2=x1;
			x1=t;
		}
		if(y1>y2) {
			var t=y2;
			y2=y1;
			y1=t;
		}

		w=x2-x1;
		h=y2-y1;

		box.style.width=(w)+'px';
		box.style.height=(h)+'px';
		box.style.left=(x1+imgx)+'px';
		box.style.top=(y1+imgy)+'px';
		box.style.visibility='visible';

		document.getElementById("x1").value=x1;
		document.getElementById("x2").value=x2;
		document.getElementById("y1").value=y1;
		document.getElementById("y2").value=y2;

		document.getElementById('button').disabled=false;
	}
}

// for resizing
function upd(w, h) {
	var x=Math.ceil(h*(parseInt(document.getElementById('width').value)/w));
	document.getElementById('height').innerHTML=x;
}

// for rotating
function rot(i) {
	var obj=document.getElementById('rotate');
	var x=parseInt(obj.value)+i;
	if(x>3)x-=4;if(x<0)x+=4;
	obj.value=x;
	document.getElementById('rotimg').src='rot'+(x*90)+'.gif';
}