<?php
define('BASE_DIR', './images/uploaded_pics/');       // gallery relative to here, must end with a /
define('MAX_THUMB_WIDTH', 100);      // max width for thumbnails
define('MAX_THUMB_HEIGHT', 100);     // max height for thumbnails
define('MAX_IMAGE_WIDTH', 640);      // max width for displaying image for cropping
define('MAX_IMAGE_HEIGHT', 480);     // max height for displaying image for cropping
define('MAX_UPLOAD_WIDTH', 1024);    // max width for uploaded image, -1 disables
define('MAX_UPLOAD_HEIGHT', 768);    // max height for uploaded image, -1 disables
define('GAL_FILE', 'gal-desc.txt');  // where the gallery descriptions are, default to spgm
define('PIC_FILE', 'pic-desc.txt');  // where the picture descriptions are, default to spgm
define('THUMB_PREFIX', '_thb_');     // thumbnail prefix, _thb_ default to spgm
define('JPG_QUALITY', 75);           // 1-100, typically 75, bigger number = better quality, larger files
define('SORT_TYPE', NAME_ASC);       // NAME_ASC, NAME_DESC, DATE_ASC, DATE_DESC
define('LANG', 'en');                // the language to use for messages

// types to allow, can be more than images, e.g. video add-on for spgm
$pic_extensions = array('gif'=>1, 'png'=>1, 'jpg'=>1);
?>
