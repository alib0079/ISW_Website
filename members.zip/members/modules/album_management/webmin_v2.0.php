<?php
// webmin

// these must be before including settings
define('NAME_ASC', 0);
define('NAME_DESC', 1);
define('DATE_ASC', 2);
define('DATE_DESC', 3);

define('VERSION', 2.0);
error_reporting(E_ALL);

function critical($message) {
	die("<span style=\"color:red;font:9pt/11pt verdana,arial,sans-serif;\">{$message}</span>");
}
//Settting
$useralbum="../pics/$_SESSION[userid]/";

define('BASE_DIR', $useralbum );       // gallery relative to here, must end with a /
define('MAX_THUMB_WIDTH', 100);      // max width for thumbnails
define('MAX_THUMB_HEIGHT', 100);     // max height for thumbnails
define('MAX_IMAGE_WIDTH', 640);      // max width for displaying image for cropping
define('MAX_IMAGE_HEIGHT', 480);     // max height for displaying image for cropping
define('MAX_UPLOAD_WIDTH', 1024);    // max width for uploaded image, -1 disables
define('MAX_UPLOAD_HEIGHT', 768);    // max height for uploaded image, -1 disables
define('GAL_FILE', 'gal-desc.txt');  // where the gallery descriptions are, default to spgm
define('PIC_FILE', 'pic-desc.txt');  // where the picture descriptions are, default to spgm
define('THUMB_PREFIX', '_thb_');     // thumbnail prefix, _thb_ default to spgm
define('JPG_QUALITY', 75);           // 1-100, typically 75, bigger number = better quality, larger files
define('SORT_TYPE', NAME_ASC);       // NAME_ASC, NAME_DESC, DATE_ASC, DATE_DESC
define('LANG', 'en');                // the language to use for messages

// types to allow, can be more than images, e.g. video add-on for spgm
$pic_extensions = array('gif'=>1, 'png'=>1, 'jpg'=>1);









//

if(!function_exists('imagecreatefromjpeg')) critical('The <a href="http://php.net/gd">GD</a> is not installed on this webserver and is required');



// force include of the login module here, if it exists
if(file_exists('login.php')) include('login.php');

// this needs to be defined so that the script can handle this case
$temp = '';
if(($pos = strpos(THUMB_PREFIX, '/')) !== false) $temp = substr(THUMB_PREFIX, 0, $pos);
define('THUMB_DIR', $temp);
define('FUNCTIONS', file_exists('functions.js'));

// a list of all installed modules, modules name=>version
$modules = array();
$nav = array();
$actions = array();

// use %s for dynamic data
$messages = array();

// writeDirDesc():
$messages['en'][0]  = 'Successfully saved gallery description';
$messages['en'][1]  = 'Successfully removed empty gallery description file';
$messages['en'][2]  = 'Error opening gallery description file';
$messages['en'][3]  = 'Error writing gallery description file';
$messages['en'][4]  = 'Error locating directory (%s)';
$messages['en'][5]  = 'Error deleting empty gallery description file';

// writePicDescs():
$messages['en'][6]  = 'Successfully saved picture descriptions';
$messages['en'][7]  = 'Successfully removed empty picture descriptions file';
$messages['en'][8]  = 'Error opening picture descriptions file';
$messages['en'][9]  = 'Error writing picture descriptions file';
$messages['en'][10] = 'Error deleting empty picture descriptions file';

// renderImage():
$messages['en'][11] = 'Error creating resource from image';
$messages['en'][12] = 'Error creating new image resource';
$messages['en'][13] = 'Successfully rendered image';
$messages['en'][14] = 'Error saving resource as image';
$messages['en'][15] = 'Error resampling image resource';

// main:
$messages['en'][16] = 'Error in directory, cannot contain \'..\'';
$messages['en'][17] = 'Successfully deleted image and thumbnail (%s)';
$messages['en'][18] = 'Error deleting thumbnail, image deleted (%s)';
$messages['en'][19] = 'Error deleting image (%s)';
$messages['en'][20] = 'Successfully renamed image and thumbnail (%s)';
$messages['en'][21] = 'Error renaming thumbnail, image renamed (%s)';
$messages['en'][22] = 'Error renaming image (%s)';
$messages['en'][23] = 'Error renaming, file already exists';
$messages['en'][24] = 'Error renaming, file extension not allowed (%s)';
$messages['en'][25] = 'Successfully created directory (%s)';
$messages['en'][26] = 'Error creating directory (%s)';
$messages['en'][27] = 'Create Directory';
$messages['en'][28] = 'Create';
$messages['en'][29] = 'Upload Picture';
$messages['en'][30] = 'Upload';
$messages['en'][31] = 'Rename';
$messages['en'][32] = 'Delete';
$messages['en'][33] = 'Description';
$messages['en'][34] = 'Save';
$messages['en'][35] = 'There are no directories to display';
$messages['en'][36] = 'There are no pictures to display';
$messages['en'][37] = 'Are you sure you wish to delete this item?';
$messages['en'][38] = 'Error uploading picture, file extension not allowed (%s)';
$messages['en'][39] = 'Successfully uploaded the picture';
$messages['en'][40] = 'Error uploading picture';
$messages['en'][41] = 'Size';
$messages['en'][42] = 'Error resizing image, width must be greater than zero';
$messages['en'][43] = 'Resize';
$messages['en'][44] = 'Compress';
$messages['en'][45] = 'Rotate';
$messages['en'][46] = 'Directory Options';
$messages['en'][47] = 'Empty';
$messages['en'][48] = 'Home';
$messages['en'][49] = 'Up';
$messages['en'][50] = 'Cancel';
$messages['en'][51] = 'Successfully deleted directory (%s)';
$messages['en'][52] = 'Error deleting directory (%s)';
$messages['en'][53] = 'Error renaming directory, file already exists';
$messages['en'][54] = 'Error renaming directory';
$messages['en'][55] = 'Successfully renamed directory';
$messages['en'][56] = 'Modified';
$messages['en'][57] = 'Error checking for updates';
$messages['en'][58] = 'You currently have the latest versions';
$messages['en'][59] = '%s is available, <a href="http://www.bluepalmtrees.com/spgm">download</a> them now';
$messages['en'][60] = 'Updates';
$messages['en'][61] = 'Thumbnails';
$messages['en'][62] = 'Successfully created %s thumbnails';
$messages['en'][63] = 'Descriptions';
$messages['en'][64] = 'Crop';
$messages['en'][65] = '(Click twice to highlight the region, click again to reset)';
$messages['en'][66] = 'Error, do not hit the refresh button after cropping, image may be lost';
$messages['en'][67] = 'Error cropping, no region was highlighted';
$messages['en'][68] = 'Installed modules';

// zip module:
$messages['en'][69] = 'Successfully unzipped %s pictures';
$messages['en'][70] = 'Error extracting any of the %s files';
$messages['en'][71] = 'Error unzipping, no files existed';

// upgrade module:
$messages['en'][72] = 'The upgrade completed successfully, please <a href="?content=album_management&">click here</a> to return';
$messages['en'][73] = 'The upgrade failured, please visit <a href="http://www.bluepalmtrees.com/spgm/">here</a> to manually get the latest version';

// filter module:
$messages['en'][74] = 'Filter';
$messages['en'][75] = 'Grayscale';
$messages['en'][76] = 'Brightness';
$messages['en'][77] = 'Contrast';

/******************************** WEBMIN FUNCTIONS ********************************/
// returns a message using language settings
function get($i, $s='') {
	global $messages;
	$lang = LANG;
	if(!isset($messages[LANG][$i])) $lang = 'en';
	return str_replace('%s', $s, $messages[$lang][$i]);
}

// set an error to be displayed later
function error($i, $s='') {
	global $errors;
	$errors[$i] = get($i, $s);
}

// set a success message to be displayed later
function success($i, $s='') {
	global $success;
	$success[$i] = get($i, $s);
}

// returns a description for the directory supplied
function getDirDesc($dir) {
	$dir = BASE_DIR.$dir;
	if(!file_exists($dir.GAL_FILE)) return '';
	return file_get_contents($dir.GAL_FILE);
}

// write the description for the current directory
function writeDirDesc($dir, $data) {
	$dir = BASE_DIR.$dir;
	if(!is_dir($dir)) return error(4, $dir);
	if($data == '') {
	  	if(!@unlink($dir.GAL_FILE)) return error(5);
		else success(1);
	}
	else {
		$fd = @fopen($dir.GAL_FILE, 'w');
		if(!$fd) return error(2);
		$ret = fwrite($fd, $data);
  		fclose($fd);
		if(!ret) error(3);
		else success(0);
	}
}

// returns an array of the descriptions of all images in a directory
function getPicDescs($dir) {
	$data = array();
	$dir = BASE_DIR.$dir;
	if(!file_exists($dir.PIC_FILE)) return $data;
	$temp = explode("\n", trim(file_get_contents($dir.PIC_FILE)));
	foreach($temp as $line) {
		$line = explode('|', $line);
		$data[trim($line[0])] = trim($line[1]);
	}
	return $data;
}

// write the descriptions of the images to file
function writePicDescs($dir, $data) {
	$dir = BASE_DIR.$dir;
	if(!is_dir($dir)) return error(4, $dir);

	$desc = '';
	foreach($data as $key=>$value)
		if($value != '' && file_exists($dir.$key)) $desc .= "{$key}|{$value}\n";
	$desc = trim($desc);
	if($desc == '') {
		if(file_exists($dir.PIC_FILE)) {
			if(!@unlink($dir.PIC_FILE)) error(10);
			else success(7);
		}
	}
	else {
		$fd = @fopen($dir.PIC_FILE, 'w');
		if(!$fd) return error(8);
		if(fwrite($fd, $desc)) success(6);
		else error(9);
		fclose($fd);
	}
}

// returns the file extension
function getExt($name) {
	if(strstr($name, '.')) return strtolower(str_replace('.', '', strrchr($name, '.')));
	else return '';
}

// translates directory names so all webservers can handle them
function trname($name) {
	global $pic_extensions;
	$name = strtr($name, '������������������������������', 'aaaiioouuueeeecAAAIIOOOUUUEEEE');
	$ext = getExt($name);
	if(isset($pic_extensions[$ext])) $name = substr($name, 0, strlen($name)-strlen($ext)-1);
	else $ext = '';
	$name = eregi_replace('[^A-Za-z0-9-]', '_', $name);
	if($ext != '') $name .= ".{$ext}";
	return $name;
}

// returns a size in human readable format
function getSize($size) {
	$suffixes = array('Bytes', 'KB', 'MB', 'GB', 'TB', 'PB');
	$i = 0;
	while($size >= 1024) {
		$size /= 1024;
		$i++;
	}
	return number_format($size, 2).' '.$suffixes[$i];
}

// returns the current directory from the dir string
function getCurrDir($dir) {
	if(substr($dir, -1) == '/') $dir = substr($dir, 0, strlen($dir)-1);
	$pos = strrpos($dir, '/');
	if($pos !== false) return substr($dir, $pos+1);
	else return $dir;
}

// removes the previous directory from the dir string
function getPrevDir($dir) {
	if(substr($dir, -1) == '/') $dir = substr($dir, 0, strlen($dir)-1);
	$pos = strrpos($dir, '/');
	if($pos !== false) return substr($dir, 0, $pos).'/';
	else return '';
}

// deletes all the contents of a directory, recursively
function empty_dir($dir) {
 	if(substr($dir, -1) != '/') $dir .= '/';
	$link = opendir(BASE_DIR.$dir);
	while($item=readdir($link)) {
		if(is_dir(BASE_DIR.$dir.$item) && $item != '.' && $item != '..') empty_dir($dir.$item);
		else @unlink(BASE_DIR.$dir.$item);
	}
	closedir($link);
}

// date compare algorithm for arranging the directories and pictures
function dateCmp($a, $b) {
	if($a[1] == $b[1]) return 0;
	return ($a[1] < $b[1]) ? -1 : 1;
}

// sorts, allows for sorting by filename and date, forward and reverse
function arrange($data, $type) {
	switch($type) {
		case NAME_DESC:
			rsort($data);
	  		break;
		case DATE_ASC:
			usort($data, 'dateCmp');
			break;
		case DATE_DESC:
			usort($data, 'dateCmp');
			$data = array_reverse($data);
			break;
		case NAME_ASC:
		default:
			sort($data);
	}
	return $data;
}

/******************************** IMAGE FUNCTIONS ********************************/
// handles image opening and error handling
function openim($pic) {
	$ext = getExt($pic);
	if($ext == 'jpg') $im = imagecreatefromjpeg($pic);
	elseif($ext == 'png') $im = imagecreatefrompng($pic);
	elseif($ext == 'gif') $im = imagecreatefromgif($pic);
	if($im) return $im;
  	error(11);
  	return false;
}

// saves image and error handling
function saveim($im, $name) {
	$ext = getExt($name);
	if($ext == 'jpg') $ret = imagejpeg($im, $name, JPG_QUALITY);
	elseif($ext == 'png') $ret = imagepng($im, $name);
	else $ret = imagegif($im, $name);

	if($ret) success(13);
	else error(14);
}

// create a new image based on parameters supplied, used for all image functions
function renderImage($dir, $pic, $dest, $sx, $sy, $dw, $dh, $sw, $sh) {
	$im = openim($dir.$pic);
	if(!$im) return;

	$new = imagecreatetruecolor(round($dw), round($dh));
	if(!$new) return error(12);

	if(imagecopyresampled($new, $im, 0, 0, round($sx), round($sy), round($dw), round($dh), round($sw), round($sh)))
		saveim($new, $dir.$dest);
	else error(15);
	imagedestroy($im);
	imagedestroy($new);
}

// returns the height and width that should be based on the actual max height and width provided
function getDim($x, $y, $maxw, $maxh) {
	if($x <= $maxw && $y <= $maxh) $dim = array($x, $y, 1);
	else {
		$factor = max(array($x / $maxw, $y / $maxh));
		$dim = array(ceil($x / $factor), ceil($y / $factor), $factor);
	}
	return $dim;
}

// creates a thumbnail for an image if one doesn't already exist
function create_thumb($dir, $img) {
	if(substr($dir, -1) != '/') $dir .= '/';
	if(file_exists($dir.THUMB_PREFIX.$img)) return false;

	$dim = getimagesize($dir.$img);
	$thumb = getDim($dim[0], $dim[1], MAX_THUMB_WIDTH, MAX_THUMB_HEIGHT);

	// create the thumb directory if used and non-existant
	if(THUMB_DIR != '') {
		if(!file_exists($dir.THUMB_DIR)) {
			mkdir($dir.THUMB_DIR);
			chmod($dir.THUMB_DIR, 0777);
		}
	}

	renderImage($dir, $img, THUMB_PREFIX.$img, 0, 0, $thumb[0], $thumb[1], $dim[0], $dim[1]);
	return true;
}

// recursively builds thumbnails for all images
function build_thumbs($dir=BASE_DIR) {
	global $pic_extensions;
 	$total = 0;
 	if(substr($dir, -1) != '/') $dir .= '/';
	$link = opendir($dir);
	while($item = readdir($link)) {
		if(is_dir($dir.$item) && $item != '.' && $item != '..' && $item != THUMB_DIR)
			$total += build_thumbs($dir.$item);
		else {
			$ext = getExt($item);
			$pre = substr($item, 0, strlen(THUMB_PREFIX));
			if(isset($pic_extensions[$ext]) && $pre != THUMB_PREFIX) {
				if(create_thumb($dir, $item)) $total++;
			}
		}
	}
	closedir($link);
	return $total;
}

// resizes the image, constrained to width
function resizeImage($dir, $pic, $w) {
	if($w < 1) return error(42);
	$dim = getimagesize($dir.$pic);
	if($w == $dim[0]) return;

	$factor = $dim[0] / $w;
	$h = round($dim[1] / $factor);
	renderImage($dir, $pic, $pic, 0, 0, $w, $h, $dim[0], $dim[1]);
}

// rotate the image by factors of 90 degrees
function rotateImage($dir, $pic, $angle) {
	if($angle == 0 || $angle > 3) return;

	$angle = abs(($angle * 90) - 360);
	$im = openim($dir.$pic);
	if(!$im) return;

	$rotate = imagerotate($im, $angle, 0);
	if(!$rotate) return error(12);

	unlink($dir.THUMB_PREFIX.$pic);
	saveim($rotate, $dir.$pic);

	imagedestroy($im);
	imagedestroy($rotate);
}

/******************************** VARIABLE SETUP ********************************/
$errors = array();
$success = array();

$dir = '';
if(isset($_GET['dir'])) $dir = $_GET['dir'];
if(substr($dir, -1) != '/') $dir .= '/';
if($dir == '/') $dir = '';
if(strpos($dir, '..') !== false) {
	error(16);
	$dir = '';
}
$img = '';
if(isset($_GET['img'])) $img = $_GET['img'];

$apply = '';
if(isset($_GET['apply'])) $apply = $_GET['apply'];

$data = getPicDescs($dir);

// dynamically loadable modules and language packs
if($list = opendir('.')){
	while($item = readdir($list)){
		$ext = getExt($item);
		$pre = strtolower(substr($item, 0, 4));
		if($ext == 'php' && $pre == 'inc_') include($item);
	}
	closedir($list);
}

/******************************** APPLY CHANGES ********************************/
if($apply == 'img') { // image changes
	if(isset($_GET['delete'])) {
		$file  = BASE_DIR.$dir.$img;
		$thumb = BASE_DIR.$dir.THUMB_PREFIX.$img;
		if(@unlink($file)) {
			unset($data[$img]);
			if(file_exists($thumb)) {
				if(@unlink($thumb)) success(17, $img);
				else error(18, $img);
			}
			$img = '';
		}
		else error(19, $img);
	} // end delete
	else {
		// rename if needed
		$name = $img;
		if(isset($_GET['name'])) $name = trname($_GET['name']);
	  	if($name != $img) {
			$file = BASE_DIR.$dir.$name;
			$ext  = getExt($name);

			if(!isset($pic_extensions[$ext])) error(24, $ext);
			elseif(file_exists($file)) error(23);
			elseif(!@rename(BASE_DIR.$dir.$img, $file)) error(22, $img);
			else {
				if(isset($data[$img])) {
				  	$data[$name] = $data[$img];
					unset($data[$img]);
				}

				if(@rename(BASE_DIR.$dir.THUMB_PREFIX.$img, BASE_DIR.$dir.THUMB_PREFIX.$name)) {
					$img = $name;
					success(20, $img);
				}
				else error(21, $img);
			}
		} // end rename file

		// set the new description
		if(isset($_GET['desc'])) $data[$img] = stripslashes($_GET['desc']);
		if(isset($_GET['width'])) resizeImage(BASE_DIR.$dir, $img, $_GET['width']);
		if(isset($_GET['rotate'])) rotateImage(BASE_DIR.$dir, $img, $_GET['rotate']);
		if(isset($_GET['compress']) && getExt($img) == 'jpg') {
			$dim = getimagesize(BASE_DIR.$dir. $img);
			renderImage(BASE_DIR.$dir, $img, $img, 0, 0, $dim[0], $dim[1], $dim[0], $dim[1]);
		}

		$img = '';
	} // end changes

	// now that everything is done, write the descriptions
	writePicDescs($dir, $data);
}
elseif($apply == 'dir') { // directory changes
	if(isset($_GET['delete'])) {
		if(isset($_GET['empty'])) empty_dir($dir);
		if(!@rmdir(BASE_DIR.$dir)) error(52, $dir);
		else {
  			success(51, $dir);
  			$dir = getPrevDir($dir);
		}
	} // end delete
	else {
		// rename if needed
		$name = $dir;
		if(isset($_GET['name'])) $name = trname($_GET['name']);

		if(substr($name, -1) == '/') $name = substr($name, 0, strlen($name)-1);
	  	if($name != getCurrDir($dir)) {
			$prev = getPrevDir($dir);
			if(file_exists($prev.$name)) error(53);
			elseif(!@rename(BASE_DIR.$dir, BASE_DIR.$prev.$name)) error(54);
			else {
				success(55);
				$dir = $prev.$name.'/';
			}
		} // end rename dir

		// write the new description
		$desc = '';
		if(isset($_GET['desc'])) $desc = $_GET['desc'];
		writeDirDesc($dir, stripslashes($desc));
	} // end changes
}
elseif($apply == 'batch') { // add descriptions for all images
	$list = opendir(BASE_DIR.$dir);
	if($list) {
		while($item = readdir($list)) {
			if(!is_dir(BASE_DIR.$dir.$item)) {
				$ext = getExt($item);
				$pre = substr($item, 0, strlen(THUMB_PREFIX));
				if(isset($pic_extensions[$ext]) && $pre != THUMB_PREFIX)
					$data[$item] = stripslashes($_POST[str_replace('.', '_', $item)]);
			}
		}
		closedir($list);
		writePicDescs($dir, $data);
	}
}
elseif($apply == 'crop') { // crop the image if values set
	if(!isset($_GET['x1']) || !isset($_GET['x2']) || !isset($_GET['y1']) || !isset($_GET['y2']) || !isset($_GET['factor']))
		error(67);
	else {
		$factor = $_GET['factor'];
		$x1 = $_GET['x1'] * $factor;
		$y1 = $_GET['y1'] * $factor;
		$x2 = $_GET['x2'] * $factor;
		$y2 = $_GET['y2'] * $factor;
		$dim = getimagesize(BASE_DIR.$dir.$img);
		if($x2 > $dim[0] || $y2 > $dim[1]) error(66);
		else {
			$w = $x2 - $x1;
			$h = $y2 - $y1;

			renderImage(BASE_DIR.$dir, $img, $img, $x1, $y1, $w, $h, $w, $h);
			if(file_exists(BASE_DIR.$dir.THUMB_PREFIX.$img)) @unlink(BASE_DIR.$dir.THUMB_PREFIX.$img);
		}
	}
}

// create new directory
if(isset($_GET['newdir'])) {
	$name = trname($_GET['newdir']);
	if(!mkdir(BASE_DIR.$dir.$name)) error(26, $name);
	else {
		chmod(BASE_DIR.$dir.$name, 0777);
		success(25, $name);
	}
}

// upload new picture
if(isset($_FILES['newpic']) && $_FILES['newpic']['name'] != '') {
	set_time_limit(300);
	$ext = getExt($_FILES['newpic']['name']);

	// rather than attempting to deal with many jpg extensions, normalize them
	if($ext == 'jpeg') {
	  	$ext = 'jpg';
	  	$_FILES['newpic']['name'] = substr($_FILES['newpic']['name'], 0, strlen($_FILES['newpic']['name'])-4).$ext;
	}

	if(!isset($pic_extensions[$ext])) error(38, $ext);
	else {
		$name = trname($_FILES['newpic']['name']);
		$name = substr($name, 0, strlen($name)-4);
		$file = BASE_DIR.$dir.$name;

		// if the filename exists, find a new name, we already paid the penalty of an upload, may as well keep it
		if(file_exists($file.".{$ext}")) {
			$x = 0;
			while(file_exists($file."_{$x}{$ext}")) $x++;
			$file .= "_{$x}";
			$name .= "_{$x}";
		}
		$file .= ".{$ext}";
		$name .= ".{$ext}";

		if(move_uploaded_file($_FILES['newpic']['tmp_name'], $file)) {
			chmod($file, 0777);
			success(39);

			// if the auto resize variable are set, constrain the uploaded image dimensions
			if(MAX_UPLOAD_WIDTH > 0 && MAX_UPLOAD_HEIGHT > 0) {
				$dim = getimagesize($file);
				$new = getDim($dim[0], $dim[1], MAX_UPLOAD_WIDTH, MAX_UPLOAD_HEIGHT);
				renderImage(BASE_DIR.$dir, $name, $name, 0, 0, $new[0], $new[1], $dim[0], $dim[1]);
			}
		}
		else error(40);
	}
}

// check if there is a newer version of webministration or modules
if(isset($_GET['check'])) {
	$fd = @fopen('http://www.bluepalmtrees.com/spgm/versions.txt', 'r');
	if(!$fd) error(57);
	else {
		$ver = '';
		while(!feof($fd)) $ver .= fread($fd, 1024);
		fclose($fd);
		if($ver == '') error(57);
		else {
			$versions = array();
			$updates = '';

			$ver = explode("\n", $ver);
			foreach($ver as $value) {
				$value = explode('|', $value);
				$versions[$value[0]] = $value[1];
			}

			// if the upgrade module is installed, everything is auto-upgradable
			$upgradable = isset($modules['upgrade']);

			// check if the main script is new
			if($versions['main'] > VERSION) {
				if($upgradable) $updates .= '<a href="?content=album_management&upgrade=main">';
			  	$updates .= 'Main v'.number_format($versions['main'], 1);
			  	if($upgradable) $updates .= '</a>';
			}

			// now check for updates for all the installed modules
			foreach($modules as $mod=>$ver) {
				if(isset($versions[$mod]) && $versions[$mod] > $ver) {
					if($updates != '') $updates .= ', ';
					if($upgradable) $updates .= "<a href=\"?content=album_management&upgrade={$mod}\">";
					$updates .= "{$mod} v".number_format($versions[$mod], 1);
					if($upgradable) $updates .= '</a>';
				}
			}

			// if nothing is new...
			if($updates == '') success(58);
			else success(59, $updates);
		}
	}
}

// recursively build thumbnails for all directories
if(isset($_GET['build'])) success(62, build_thumbs());
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
	<title>SPGM Webministration</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8"/>
	<style type="text/css">
		
		div.nav a{padding-left:5px;padding-right:5px;}
		form{margin:0px;}
		h1,h1 a{font-size:18px;}
		hr{height:1px;width:90%;color:black;background-color:black;}
		img{border:0;padding:3px;}
		td{vertical-align:top;}
		.right{text-align:right;}
	</style>
<?php
if(FUNCTIONS) echo "\t<script type=\"text/javascript\" src=\"functions.js\"></script>\n";
?>
</head>
<body>
<?php
// navigation
echo "<div class=\"nav\">\n";
echo "\t<a href=\"?content=album_management&\">".get(48)."</a>\n";
if($dir != '') echo "\t<a href=\"?content=album_management&dir=".getPrevDir($dir)."\">".get(49)."</a>\n";
if($img != '' || isset($_GET['batch'])) echo "\t<a href=\"?content=album_management&dir={$dir}\">".get(50)."</a>\n";
echo "\t<a href=\"?content=album_management&dir={$dir}&amp;img={$img}&amp;check=1\">".get(60)."?</a>\n";
echo "\t<a href=\"?content=album_management&dir={$dir}&amp;img={$img}&amp;build=1\">".get(61)."...</a>\n";
if($dir != '') echo "\t<a href=\"?content=album_management&dir={$dir}&amp;batch=1\">".get(63)."</a>\n";
if($img != '' && FUNCTIONS) echo "\t<a href=\"?content=album_management&dir={$dir}&amp;img={$img}&amp;crop=1\">".get(64)."</a>\n";
foreach($nav as $entry) echo "\t{$entry}\n"; // add on module's navigation
echo "</div>\n";

// report any errors or successes
if(count($errors) > 0) {
	echo "<div style=\"border:1px solid #8b0000;background-color:#ffccff;margin:2px;padding:2px\">\n";
	foreach($errors as $id=>$message) echo "~{$id}: {$message}<br/>\n";
	echo "</div>\n";
}

if(count($success) > 0) {
	echo "<div style=\"border:1px solid #008000;background-color:#ccffcc;margin:2px;padding:2px\">\n";
	foreach($success as $id=>$message) echo "~{$id}: {$message}<br/>\n";
	echo "</div>\n";
}
?>
<table cellpadding="5" cellspacing="0" style="width:100%">
	<tr>
		<td style="width:200px">
			<form method="get" action=""><div>
	                  <? echo "\t\t\t\t<input type=\"hidden\" name=\"content\" value=\"album_management\"/>\n"; ?>
				<input type="hidden" name="dir" value="<?php echo $dir; ?>"/>
				<?php echo get(27); ?>:<br/><input name="newdir"/><br/>
				<input type="submit" value="<?php echo get(28); ?>"/><br/><br/>
			</div></form>
<?php
if($dir != '') {
?>
			<form enctype="multipart/form-data" method="post" action="?content=album_management&dir=<?php echo $dir; ?>"><div>
				<?php echo get(29); ?>:<br/><input type="file" name="newpic"/><br/>
				<input type="submit" value="<?php echo get(30); ?>"/><br/><br/>
			</div></form>

			<a href="#" onclick="document.getElementById('diropts').style.display='inline';this.style.display='none';"><?php echo get(46); ?></a>
			<div id="diropts" style="display:none">
				<form method="get" action=""><div>
                              <? 	echo "\t\t\t\t<input type=\"hidden\" name=\"content\" value=\"album_management\"/>\n"; ?>
					<input type="hidden" name="apply" value="dir"/>
					<input type="hidden" name="dir" value="<?php echo $dir; ?>"/>
					<?php echo get(31); ?>: <input name="name" value="<?php echo str_replace('_', ' ', getCurrDir($dir)); ?>" style="width:125px"/><br/>
					<?php echo get(33); ?>:<br/><textarea name="desc" rows="4" cols="24"><?php echo getDirDesc($dir); ?></textarea><br/>
					<label for="dirdelete"><input type="checkbox" name="delete" id="dirdelete" value="1" onclick="document.getElementById('empty').disabled=!this.checked;"/> <?php echo get(32); ?>?</label>
					<label for="empty"><input type="checkbox" name="empty" id="empty" value="1" disabled="disabled"/> <?php echo get(47); ?>?</label><br/>
					<input type="submit" value="<?php echo get(34); ?>" onclick="if(document.getElementById('dirdelete').checked) return window.confirm('<?php echo get(37); ?>');"/>
				</div></form>
			</div><br/>
<?php
}

// show all the modules installed
if(count($modules) > 0) {
	echo "\t\t\t<a href=\"#\" onclick=\"document.getElementById('mods').style.display='inline';this.style.display='none';\">".get(68)."</a>\n";
	echo "\t\t\t<div id=\"mods\" style=\"display:none\">\n";
	foreach($modules as $mod=>$ver) echo "\t\t\t\t{$mod} v".number_format($ver, 1)."<br/>\n";
	echo "\t\t\t</div>\n";
}
?>
		</td><td style="border-left:1px solid black;width:100%">
<?php
if(isset($_GET['crop']) && FUNCTIONS) {
	$dim = getimagesize(BASE_DIR.$dir.$img);
	$dim = getDim($dim[0], $dim[1], MAX_IMAGE_WIDTH, MAX_IMAGE_HEIGHT);
	echo "\t\t<form method=\"get\" action=\"\"/><div>\n";
	echo "\t\t\t<input type=\"hidden\" name=\"dir\" value=\"{$dir}\"/>\n";
      echo "\t\t\t\t<input type=\"hidden\" name=\"content\" value=\"album_management\"/>\n";
	echo "\t\t\t<input type=\"hidden\" name=\"img\" value=\"{$img}\"/>\n";
	echo "\t\t\t<input type=\"hidden\" name=\"apply\" value=\"crop\"/>\n";
	echo "\t\t\t<input type=\"hidden\" name=\"x1\" id=\"x1\"/>\n";
	echo "\t\t\t<input type=\"hidden\" name=\"y1\" id=\"y1\"/>\n";
	echo "\t\t\t<input type=\"hidden\" name=\"x2\" id=\"x2\"/>\n";
	echo "\t\t\t<input type=\"hidden\" name=\"y2\" id=\"y2\"/>\n";
	echo "\t\t\t<input type=\"hidden\" name=\"factor\" value=\"".$dim[2]."\"/>\n";
	echo "\t\t\t<input type=\"submit\" id=\"button\" value=\"".get(64)."\" disabled=\"disabled\"/> ".get(65)."\n";
	echo "\t\t</div></form>\n";
	echo "\t\t<div id=\"box\" style=\"background-image:url('area.gif');position:absolute;visibility:hidden;width:0px;height:0px;border:1px solid #006;z-index:500;\"></div>\n";
	echo "\t\t<div id=\"pic\" style=\"margin:0px;padding:0px;position:relative;height:1%;\">\n";
	echo "\t\t\t<img src=\"".BASE_DIR."{$dir}{$img}?time=".time()."\" alt=\"\" id=\"cropPic\" style=\"position:relative;\" onmousedown=\"crop(event);\" width=\"".$dim[0]."\" height=\"".$dim[1]."\"/>\n";
	echo "\t\t</div>\n";
} // end crop
elseif($img != '') {
	create_thumb(BASE_DIR.$dir, $img);

	$size = filesize(BASE_DIR.$dir.$img);
	$dim = getimagesize(BASE_DIR.$dir.$img);
	$ext = getExt($img);

	echo "\t\t\t<form method=\"get\" action=\"\"><div>\n";
	echo "\t\t\t\t<input type=\"hidden\" name=\"dir\" value=\"{$dir}\"/>\n";
	echo "\t\t\t\t<input type=\"hidden\" name=\"content\" value=\"album_management\"/>\n";
	echo "\t\t\t\t<input type=\"hidden\" name=\"img\" value=\"{$img}\"/>\n";
	echo "\t\t\t\t<input type=\"hidden\" name=\"apply\" value=\"img\"/>\n";
	echo "\t\t\t\t<a href=\"".BASE_DIR."{$dir}{$img}\"><img src=\"".BASE_DIR."{$dir}".THUMB_PREFIX."{$img}?time=".time()."\" alt=\"{$img}\"/></a><br/>\n";
	echo "\t\t\t\t<table>\n";
	echo "\t\t\t\t\t<tr><td class=\"right\">".get(31).":</td><td><input name=\"name\" value=\"".str_replace('_', ' ', $img)."\" style=\"width:150px\"/></td></tr>\n";
	echo "\t\t\t\t\t<tr><td class=\"right\"><label for=\"delete\">".get(32)."?</label></td><td><input type=\"checkbox\" id=\"delete\" name=\"delete\" value=\"1\"/></td></tr>\n";
	echo "\t\t\t\t\t<tr><td class=\"right\">".get(33).":</td><td><input name=\"desc\"".(isset($data[$img]) ? " value=\"".$data[$img]."\"" : '')." style=\"width:350px\"/></td></tr>\n";

	echo "\t\t\t\t\t<tr><td class=\"right\">".get(43)."</td><td><input name=\"width\" id=\"width\" value=\"".$dim[0]."\" style=\"width:40px\"";
	if(FUNCTIONS) echo " onkeyup=\"upd(".$dim[0].", ".$dim[1].");\"";
	echo "/>x<span id=\"height\">".$dim[1]."</span></td></tr>\n";

	if(FUNCTIONS) {
  		echo "\t\t\t\t\t<tr><td class=\"right\">".get(45)."</td><td><input type=\"hidden\" name=\"rotate\" id=\"rotate\" value=\"0\"/>";
 		echo "<a href=\"#\" onclick=\"rot(-1);\">&lt;-</a> <img src=\"rot0.gif\" id=\"rotimg\" alt=\"\"/> <a href=\"#\" onclick=\"rot(1);\">-&gt;</a></td></tr>\n";
	}

	if($ext == 'jpg') {
		$pixels = $dim[0] * $dim[1];
		$ratio  = $pixels / $size;
		if(($pixels > 65536 && $ratio < 4.5) || ($pixels > 16384 && $ratio < 3) || ($pixels > 1024 && $ratio < 1.5) || $ratio < 0.9)
	  		echo "\t\t\t\t\t<tr><td class=\"right\"><label for=\"compress\">".get(44)."</label></td><td><input type=\"checkbox\" name=\"compress\" id=\"compress\" value=\"1\"/></td></tr>\n";
 	}
	echo "\t\t\t\t\t<tr><td class=\"right\">".get(41).":</td><td>".getSize($size).", ".number_format(($dim[0] * $dim[1]) / $size, 2)." px/byte</td></tr>\n";
	echo "\t\t\t\t\t<tr><td class=\"right\">".get(56).":</td><td>".date('j F Y', filemtime(BASE_DIR.$dir.$img))."</td></tr>\n";

	// anything from addon modules
	foreach($actions as $value) echo "\t\t\t\t\t<tr><td class=\"right\">".$value[0]."</td><td>".$value[1]."</td></tr>\n";

	echo "\t\t\t\t</table>\n";
	echo "\t\t\t\t<input type=\"submit\" value=\"".get(34)."\" onclick=\"if(document.getElementById('delete').checked) return window.confirm('".get(37)."');\"/>\n";
	echo "\t\t\t</div></form>\n";
} // end if $img
elseif(isset($_GET['batch'])) {
	$list = opendir(BASE_DIR.$dir);
	echo "\t\t\t<form method=\"post\" action=\"?content=album_management&dir={$dir}&amp;apply=batch\"><div>\n";
	if($list) {
		while($item = readdir($list)) {
			if(!is_dir(BASE_DIR.$dir.$item)) {
				$ext = getExt($item);
				$pre = substr($item, 0, strlen(THUMB_PREFIX));
				if(isset($pic_extensions[$ext]) && $pre != THUMB_PREFIX) {
					echo "\t\t\t\t<img src=\"".BASE_DIR.$dir.THUMB_PREFIX."{$item}\" alt=\"{$item}\"/>\n";
					echo "\t\t\t\t<input name=\"".str_replace('.', '_', $item)."\"";
					if(isset($data[$item])) echo " value=\"".htmlentities($data[$item])."\"";
					echo " style=\"width:350px\"/><br/>\n";
				}
			}
		}
		closedir($list);
	}
	echo "\t\t\t\t<input type=\"submit\" value=\"".get(34)."\"/>\n";
	echo "\t\t\t</div></form>\n";
} // end if batch
else {
	// get and sort all the directories
	unset($items);
	$items = array();
	$list = opendir(BASE_DIR.$dir);
	if($list) {
		while($item = readdir($list)) {
			if(is_dir(BASE_DIR.$dir.$item) && $item != '.' && $item != '..' && $item != THUMB_DIR)
				$items[] = array($item, filemtime(BASE_DIR.$dir.$item));
		}
		closedir($list);
	}
	$items = arrange($items, SORT_TYPE);

	// display all the directories and their descriptions
	foreach($items as $item) {
		echo "\t\t\t<a href=\"?content=album_management&dir={$dir}".$item[0]."\">".str_replace('_', ' ', $item[0])."</a>";
		$desc = getDirDesc($dir.$item[0].'/');
		if($desc != '') echo " - {$desc}";
		echo "<br/>\n";
	}
	if(count($items) > 0 && $dir != '') echo "\t\t\t<hr/>\n";
	if(count($items) == 0 && $dir == '') echo "\t\t\t".get(35)."\n";

	if($dir != '') {
		echo "\t\t\t".str_replace('_', ' ', getCurrDir($dir));
		$desc = getDirDesc($dir);
		if($desc != '') echo " - {$desc}";
		echo "<br/>\n";
	}

	// get and sort all the images in this directory
	unset($items);
	$items = array();
	$list = opendir(BASE_DIR.$dir);
	if($list) {
		while($item = readdir($list)) {
			if(!is_dir(BASE_DIR.$dir.$item)) {
				$ext = getExt($item);
				$pre = substr($item, 0, strlen(THUMB_PREFIX));
				if(isset($pic_extensions[$ext]) && $pre != THUMB_PREFIX)
					$items[] = array($item, filemtime(BASE_DIR.$dir.$item));
			}
		}
		closedir($list);
	}
	$items = arrange($items, SORT_TYPE);

	// display all the images in this directory
	foreach($items as $item) {
		if(strpos($item[0], ' ')) @rename(BASE_DIR.$dir.$item[0], BASE_DIR.$dir.str_replace(' ', '_', $item[0]));
		create_thumb(BASE_DIR.$dir, $item[0]);
		echo "\t\t\t<a href=\"?content=album_management&dir={$dir}&amp;img=".$item[0]."\"><img src=\"".BASE_DIR.$dir.THUMB_PREFIX.$item[0]."?time=".time()."\" alt=\"".$item[0]."\"/></a>\n";
	}
	if(count($items) == 0 && $dir != '') echo "\t\t\t\t\t\t".get(36)."\n";
} // end else
?>
		</td>
	</tr>
</table>
</body>
</html>
