
<table align="center" bgcolor="#ffffff" border="0" cellpadding="0"
 cellspacing="0" width="740">
  <tbody>
    <tr>
      <td>
      <form target="new"  name="form1" id="form1" method="post" action="http://www.islamicsocietyofwichita.com/modules/calendar1/events/index.php"> <br>
        <table class="setupHeaders" align="center" border="0"
 cellpadding="4" cellspacing="0" width="216">
          <tbody>
            <tr>
              <td><b>Event Manager</b> </td>
            </tr>
          </tbody>
        </table>
        <table class="formBoxBorder" align="center" border="0"
 cellpadding="6" cellspacing="0" width="216">
          <tbody>
            <tr>
              <td rowspan="2" align="center" valign="middle"><img
 src="http://www.islamicsocietyofwichita.com/pics/icons/loginUsers.gif" height="60" width="60"></td>
              <td width="120"> User Name: <input  readonly="readonly" value="<? echo "$username";?>"
 name="name" class="formElements">
              <script type="text/javascript">
      document.form1.name.focus();
      </script>
              </td>
            </tr>
            <tr>
              <td> Password:
              <input readonly="readonly" value="<? echo "$password";?>" name="pwd" class="formElements"
 type="password"><input name="dataMode" id="dataMode" value="s"
 type="hidden"> </td>
            </tr>
            <tr align="center">
              <td>&nbsp; </td>
              <td align="left"> <input name="Submit"
 class="formButtons" value="Log In" type="submit"> </td>
            </tr>
          </tbody>
        </table>
        <br>
        <br>
      </form>
      </td>
    </tr>
  </tbody>
</table>
