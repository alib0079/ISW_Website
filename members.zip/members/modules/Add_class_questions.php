<?
if( $_POST[file_uploaded] AND $_POST[slide_num]){


$uploaddir="../wiki/slide_shows/tafseer_class/";
$imagename="$_POST[slide_num]";
//$imagename.= basename($_FILES['uploadedfile']['name']);


$uploadfile = $uploaddir . $imagename;




if (move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $uploadfile)) {

  echo "<br><b>The slide # $_POST[slide_num] was uploaded</b><br><br>";

}else{echo "Image was not copied";}

}
?>


<form enctype="multipart/form-data" action="" method="POST">

<input type="hidden" name="file_uploaded" value="true" >

<input type="hidden" name="slide_name" value="<? echo "$_GET[content]";?>" >
<table style="width: 100%; text-align: left;" border="1" cellpadding="2"
cellspacing="0">
<tbody>

<tr>
<td style="vertical-align: top;">
<b>Class # </b><input type="text" name="slide_num" size="2" value="" >
</td>
<td style="vertical-align: top;">
<b> Soura : </b><input type="text" name="slide_num" size="20" value="" >
</td>
<td style="vertical-align: top;">
<b>Title:</b><input type="text" name="slide_num" size="50" value="" >
</td>
</tr>
</tbody>
</table>
<table style="width: 100%; text-align: left;" border="1" cellpadding="2"
cellspacing="0">
<tr>
<td style="vertical-align: top;"><b>Upload a text or html file only:</b><br>
<input size=70 name="uploadedfile" type="file" />
<input type="submit" name="uploaded"  size="70" value="Upload File">
</td>
</tr>


</table>
</form> 

