<table style="width: 100%; text-align: left;" border="0" cellspacing="2">
<tbody>
<tr>
<td class=tablelinks>
<a href="?content=<? echo "$_GET[content]"; ?>&action=view_content&change_cat=true">View Content</a> | &nbsp;&nbsp;
<a href="?content=<? echo "$_GET[content]"; ?>&action=add_content&change_cat=true">Add Content</a> | &nbsp;&nbsp; 
<a href="?content=<? echo "$_GET[content]"; ?>&action=add_category&change_cat=true">Add Category</a> | &nbsp;&nbsp;
</td>
</tr>
<tr>
<td><br></td>
</tr>

<tr>
<td style="vertical-align: top;">




<?

if($_GET[action]){@include("electronic_library_management/$_GET[action].php");}else{@include("electronic_library_management/home.php");}
?>

</td>
</tr>
</tbody>
</table>

