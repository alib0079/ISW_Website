<br><br>
<form target="_blank" name="form2" id="form2" action="http://www.almars.net/login/login.php" method="post">
<input type="hidden" name="loginfrom" value="http://www.almars.net/?content=coustomer_login">
<table align="center" border="1" cellspacing="0" cellpadding="3">
<tr>

<td style="width: 200px; text-align: left; height: 50px;"><b><img
alt="almars_logo" src="http://almars.net/data/images/log.PNG"
style="width: 30px; height: 30px;" align="left">
</b><big style="font-weight: bold; color: rgb(204, 0, 0);">ALMARS</big><b><br
style="color: rgb(255, 0, 0);">
<span style="color: rgb(51, 51, 153);">IT&amp; Marketing</span></b></td>
<td style="text-align: center; color: rgb(51, 51, 153);"><big><big><b>E-commerce
Solution</b></big><b><small>,<br> Put Your Inventory Online. </small></b></big></td>
</tr><tr>
<td>Email:</td><td>
<input type="text" name="uname"  maxlength="40" value="<? echo "$username"; ?>">
</td></tr>
<tr><td>Password:</td><td>
<input type="password" name="passwd"  maxlength="50" value="<? echo "$pass";?>">
</td></tr>
<tr><td colspan="2" align="right">
<input type="submit" name="submit" value="Special Login">
</td></tr>
</table>
</form>


