<?
if ($logged_in !== 1) { exit;} ?>


<font color="#008000"><u><b>The top balance is the final balance:</b></u></font><br><br>
<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1">
  <tr>
    <td width="12%" align="center"><font color="#000080"><b>Reference#</b></font></td>
    <td width="38%" align="center"><font color="#000080"><b>Description</b></font></td>
    <td width="25%" align="center"><font color="#000080"><b>Amount</b></font></td>
    <td width="25%" align="center"><font color="#000080"><b>Balance</b></font></td>
  </tr>

<?
$selectbalance = $db_object->query("SELECT  * FROM youth_finance WHERE `amount` >0 ORDER BY `time` DESC LIMIT 0 , 30 ");

	if (DB::isError($selectbalance)) {
		echo"I can't get the balance please contact the webmaster";
	}

$numRows  = $selectbalance->numRows();


for($i=0;$i<$numRows;$i++){
 
	$_row= $selectbalance->fetchRow();
$reference = $_row['reference'];
$description = $_row['description']; 
$amount=  $_row['amount'];     
$balance = $_row['balance'];
$date = $_row['date'];
?>

<tr>
    <td width="12%" align="center"><font color="#000080"><?echo "$reference";?></font></td>
    <td width="38%" align="center"><font color="#000080"><?echo "$description";?></font></td>
    <td width="25%" align="center"><font color="#000080"><?echo "$amount";?></font></td>
    <td width="25%" align="center"><font color="#000080"><?echo "total of all for this month";?></font></td>
  </tr>



<?}?>
</table>