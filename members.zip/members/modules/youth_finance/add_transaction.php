<?
if ($logged_in !== 1) { exit;}


echo "<big><big> you didn't program access control yet </big></big>";
//action insert transaction

$selectbalance = $db_object->query("SELECT  * FROM youth_finance ORDER BY `time` DESC LIMIT 0 , 1");

	if (DB::isError($selectbalance)) {
		echo"I can't get the balance please contact the webmaster";
	}

$numRows  = $selectbalance->numRows();
for($i=0;$i<$numRows;$i++){
	$_balances= $selectbalance->fetchRow();
$lastbalance[] = $_balances['balance'];
}

if ($_POST[submit]){
if($logged_in == 1) {
if( $_POST[type]=='+' OR  $_POST[type]=='-'  ){
if($_POST[amount]){
if($_POST[description]){
if($_POST[date]){
$description="$_POST[description] on ($_POST[date])";
$amount="$_POST[type]$_POST[amount] ";
if($_POST[type]=='+'){
$balance= $lastbalance[0] + $_POST[amount] ;
}elseif($_POST[type]=='-'){
$balance= $lastbalance[0] - $_POST[amount] ;
}
$date = date("y.m.d");
$query="INSERT INTO `youth_finance` ( `reference` , `description` , `amount` , `balance`,`date` )VALUES ('', '$description', '$amount', '$balance','$date')";
if (!mysql_query ($query) )
						{
						echo"This charge was not counted please do it again";
						}else{unset($_POST); echo "<big><b>Transaction was Added succecfuly</b></big>";}
}else{echo "<font color=\"#FF0000\">You forgot the date</font> ";}
}else{echo "<font color=\"#FF0000\">You forgot, Please Write a small description</font>";}
}else{echo "<font color=\"#FF0000\">The amount needs to be more than $0.00</font>";}
}else{echo "<font color=\"#FF0000\">Is the amount Debit(-) Or Credit(+)</font>";}
}else{echo "<font color=\"#FF0000\">You are not allowed to add transactions to this account. Please </font><a href=\"http://youth.islamwave.org/login/login.php?loginfrom=http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]\"><span style=\"color: rgb(0, 0, 102);\">log in</span></a></big><span style=\"text-decoration: underline;\"> </span>";}
}
?>

<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1">
  <tr>
    <td width="100%">
    <form method="POST" action="">
    <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber2" bgcolor="#C0C0C0" height="54">
    <tr>
    <td width="13%" align="center"><font color="#000080"><b>Type</b></font></td>
      <td width="48%" align="center"><font color="#000080"><b>Description</b></font></td>
      <td width="13%" align="center"><font color="#000080"><b>Amount</b></font></td>
     <td width="38%" align="center"><font color="#000080"><b>Date</b></font></td>

    </tr>
    <tr>
      <td width="1%"><select size="1" name="type">
      <option >Choose one</option>
      <option value="-">Debit(-)</option>
      <option value="+">Credit(+)</option>
      </select></td>
      <td width="60%">
      <p align="center"><input type="text" name="description" size="57" value="<?if($_POST[description]){echo "$_POST[description]";}?>" ></td>
      <td width="13%">
      <p align="center"><input type="text" name="amount" size="7" value="<?if($_POST[amount]){echo "$_POST[amount]";}?>"></td>
      <td width="38%">
      <p align="center"><input type="text" name="date" size="10" value="<?if($_POST[date]){echo "$_POST[date]";}?>" ></td>
    </tr>
  </table>
  <p><input type="submit" value="Submit" name="submit" style="float: right"></p>
  </form>
  </td>
  </tr>
</table>

