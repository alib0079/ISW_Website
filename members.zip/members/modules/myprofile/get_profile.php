<?

if($_GET[profile_id]){

//check if user allow profile viewing

$check = $db_object->query("SELECT * FROM `users` WHERE `id` ='$_GET[profile_id]' LIMIT 1 ");
if (DB::isError($check)) {
		echo"can not get the profile info";

	}else{
//get all the information
$numRows  = $check->numRows();
if($numRows > 0){
$_check = $check->fetchRow();

}
}
if ($_check[private]==0){$id="$_GET[profile_id]";}else{echo "You can not View the profil of this member please ask him/her about it ";}

}else{$id="$_SESSION[userid]";}


//get profile info

$result = $db_object->query("SELECT * FROM `users` WHERE `id` ='$id' LIMIT 0 , 30 ");
if (DB::isError($result)) {
		echo"can not get the profile info";

	}else{
//get all the information
$numRows  = $result->numRows();
if($numRows > 0){
$_result = $result->fetchRow();
}
}

//update Session var if user viewing self profile

if($_SESSION[userid]==$id){
$_SESSION[userfirstname]=$_result[firstname];
$_SESSION[userlastname]=$_result[lastname];
$_SESSION[useraddress]=$_result[address];
$_SESSION[usercity]=$_result[city];
$_SESSION[userstate]=$_result[state];
$_SESSION[userzip]=$_result[zip];
$_SESSION[userabout]=$_result[about];
$_SESSION[userquote]=$_result[quote];
$_SESSION[userwebsite]=$_result[website];
$_SESSION[userprofile_pic]=$_result[profile_pic];

}


?>
















