<? 

echo "I'm checking if you can view the profile ";

?>