<? 

if($_POST[submit]){ if( $_POST[firstname] AND  $_POST[lastname]){

//check web url
if ($_POST['website'] != '' & !preg_match("/^(http|ftp):\/\//", $_POST['website'])) {
		$_POST['website'] = 'http://'.$_POST['website'];	}

echo "<b><BR><BR>Updating user id : $_SESSION[userid]......</b>";


$update = $db_object->query("UPDATE `users` SET `firstname` = '$_POST[firstname]', `lastname` = '$_POST[lastname]', `about` = '$_POST[profile_about]', `userphone` = '$_POST[phone]', `website` = '$_POST[website]', `address` = '$_POST[address]', `city` = '$_POST[city]', `state` = '$_POST[state]', `zip` = '$_POST[zip]', `quote` = '$_POST[profile_quote]' ,`private`='$_POST[private]' WHERE `users`.`id` = '$_SESSION[userid]' LIMIT 1;");

	if (DB::isError($selectbalance)) {
		echo"Not uptated";
	}else{echo "updated";}



exit;
}else{ echo "<b><span style=\"color: rgb(255, 0, 0);\"> First name and Last Name are required </span>";}
}
?>


<form action="" method="post">
<input type="hidden" value= "true"  name="users_address" maxlength="30">
  <table style="text-align: left; width: 100%;" border="0"
 cellspacing="2" cellpadding="2">
    <tbody>
<tr>
<td style="vertical-align: top; text-align: right;"><b>Make My Profile Private:</b></td>
<td>
<input type="radio" name="private" value="1"> Yes
<input type="radio" name="private" value="0" checked>No
</td>
</tr>
<tr>
        <td style="vertical-align: top; text-align: right;"> <b>My Picture:</b><br>
  </td>

   <td style="vertical-align: top;"><a href="../AJAX.php?AJAX_file=change_profile_image" class="DOMpop">Change</a> <a href="../AJAX.php?AJAX_file=delete_profile_image" class="DOMpop"></a>your Profile Photo.<br>
<span style="font-weight: bold;"><img alt="Profile picture"
src="<? echo "../pics/$_SESSION[userid]/$_SESSION[userprofile_pic]"; ?>" style="width: 100px;" ></span><br>
   </td>
</tr>

<tr>
        <td style="vertical-align: top; font-weight: bold;">
        <div style="vertical-align: top; text-align: right;" >Firstname :&nbsp;</div>
        </td>
        <td style="vertical-align: top;"> <input type="text" value= "<? echo "$_SESSION[userfirstname]";?>"  name="firstname" maxlength="30"> </td>
      </tr>

</tr>
      <tr>
        <td style="vertical-align: top; font-weight: bold;">
        <div style="vertical-align: top; text-align: right;">Lastname :&nbsp;</div>
        </td>
        <td style="vertical-align: top;"> <input type="text" value= "<? echo "$_SESSION[userlastname]";?>"  name="lastname" maxlength="30"> </td>
      </tr>



</tr>
      <tr>
        <td style="vertical-align: top; font-weight: bold;">
        <div style="vertical-align: top; text-align: right;">Address :&nbsp;</div>
        </td>
        <td style="vertical-align: top;"> <input type="text" size="50" value= "<? echo "$_SESSION[useraddress]";?>"  name="address" maxlength="100"> </td>
      </tr>



</tr>
</tr>
      <tr>
        <td style="vertical-align: top; font-weight: bold;">
        <div style="vertical-align: top; text-align: right;">City :&nbsp;</div>
        </td>
        <td style="vertical-align: top;"> <input type="text" value= "<? echo "$_SESSION[usercity]";?>"  name="city" maxlength="30"> </td>
      </tr>

      <tr>
        <td style="vertical-align: top; font-weight: bold;">
        <div style="vertical-align: top; text-align: right;">State :&nbsp;</div>
        </td>
        <td style="vertical-align: top;"><? include("form_states.php");?></td>
      </tr>


      <tr>
        <td style="vertical-align: top; font-weight: bold;">
        <div style="vertical-align: top; text-align: right;">Zip code(5 digits) :</div>
        </td>
        <td style="vertical-align: top;"><input type="text" value= "<? echo "$_SESSION[userzip]"; ?>"  name="zip" maxlength="5"></td>
      </tr>
      <tr>
        <td style="vertical-align: top; font-weight: bold;">
        <div style="vertical-align: top; text-align: right;">Phone number : </div>
        </td>
        <td style="vertical-align: top;"><input type="text" name="phone"  value="<? echo "$_SESSION[userphone]"; ?>"></td>
      </tr>
      <tr>
        <td
 style="vertical-align: top; width: 250px; font-weight: bold;">
        <div style="vertical-align: top; text-align: right;"><br>Website or Blog:<br>
        </div>
        </td>
        <td style="vertical-align: top;"><br><input type="text" value= "<?echo "$_SESSION[userwebsite]"; ?>"  name="website" maxlength="150"><font color="blue"> </font></td>
      </tr>

 <tr valign="top">
<td align="right" valign="top">
<b>Quote:</b>
</td>

<td>
<textarea
name="profile.quote" cols="40" rows="6"><? echo "$_SESSION[userquote]";?></textarea>
</td>
</tr>
<tr valign="top">
<td style="padding-top: 2px;" id="descbox-bio" align="right"
valign="top">
<b>About me:</b>
</td>
<td>
<textarea
name="profile.about" cols="40" rows="6"><? echo "$_SESSION[userabout]";?></textarea>
</td>
</tr>

      <tr>
        <td style="vertical-align: top;"><br>
        </td>
        <td style="vertical-align: top;"> 

<input type="hidden"  name="step2" value="true"> 
<input type="hidden"  name="submit" value="Finish">
 
<input title=" Sign up" alt="Update" src="../pics/buttons/button_login.gif" border="0" type="image">
</td>
      </tr>
    </tbody>
  </table>
</form>
______________________________________________________________________
<BR>
<BR>
<script language="JavaScript"><!--

function NAME_IT33() {

window.open('./info/useragreement.php','EANITHING','toolbar=no,location=no, directories=no, status=yes, menubar=no, resizable=yes, copyhistory=no, scrollbars=yes, width=500, height=600');

}

// --></script>
&copy;2004-2006 <? echo "$_config[sitename]"; ?>. All Rights Reserved.
<a href="javascript:NAME_IT33()"onmouseover="window.status='Click me and you will get the script!'; return true"><font color="blue">Privacy</a>


