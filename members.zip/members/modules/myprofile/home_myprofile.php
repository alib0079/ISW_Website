<? 
//home file of myprofile module

include("get_profile.php"); 

echo "<big><b>$_result[firstname] $_result[lastname]</b></big><br><br>";

echo "<IMG  src=\"../pics/$_SESSION[userid]/$_result[profile_pic]\"  style=\"width: 100px;\" border=0 >
<br><br>";

echo "<b>ID:</b>$_result[id]<br>";
echo "<b>Firstname:</b>$_result[firstname]<br>";
echo "<b>Lastname:</b>$_result[lastname]<br>";
echo "<br><b>Address:</b>$_result[address] $_result[city] $_result[state] $_result[zip]<br>";
echo "<br><b>Website or Blog:</b>$_result[website]<br>";
echo "<br><b>About me:</b>$_result[about]<br>";
echo "<br><b>Quote:</b>$_result[quote]<br>";


?>

