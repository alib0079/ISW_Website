<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta content="text/html; charset=ISO-8859-1"
 http-equiv="content-type">
  <title>edit_profile</title>
</head>
<body>
<table class="padt10" border="0" cellpadding="0" cellspacing="0">
  <tbody>
    <tr valign="top">
      <td valign="top" width="100%"> <input name="WebToken"
 value="4ee95689f38e3ac29e548bb9a5fca130" type="hidden">
      <table border="0" cellpadding="0" cellspacing="0">
        <form name="pfform" method="post" action="/groups/profile2"
 style="display: inline;"></form>
        <tbody>
          <tr>
            <td align="right">
            <div class="padb5" id="pf_hdp" style="display: none;"><img
 src="http://groups.google.com/groups/profile/img?r=enfocus%3A%2F%2F5f203C8AAACdgEinboBnF_9PN9fMu1loWjtCCfzuqAqbZKiRA0TcjcvWhO7lKKbx25g7dI4SXes&amp;w=50&amp;h=50"
 class="height=50" alt="Picture" width="50"></div>
            <br>
            </td>
            <td>&nbsp;</td>
            <td valign="bottom">
            <div class="padb5" id="pf_hdr" style="display: none;"> <span
 class="fontsize5"><b>Ali Bouhouch</b></span> </div>
            <br>
            </td>
          </tr>
          <tr valign="top">
            <td id="descbox-icon" align="right">
            <div class="padr7 nowrap" id="desc-icon"
 style="display: inline;"><b>My Picture:</b></div>
            </td>
            <td><br>
            </td>
            <td>
            <div id="text-icon" style=""> <input
 name="field.other.pfimg" value="1" type="hidden"> <input
 name="other.pfimg" value="" type="hidden">
            <div id="pfimg-desc0" style="display: none;"><a
 href="http://groups.google.com/groups/profile?myprofile#"
 onclick="return PF_AddPhotoDialog();">Select</a> a picture to use as
your Groups Photo.</div>
            <div id="pfimg-desc1"><a
 href="http://groups.google.com/groups/profile?myprofile#"
 onclick="return PF_AddPhotoDialog();">Change</a> or <a
 href="http://groups.google.com/groups/profile/addphoto?Action.Delete=1&amp;_done=%2Fgroups%2Fprofile%3Fmyprofile%3D%26&amp;%26Action%3Dedit">delete</a>
your Groups Photo.</div>
            <div id="pfimg-desc2" style="display: none;">The following
image has been selected as your Groups Photo. <a
 href="http://groups.google.com/groups/profile?myprofile#"
 onclick="return PF_AbandonTempPhoto();">Undo</a></div>
            <a href="http://groups.google.com/groups/profile?myprofile#"
 onclick="return PF_AbandonTempPhoto();"> </a>
            <a href="http://groups.google.com/groups/profile?myprofile#"
 onclick="return PF_AbandonTempPhoto();"> <img
 src="http://groups.google.com/groups/profile/img?r=enfocus%3A%2F%2F5f203C8AAACdgEinboBnF_9PN9fMu1loWjtCCfzuqAqbZKiRA0TcjcvWhO7lKKbx25g7dI4SXes&amp;w=50&amp;h=50"
 id="pfimg_edit" alt="Picture" height="50" width="50"> </a><a
 href="http://groups.google.com/groups/profile?myprofile#"
 onclick="return PF_AbandonTempPhoto();"> </a></div>
            </td>
            <td><br>
            </td>
          </tr>
          <tr valign="top">
            <td style="padding-top: 2px;" id="descbox-name"
 align="right" valign="top">
            <div class="padr7 nowrap" id="desc-name"
 style="display: inline;"><b>Name:</b></div>
            </td>
            <td><br>
            </td>
            <td>
            <div style="">
            <div id="span-name" style="display: none;"> Ali Bouhouch
            </div>
            <div class="padb5" id="text-name" style=""> <input
 name="field.profile.name" value="1" type="hidden"> <input
 name="profile.name" value="Ali Bouhouch" maxlength="200" type="text"
 width="20"> &nbsp;&nbsp;
            </div>
            </div>
            </td>
          </tr>
          <tr valign="top">
            <td style="padding-top: 2px;" id="descbox-location"
 align="right" valign="top">
            <div class="padr7 nowrap" id="desc-location" style=""><b>Location:</b></div>
            </td>
            <td><br>
            </td>
            <td>
            <div style="">
            <div id="span-location"
 style="padding-bottom: 4px; display: none;"> Wichita,Ks
            </div>
            <div class="padb5" id="text-location" style=""> <input
 name="field.profile.location" value="1" type="hidden"> <input
 name="profile.location" value="Wichita,Ks" maxlength="50" type="text"
 width="20"> &nbsp;&nbsp;
            </div>
            </div>
            </td>
          </tr>
          <tr valign="top">
            <td style="padding-top: 2px;" id="descbox-title"
 align="right" valign="top">
            <div class="padr7 nowrap" id="desc-title"
 style="display: inline;"><b>Title:</b></div>
            </td>
            <td><br>
            </td>
            <td>
            <div style="">
            <div class="padb5" id="text-title" style=""> <input
 name="field.profile.title" value="1" type="hidden"> <input
 name="profile.title" value="" maxlength="50" type="text" width="20">&nbsp;&nbsp;
            </div>
            </div>
            </td>
          </tr>
          <tr valign="top">
            <td style="padding-top: 2px;" id="descbox-industry"
 align="right" valign="top">
            <div class="padr7 nowrap" id="desc-industry"
 style="display: inline;"><b>Industry:</b></div>
            </td>
            <td><br>
            </td>
            <td>
            <div style="">
            <div class="padb5" id="text-industry" style=""> <input
 name="field.profile.industry" value="1" type="hidden">
            <select name="profile.industry" width="20">
            <option value="0" selected="selected">Not specified</option>
            <option value="1">Agriculture</option>
            <option value="2">Arts</option>
            <option value="3">Construction</option>
            <option value="4">Consumer Goods</option>
            <option value="5">Corporate Services</option>
            <option value="6">Education</option>
            <option value="7">Finance</option>
            <option value="8">Government</option>
            <option value="9">Legal</option>
            <option value="10">Manufacturing</option>
            <option value="11">Media</option>
            <option value="12">Medical and Health Care</option>
            <option value="13">Non-Profit</option>
            <option value="14">Recreation, Travel, and Entertainment</option>
            <option value="15">Scientific</option>
            <option value="16">Service Industry</option>
            <option value="17">Technology</option>
            <option value="18">Transportation</option>
            </select>
&nbsp;&nbsp;
            </div>
            </div>
            </td>
          </tr>
          <tr valign="top">
            <td style="padding-top: 2px;" id="descbox-email"
 align="right" valign="top">
            <div class="padr7 nowrap" id="desc-email"
 style="display: none;"><b>Email address:</b></div>
            <br>
            </td>
            <td><br>
            </td>
            <td>
            <div style="">
            <div id="span-email"
 style="padding-bottom: 4px; display: none;"> ab.ali.bouhouch@gmail.com
            </div>
            </div>
            <br>
            </td>
          </tr>
          <tr valign="top">
            <td style="padding-top: 2px;" id="descbox-website"
 align="right" valign="top">
            <div class="padr7 nowrap" id="desc-website" style=""><b>Website
or Blog:</b></div>
            </td>
            <td><br>
            </td>
            <td>
            <div style="">
            <div id="span-website"
 style="padding-bottom: 4px; display: none;"> <a target="new"
 href="http://www.google.com/url?sa=D&amp;q=http://www.islamicsocietyofwichita.com">http://www.islamicsocietyofwichita.com</a>
            </div>
            <div class="padb5" id="text-website" style=""> <input
 name="field.profile.website" value="1" type="hidden"> <input
 name="profile.website" value="http://www.islamicsocietyofwichita.com"
 maxlength="1000" type="text" width="40"> &nbsp;&nbsp;
            </div>
            </div>
            </td>
          </tr>
          <tr valign="top">
            <td style="padding-top: 2px;" id="descbox-quote"
 align="right" valign="top">
            <div class="padr7 nowrap" id="desc-quote"
 style="display: inline;"><b>Quote:</b></div>
            </td>
            <td><br>
            </td>
            <td>
            <div style="">
            <div class="padb5" id="text-quote" style=""> <input
 name="field.profile.quote" value="1" type="hidden"> <textarea
 name="profile.quote" cols="40" rows="6"></textarea> &nbsp;&nbsp;
            </div>
            </div>
            </td>
          </tr>
          <tr valign="top">
            <td style="padding-top: 2px;" id="descbox-bio" align="right"
 valign="top">
            <div class="padr7 nowrap" id="desc-bio"
 style="display: inline;"><b>About me:</b></div>
            </td>
            <td><br>
            </td>
            <td>
            <div style="">
            <div class="padb5" id="text-bio" style=""> <input
 name="field.profile.bio" value="1" type="hidden"> <textarea
 name="profile.bio" cols="40" rows="6"></textarea> &nbsp;&nbsp;
            </div>
            </div>
            </td>
          </tr>
          <tr>
            <td colspan="2">&nbsp;</td>
            <td>
            <div class="padt5 padb10" id="pf_hdr_edit" style=""> Note:
This is your public profile. You can edit or remove information at any
time. For more privacy information, please read our updated <a
 href="http://groups.google.com/intl/en/googlegroups/privacy3.html">Privacy
Policy</a>. </div>
            </td>
          </tr>
          <tr>
            <td class="padall0" colspan="2"><br>
            </td>
            <td style="">
            <div style="display: inline;" id="fmbtn"> <input
 name="Action.SaveProfile" value="Save" type="submit">&nbsp;
            <form style="display: inline;" method="get"
 action="/groups/profile"><input name="myprofile" value="1" \=""
 type="hidden"><input value="Cancel"
 onclick="return PF_HandleCancelLink();" type="submit"></form>
            </div>
            </td>
          </tr>
        </tbody>
      </table>
      </td>
    </tr>
  </tbody>
</table>
<br>
<br>
</body>
</html>
