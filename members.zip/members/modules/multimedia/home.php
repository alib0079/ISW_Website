<br><br><br><br>
<a href="?content=multimedia&amp;datatype=audio&amp;change_cat=true"><img
alt="Audio"
src="http://www.islamicsocietyofwichita.com/pics/icons/audio.JPG"
style="border: 0px solid ; width: 100px; height: 120px;"></a>&nbsp;|
&nbsp;&nbsp;&nbsp;<a
href="?content=multimedia&amp;datatype=video&amp;change_cat=true"><img
alt="Video"
src="http://www.islamicsocietyofwichita.com/pics/icons/video.JPG"
style="border: 0px solid ; width: 100px; height: 118px;"></a><a
href="http://www.islamicsocietyofwichita.com/members/?content=multimedia&amp;datatype=video&amp;change_cat=true"></a>
| &nbsp;&nbsp;&nbsp;<a href="?content=multimedia&amp;datatype=flash"><img
alt="Flash"
src="http://www.islamicsocietyofwichita.com/pics/icons/flash.JPG"
style="border: 0px solid ; width: 100px; height: 122px;"></a> |