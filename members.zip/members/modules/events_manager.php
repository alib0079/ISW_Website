<?
if ($logged_in !== 1) { exit;}

$username="BOA";
$password="1f4be615c3846e49fe2adb46b27420c4";
if($_POST[Submit]){
include("http://www.islamicsocietyofwichita.com/modules/calendar1/events/index.php");
}else{
include("$_GET[content]/login.php");
}
?>

<br><br><br><script language="javascript"><!--
function popupWindow(url) {
  window.open(url,'popupWindow','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,width=1000,height=500,screenX=150,screenY=150,top=150,left=150')
}
//--></script>

<a href="javascript:popupWindow('http://www.islamicsocietyofwichita.com/members/modules/events_manager/index.php?u=<? echo "$username";?>&p=<? echo "$password";?>')"></a>

