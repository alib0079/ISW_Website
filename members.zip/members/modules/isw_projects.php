<table style="width: 100%; text-align: left;" border="0" cellspacing="2">
<tbody>
<tr>
<td class=tablelinks>
<a href="?content=<? echo "$_GET[content]"; ?>&action=view_projects">View All Projects</a> | &nbsp;&nbsp; 
<a href="?content=<? echo "$_GET[content]"; ?>&action=view_project_published">Published Project</a> | &nbsp;&nbsp;
<a href="?content=<? echo "$_GET[content]"; ?>&action=add_project">Add Project</a> | &nbsp;&nbsp;

</td>
</tr>
<tr>
<td><br></td>
</tr>

<tr>
<td style="vertical-align: top;">




<?

if($_GET[action]){@include("isw_projects/$_GET[action].php");}else{@include("isw_projects/home.php");}
?>

</td>
</tr>
</tbody>
</table>

