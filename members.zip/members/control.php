<?
include("../login/loginckeck.php");
if ($logged_in == 1) {
 if(!$_GET[content]){ 



}
if($_GET[content]){
if(@$_GET[content]){ @include("./modules/$_GET[content].php");}
}
}
?>