<?
require './connection/db_connect.php';
include("../config/config.php");
include("template.php");

?>












