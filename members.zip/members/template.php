<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta content="text/html; charset=ISO-8859-1"
 http-equiv="content-type">
  <title>ISW Information</title>
  <meta content="text/html; charset=ISO-8859-1"
 http-equiv="content-type">
<link href="./style/style.css" rel="stylesheet" type="text/css">


<style type="text/css">
@import './style/DOMinclude.css';
#g{position:absolute;top:1em;right:1em}
</style>

<script type="text/javascript" 
  src="./scripts/DOMinclude_config.js"></script>
<script type="text/javascript" 
  src="./scripts/DOMinclude.js"></script>

<script language="JavaScript" type="text/javascript" src="../modules/wysiwyg_beta/wysiwyg_w500.js">
</script>

</head>
<body style="color: rgb(0, 0, 0); background-color: rgb(204, 204, 204);"
 alink="#000099" link="#000099" vlink="#990099">
<div
 style="text-align: center; font-weight: bold; color: rgb(0, 102, 0);"><big><big><big><span
 style="color: rgb(51, 0, 153);"></span></big></big></big>
<table
 style="  background-color: rgb(255, 255, 255);  margin-left: auto; margin-right: auto; text-align: left; width: 950px; height: 1001px;"
 border="0" cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
      <td
style="background-color: rgb(102, 102, 102); text-align: center; vertical-align: top;"><big><span
style="font-weight: bold;"><big><big><span style="color: rgb(255, 255, 255);">ISW Members Area</span></big></big></span></big></td>
    </tr>
    <tr>
      <td style="vertical-align: top;">
      <table
 style="  background-color: rgb(255, 255, 255);  margin-left: auto; margin-right: auto; text-align: left; width: 100%; height: 584px;"
 border="0" cellpadding="2" cellspacing="2">
        <tbody>
          <tr>
            <td style=" vertical-align: top;  width: 160px;   ">
            <div style="text-align: center;">
<? include("mylinksleft.php"); ?>
 </div>
            </td>
            <td style="width: 20px; vertical-align: top;">
            <div style="text-align: center;">&nbsp;&nbsp;&nbsp;&nbsp; </div>
            </td>
            <td style=" width; 100%; vertical-align: top; text-align: center;">
<? include("control.php"); ?>
            </td>
            <td style="width: 20px; vertical-align: top;">
            <div style="text-align: center;"> &nbsp;&nbsp;</div>
            </td>
          </tr>
        </tbody>
      </table>
      <center><br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <p><font size="-2">&copy;2006 ALMARS</font>
      </p>
      </center>
      </td>
    </tr>
  </tbody>
</table>
<big><big><big><span style="color: rgb(51, 0, 153);"></span></big></big></big></div>
</body>
</html>
