<?
if ($logged_in == 1) {
?><br> <center>

<?



echo "<table style=\" background-color: rgb(204, 204, 204);width: 100%; text-align: center;\" border=\"0\" cellpadding=\"2\" cellspacing=\"2\">";
echo "<tbody><tr><td style=\"vertical-align: top;\">";
echo "<b><a href=\"../?home\">Home Page</a></b><br>";
echo "</td></tr></tbody></table><br>";

echo "<table style=\"background-color: rgb(204, 204, 204);width: 100%; text-align: center;\" border=\"0\" cellpadding=\"2\" cellspacing=\"2\">";
echo "<tbody><tr><td style=\"vertical-align: top;\">";
echo "<b><a href=\"?content=myprofile\">My Profile</a></b><br>";
echo "</td></tr></tbody></table><br>";


echo "<table style=\"background-color: rgb(204, 204, 204);width: 100%; text-align: center;\" border=\"0\" cellpadding=\"2\" cellspacing=\"2\">";
echo "<tbody><tr><td style=\"vertical-align: top;\">";
echo "<b><a href=\"?content=mypictures\">My Pictures</a></b><br>";
echo "</td></tr></tbody></table><br>";


$access = $db_object->query(" SELECT * FROM `mod_access` WHERE `user_id` =$_SESSION[userid] ");
if (DB::isError($access)) {
		echo"I can't get access";
	}

$num  = $access->numRows();

for($j=0;$j<$num;$j++){
	$_access= $access->fetchRow();




$maincat = $db_object->query(" SELECT  * FROM `cat_info` WHERE cat_id=$_access[cat_id]  ORDER BY `cat_name` ASC  ");

	if (DB::isError($maincat)) {
		echo"I can't get main categories";
	}

$numRows  = $maincat->numRows();
for($i=0;$i<$numRows;$i++){
	$_maincat= $maincat->fetchRow();

echo "<table style=\"background-color: rgb(204, 204, 204);width: 100%; text-align: center;\" border=\"0\" cellpadding=\"2\" cellspacing=\"2\">";
echo "<tbody><tr><td style=\"vertical-align: top;\">";
echo "<b><a href=\"?content=$_maincat[cat_mod]\">$_maincat[cat_name]</a></b><br>";
echo "</td></tr></tbody></table><br>";

}
}



?>
<table
style=" text-align: center; width: 12px; height: 32px;"
border="0" cellpadding="2" cellspacing="2">
<tbody>
<tr>
<td style="vertical-align: top; text-align: left;"><span
style="font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span>
</td>
</tr>
</tbody>
</table>
</center>
<?}?>