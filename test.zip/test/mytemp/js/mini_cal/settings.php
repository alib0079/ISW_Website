<?php

/**
 * Set this to true for the popup menu to use the theme colors.  You can
 * get a slight speed boost by setting this to false.
 */
define("USE_THEME_COLORS", TRUE);
$hub_dir = "../../";                        

?>