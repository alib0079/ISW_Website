<?php
header("location:../index.php?module=users&norm_user_op=signup");
exit();
?>