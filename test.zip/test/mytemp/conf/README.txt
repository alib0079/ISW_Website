This directory should be writable by the web server ONLY
during installation. The branch directory should ONLY be
writable when creating a branch.

At all other times, please be sure to make this directory
readable by the web server only.
