<?php

/* Image types which are allowed to be uploaded via phpwebsite modules */
/* Added 12/03/2003 (might not be implemented in all modules yet */

$allowedImageTypes = array("image/jpeg",
			   "image/jpg",
			   "image/pjpeg",
			   "image/png",
			   "image/x-png",
			   "image/gif",
			   "image/wbmp");

?>