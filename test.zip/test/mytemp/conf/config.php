<?php

    $dbversion    = 'mysql'                            ;
    $dbhost       = 'localhost'                      ;
    $dbuser       = 'isw_wbst1'                      ;
    $dbpass       = 'nV{wXzHELe4L'                      ;
    $dbname       = 'isw_wbst1'                        ;
    $table_prefix = ''                                 ;
    $source_http  = 'islamicsocietyofwichita.com/mytemp/'              ;
    $source_dir   = '/home/isw/public_html/mytemp/'                    ;
    $hub_hash     = '512eislamicsocietyofwichita.comabd55764isw85249c' ;
    $install_pw   = '35789'                       ;

?>
