<?php

$version = "0.10.2";
$mod_title = "core";
$mod_pname = "Core Files";

?>
