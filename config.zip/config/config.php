<?
//database table
$table='isw_info_cat';
$content_table='isw_info';
$datadir='wiki/';
//base dir
$_configure[base_dir]="";

//email configuration

$_configure[comment_mailto]='administrator@islamicsocietyofwichita.com';

//$_configure[donation_mailto] ='madi_hussam@hotmail.com';
$_configure[donation_mailto] ='administrator@islamicsocietyofwichita.com';

//$_configure[reservation_mailto] ='madi_hussam@hotmail.com';
$_configure[reservation_mailto] ='administrator@islamicsocietyofwichita.com';
//$_configure[reservation_mailto] ='bouhouch6@netzero.com';


$_configure[membership_mailto]='administrator@islamicsocietyofwichita.com';
//$_configure[membership_mailto]='bouhouch6@netzero.com';


//$_config[email_tafseer_class_question_to]='bouhouch6@netzero.com';
$_config[email_tafseer_class_question_to]='administrator@islamicsocietyofwichita.com';

//$_configure[news_mailto]='bouhouch6@netzero.com';
$_configure[news_mailto]='administrator@islamicsocietyofwichita.com';

$_configure[default_wiki_mailto]='administrator@islamicsocietyofwichita.com';

$_configure[dawaa_contact_form]='administrator@islamicsocietyofwichita.com';

//fees
$_configure[annual_membership_fees_family]='50';
$_configure[annual_membership_fees_single]='30';

//messages

$StrSaveFileSuccess='Changes were saved successfuly';


//News configuration

$_configure[num_news_inhome]='6';
?>
