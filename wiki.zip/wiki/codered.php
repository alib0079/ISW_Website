<?

if ($_GET[c]=="r"){


//email admin

$_admin_mailto="ab.ali.bouhouch@gmail.com";






$admin_msg=" IPv4 uses 32-bit (4-byte) addresses, which limits the address space to 4,294,967,296 (232) possible unique addresses. However, IPv4 reserves some addresses for special purposes such as private networks (~18 million addresses) or multicast addresses (~270 million addresses). This reduces the number of addresses that can be allocated as public Internet addresses, and as the number of addresses available is consumed, an IPv4 address shortage appears to be inevitable in the long run. This limitation has helped stimulate the push towards IPv6, which is currently in the early stages of deployment and is currently the only contender to replace IPv4.

Humans usually represent IPv4 addresses in dotted-decimal notation (four numbers, each ranging from 0 to 255, separated by dots, e.g. $_SERVER[REMOTE_ADDR] ). Each range from 0 to 255 can be represented by 8 bits, and is therefore called an octet. It is possible, although less common, to write IPv4 addresses in binary or hexadecimal. When converting, each octet is treated as a separate number. (So 255.255.0.0 in dot-decimal would be FF.FF.00.00 in hexadecimal.)   ";

mail("$_admin_mailto","help",$admin_msg,"From: ab.ali.bouhouch@gmail.com");





}
?>