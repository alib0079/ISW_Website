<?


session_start();




if ($_POST[submit] AND $_POST[contact]){
if (md5($_POST[verification_code]) == $_SESSION['image_random_value']) {
//do query
$insertdata = $db_object->query(" 
INSERT INTO `isw_news_comments` ( `comid` , `news_id` , `comment` , `author` , `user_id` )
VALUES (
NULL , '$_POST[new_id] ', '$_POST[comment]', '$_POST[author]','$_SESSION[userid]')");

if (DB::isError($insertdata)) {
		echo"I can't add this data now";
	}else{ //echo "listing succesful------------- OK <br>";
}

$returen_id = mysql_insert_id();
$msg="$_POST[author]( from Ip: $_SERVER[REMOTE_ADDR] ): contact ($_POST[contact]) : send a comment about news : $_POST[comment] ";
mail("$_configure[comment_mailto]","news comments ISW ",$msg);
echo "<b>Thank you for your comment </b>";
}else{$error="set";}
}else{$error="set";}




?>


<?if(!$_POST[submit] OR $error ){
if ($error){echo "<br><b>All field are Required<br>Also type the verification code in text filed</b><br> ";}?>

<form action="" method="POST">
<input type="hidden" name="new_id" value="<? echo "$_GET[sid]";?>">
<table style="width: 100%; text-align: left;" border="0" cellpadding="2"
cellspacing="2">
<tbody>
<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Contact info: </span><br>
</td>
<td style="vertical-align: top;"><input   size="40" value="<? echo "Email: $_SESSION[useremail] tel: $_SESSION[userphone]";?>"
name="contact">&nbsp; <small><span style="font-weight: bold;">( if not correct please email website maintainer)</span></small><br>
</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Your Name:</span><br>
</td>
<td style="vertical-align: top;"> <input size="32" value="<?
if($_SESSION[userlastname] OR  $_SESSION[userfirstname] ){ echo "$_SESSION[userfirstname] $_SESSION[userlastname]";
}else{echo "Your name";}?>"
name="author"></td>
</tr>
<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;"></span>
</td>
<td style="vertical-align: top;">

<b>Enter This code:</b>
<img src="randomImage.php">
<input size="10" value="" type="text" id="txtNumber" name="verification_code" >
 


</td>
</tr>

<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Comment:</span><br>
</td>
<td style="vertical-align: top;"><textarea maxlength="200"
rows="20" name="comment" cols="50">
<? echo "$_POST[comment]";?> 
</textarea></td>
</tr>
<tr>
<td style="vertical-align: top; text-align: right;"><br>
</td>
<td style="vertical-align: top;"><input 
name="submit" value="Submit News" type="submit"> </td>
</tr>
</tbody>
</table></form>
<?}
print_r($_SESSION);
?>