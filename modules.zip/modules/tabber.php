
<link rel="stylesheet" href="./modules/tabber/example.css" TYPE="text/css" MEDIA="screen">
<link rel="stylesheet" href="./modules/tabber/example-print.css" TYPE="text/css" MEDIA="print">

<script src="./modules/tabber/prototype.js" type="text/javascript"></script>

<script type="text/javascript" src="./modules/tabber/tabber.js"></script>

<style type="text/css">
.tabberlive .tabbertab {
  height:100%;
}
</style>

