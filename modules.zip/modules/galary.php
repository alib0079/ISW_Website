<?
echo "<b>Album Collection: </b>";
$path='./pics/albums_picasa';
$dh = opendir($path);
while (($file = readdir($dh)) !== false) {
if($file!== '.' AND $file!='..'){
   echo "<a href=\"?content=$_GET[content]&album=$path/$file\" > [$file] </a> &nbsp;&nbsp; ";

}
}
closedir($dh);

?>
<br><br>
<iframe
 src="<? echo "$_GET[album]"; ?>"
 height="100%" width="100%"></iframe>
