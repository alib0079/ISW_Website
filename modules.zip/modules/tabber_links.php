<link rel="stylesheet" type="text/css" href="./modules/tabber_links/tabcontent.css" />

<script type="text/javascript" src="./modules/tabber_links/tabcontent.js"></script>