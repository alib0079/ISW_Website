<?
//include("./login/loginckeck.php");
//if ($logged_in == 1) {


if ($_POST[submit] AND $_POST[contact]){




$msg="$_POST[author] this link for you http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]  ";
echo "$msg";
mail("$_POST[mailto]","Your Friend  $_POST[author] want you to visit this page ",$msg);

}else{$error="set";}

if($returen_id){

include("add_image_form.php");

}

if($_POST[image_uploaded]){
include("check_picture_query.php");
exit;
}




?>


<?if(!$_POST[submit] OR $error ){
if ($error){echo "<br><b>All field are Required</b><br>";}?>
<form action="" method="POST">

<input  size="40" value="<? echo "$_GET[link]";?>" name="link">

<table style="width: 100%; text-align: left;" border="0" cellpadding="2"
cellspacing="2">
<tbody>
<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Your Email: </span><br>
</td>
<td style="vertical-align: top;"><input  size="40" value="<? echo "$_SESSION[useremail]";?>"
name="contact">&nbsp; <small><span style="font-weight: bold;"></span></small><br>
</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Your Name:</span><br>
</td>
<td style="vertical-align: top;"><input  size="40" value="<?
if($_SESSION[userlastname] OR  $_SESSION[userfirstname] ){ echo "$_SESSION[userfirstname] $_SESSION[userlastname]";
}else{echo "";}?>"
name="author"></td>
</tr>
<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Your Friends Email: </span><br>
</td>
<td style="vertical-align: top;"><input  size="40" name="mailto">&nbsp; <small><span style="font-weight: bold;"></span></small><br>
</td>
</tr>

<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Note:</span><br>
</td>
<td style="vertical-align: top;"><textarea maxlength="200"
rows="10" name="note" cols="40">
<? echo "$_POST[note]";?>
</textarea></td>
</tr>
<tr>
<td style="vertical-align: top; text-align: right;"><br>
</td>
<td style="vertical-align: top;"><input 
name="submit" value="Submit link" type="submit"> </td>
</tr>
</tbody>
</table></form>
<?}
//}?>