<?

if ($logged_in == 1) {


$AllowEdit='edit';

if ($_GET['wikiid'])
{
if($_GET[path]){$wikiid="$_GET[path]"; $wikiid.="$_GET[wikiid]"; $datadir.="$_GET[path]"; }else{$wikiid="$_GET[wikiid]";}


//check if user has privilege to edit this file

      $user_privilege= $db_object->query("SELECT * FROM wiki_access WHERE user_id = '".$_SESSION['userid']."' AND `wikiid` LIKE '".$wikiid."' AND `access_type` LIKE 'w'");
      if (DB::isError($user_privilege) ) {
		die('i can select from the users table .');
	}
          


$numRows  = $user_privilege->numRows();

if($numRows == 1 ){

$text = stripslashes($_POST['content']);





if (!is_valid_name(stripslashes($_GET['wikiid'])))
  print "<font color='#CC0000'>StrFileInvalidName</font>";
 else if ($fp = @fopen ($datadir.stripslashes($_GET['wikiid']), "wb"))
 {
  fwrite($fp, $text);
  fclose($fp);
  print "<font color='#009900'>Content was saved thanks</font>";





 }
 else
  print "<font color='#CC0000'>StrSaveFileFail</font>";


}else{ 
$msg="[$_GET[wikiid]]:$_SESSION[userfirstname]:$_SESSION[userlastname]:$_SESSION[username]: $_POST[content] ";



mail("$_configure[default_wiki_mailto]", "wiki editing from Ip: $_SERVER[REMOTE_ADDR] ",$msg);

echo "<FONT color=#ff0000>You do not have privilege to write this content instantly.</font><br> But your content was sent to the content maintainer. His name is <b/>Ali Bouhouch</b>. Thank you for you contribution.";}

}else{ echo "no no";}
}else{ 

header("location: /");
exit;
}
?>