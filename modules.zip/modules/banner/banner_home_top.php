<script language='JavaScript' type='text/javascript' src='http://ksdeals.com/ads/adx.js'></script>
<script language='JavaScript' type='text/javascript'>
<!--
   if (!document.phpAds_used) document.phpAds_used = ',';
   phpAds_random = new String (Math.random()); phpAds_random = phpAds_random.substring(2,11);
   
   document.write ("<" + "script language='JavaScript' type='text/javascript' src='");
   document.write ("http://ksdeals.com/ads/adjs.php?n=" + phpAds_random);
   document.write ("&amp;what=zone:2");
   document.write ("&amp;exclude=" + document.phpAds_used);
   if (document.referrer)
      document.write ("&amp;referer=" + escape(document.referrer));
   document.write ("'><" + "/script>");
//-->
</script><noscript><a href='http://ksdeals.com/ads/adclick.php?n=a1f8bc2e' target='_blank'><img src='http://ksdeals.com/ads/adview.php?what=zone:2&amp;n=a1f8bc2e' border='0' alt=''></a></noscript>