<table style="width: 100%; text-align: left;" border="0" cellspacing="2">
<tbody>
<tr>
<td class=tablelinks>
<a href="?content=<? echo "$_GET[content]"; ?>&action=class_questions">
<img alt="Class Questions" src="http://www.islamicsocietyofwichita.com/pics/buttons/main_poits.gif"style="border: 0px solid ; width: 100px; height: 30px;"></a> &nbsp;&nbsp; 
<a href="?content=<? echo "$_GET[content]"; ?>&action=class_sumary">
<img alt="Class Summary" src="http://www.islamicsocietyofwichita.com/pics/buttons/class_summary.gif" style="border: 0px solid ; width: 100px; height: 30px;"></a>&nbsp;&nbsp;
<a href="?content=<? echo "$_GET[content]"; ?>&action=post_question">
<img alt="Post Questions" src="http://www.islamicsocietyofwichita.com/pics/buttons/post_questions.gif" style="border: 0px solid ; width: 100px; height: 30px;"></a>&nbsp;&nbsp;
<hr style="width: 100%; height: 2px;">
</td>
</tr>
<tr>
<td><br></td>
</tr>

<tr>
<td style="vertical-align: top;">




<?

if($_GET[action]){@include("tafseer_class/$_GET[action].php");}else{@include("tafseer_class/home.php");}
?>

</td>
</tr>
</tbody>
</table>

