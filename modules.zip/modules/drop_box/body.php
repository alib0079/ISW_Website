<div id="dropin" style="position:absolute;visibility:hidden;left:200px;top:100px;width:500px;height:300px;background-color:#F5F5F5">

<div align="right"><a href="#" onClick="dismissbox();return false">[Close Box] </a></div>

<table
style="height: 100%; width: 100%; text-align: left; margin-left: auto; margin-right: auto;"
border="1" cellpadding="2" cellspacing="2">
<tbody>
<tr>
<td
style="text-align: center; vertical-align: middle; background-color: rgb(255, 255, 204);"><big
style="color: rgb(255, 0, 0);"><a
href="http://www.islamicsocietyofwichita.com//?content=register"><img
alt=""
src="http://www.islamicsocietyofwichita.com/members/modules/events_manager/loginUsers.gif"
style="border: 0px solid ; width: 77px; height: 77px;" align="left"></a><big>Some
areas in the Website may require
you to log in.<br>
&nbsp;Get your login information now</big></big><br>
<a
href="http://www.islamicsocietyofwichita.com//?content=register"><big
style="color: rgb(255, 0, 0);"><big>Click here</big></big></a><br>
<a
href="http://www.islamicsocietyofwichita.com//?content=register"> </a>
</td>
</tr>
</tbody>
</table>

</div>