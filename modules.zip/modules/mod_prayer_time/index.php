<div><center><big><big><span style="color: rgb(51, 204, 0);"><b>Prayer Schedule<br>
</b></span></big></big>

<?
$m=date(m);
include("$m.html");
?>

from : http://www.qibla.org/
</div>








