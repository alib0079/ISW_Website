<?if($_GET[datatype]){?>
<div style="text-align: left;"><b>Multimedia:</b> | <a
 href="http://www.islamicsocietyofwichita.com/?content=mod_news&amp;action=submit_news_comment&amp;sid=53nt">Submit
Comment</a><br>
<hr style="width: 100%; height: 2px;"> <br></div>

<a href="?content=<? echo "$_GET[content]"; ?>&datatype=audio&change_cat=true">Audio</a> | &nbsp;&nbsp;
<a href="?content=<? echo "$_GET[content]"; ?>&datatype=video&change_cat=true">Video</a> | &nbsp;&nbsp; 
<a href="?content=<? echo "$_GET[content]"; ?>&datatype=flash">Flash</a> | &nbsp;&nbsp;
<a href="?content=<? echo "$_GET[content]"; ?>&datatype=ebook">e-Books</a> | &nbsp;&nbsp;
<hr style="width: 100%; height: 2px;">
<? 

//display subjects

$resultA = $db_object->query(" SELECT * FROM `library_categories` WHERE `cat_type` LIKE 'e' ORDER BY `cat_name` ASC   LIMIT 30 ");

if (DB::isError($resultA)) {
		echo "I can not do result";
	}

$numRows  = $resultA->numRows();
if ($numRows > 0 ){
?><b>Subjects:</b><?
for($i=0;$i<$numRows;$i++){
	$_resultA= $resultA->fetchRow();

$resultB = $db_object->query(" SELECT * FROM `library_data` WHERE `subject` LIKE '$_resultA[cat_name]'AND `datatype` LIKE '$_GET[datatype]'   LIMIT 1 ");

if (DB::isError($resultB)) {
		echo "I can not do result";
	}

$num = $resultB->numRows();

if ($num > 0 ){


?>[<a href="?content=<? echo "$_GET[content]"; ?>&datatype=<? echo "$_GET[datatype]";?>&subject=<? echo "$_resultA[cat_name]"; if($_GET[language]){echo "&language=$_GET[language]";} ?>"><? echo "$_resultA[cat_name]";?></a>] <?


}}}

//end display subjects


?>

<hr style="width: 100%; height: 2px;">

<?

//end links start display
if($_GET[index]){
$andstring1= "AND `index`=$_GET[index]";
}
if($_GET[language]){
$andstring2= "AND `language` LIKE '$_GET[language]'";

}
if($_GET[subject]){
$andstring3= "AND `subject` LIKE '$_GET[subject]'";

}

$result = $db_object->query(" SELECT * FROM `library_data` WHERE `datatype` LIKE '$_GET[datatype]' $andstring1 $andstring2 $andstring3 ORDER BY `index` DESC   LIMIT 30 ");

if (DB::isError($result)) {
		echo "I can not do result";
	}

$numRows  = $result->numRows();

if ($numRows > 0 ){

for($i=0;$i<$numRows;$i++){
	$_result= $result->fetchRow();

?>
<div style="text-align: left;">
<br>

<? if($_result[image]){?>
<img alt="No Image"
src="http://www.islamicsocietyofwichita.com/pubinformation/pics/news/<? echo "$_result[image]";?>" align="left">
<?}?>
<h5 style="text-align: left;">
<a href="?content=<? echo "$_GET[content]"; ?>&datatype=<? echo "$_GET[datatype]";?>&index=<? echo "$_result[index]";?>"><? echo "$_result[title]";?></a>

</h5>
<? if($_GET[index]){

if($_result[datatype]!==ebook){echo "<center>$_result[location]</center>";}
if($_result[datatype]==ebook){ include("$_result[location]"); }
}?>
<br>
<small> 
<b>By :</b> <? echo "$_result[author]";?> |
<b> Language :</b>
<a href="?content=<? echo "$_GET[content]"; ?>&datatype=<? echo "$_GET[datatype]";?>&language=<? echo "$_result[language]"; if($_GET[subject]){echo "&subject=$_GET[subject]";} ?>"><? echo "$_result[language]";?></a> | 

<b>Subject:</b>
 
<a href="?content=<? echo "$_GET[content]"; ?>&datatype=<? echo "$_GET[datatype]";?>&subject=<? echo "$_result[subject]"; if($_GET[language]){echo "&language=$_GET[language]";} ?>"><? echo "$_result[subject]";?></a> | 

</small><br>
-------------------------------------------------------------------------------------------------------------


<?
}}
?>
</div>

<?}else{include("$_GET[content]/multimedia_home.php");}?>