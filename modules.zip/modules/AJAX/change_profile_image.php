<?
require './connection/db_connect.php';
include("./modules/functions_small.php");
include("./config/config.php");

if( $_POST[uploaded] ){

$ext = strtolower(end(explode('.', basename($_FILES[uploadedfile][name]))));

if ($ext == 'jpg' || $ext == 'jpeg') {
    
} else if ($ext == 'png') {
    
# Only if your version of GD includes GIF support
} else if ($ext == 'gif') {
    
} else {
$error= "set";
echo "<br><BR>Image has to be <b>.jpeg </b>, <b>.jpg</b> , <b>.png</b> OR <b> .gif </b>Only please uploade other image<br>";
}

$uploaddir="./pics/$_SESSION[userid]/";
$imagename="$_SESSION[userprofile_pic]";
$uploadfile = $uploaddir . $imagename;




if (move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $uploadfile)) {

  echo "<br><b>Thank you image uploaded </b><br><br>";

echo "<img alt=\"  \" src=\"./pics/thumb.php?src=$imagename&amp;x=400&amp;y=400&amp;f=1&amp;dir=$_SESSION[userid]&amp;dest=$imagename\">";
echo "<img src=\"./pics/thumb.php?src=$imagename&amp;x=100&amp;y=100&amp;f=0&amp;dir=$_SESSION[userid]&amp;dest=$imagename\">";

exit;

}else{echo "Image was not copied";}

}







echo "<img  src=\"./pics/$_SESSION[userid]/$_SESSION[userprofile_pic]\"  style=\"width: 100px;\" >";
?>
<br><br>
<form enctype="multipart/form-data" action="" method="POST">
<input size=20 name="uploadedfile" type="file" />
<input type="submit" name="uploaded"  size="30" value="Upload File">
</form>