<?
require './connection/db_connect.php';
include("./modules/functions_small.php");
include("./config/config.php");

print_r($_SESSION);

?>

<br><BR>this is the deleting script you need to program it thanks