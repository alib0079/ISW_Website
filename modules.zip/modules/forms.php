<? if($logged_in !==1){ ?>

<a href="http://www.islamicsocietyofwichita.com//?content=register"><big>Reserving
the MCC online requires a quick registration in order to avoid spamming
to our site.&nbsp;&nbsp; Please take a moment to <big><big><b>Register New Account Here</b></big></big></big></a>

<? 
//login as guest
echo"<BR><BR><div style=\"text-align: center;\"><form action=\"http://$_SERVER[HTTP_HOST]/$_configure[base_dir]/login/login.php\" method=\"POST\">";
echo"<input type=\"hidden\" name=\"loginfrom\" value=\"http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]\">";
echo "<input type=\"hidden\" name=\"uname\" maxlength=\"40\" value=\"guest\">";
echo "<input type=\"hidden\" name=\"passwd\" maxlength=\"50\" value=\"guest\">";
echo"<input  type=\"submit\" name=\"submit\" value=\"Log in as Guest\" >";
echo"</form></div>";




} 
include("login/loginckeck.php");

if ($logged_in !== 1) { exit;}

?>

<table
style="background-color: rgb(204, 204, 204); width: 100%; text-align: left;"
border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="vertical-align: top; text-align: center;"><a href="?content=forms&amp;form=reservation"> MCC Reservation Form</a>
</td>
<td style="vertical-align: top; text-align: center;"><a  href="?content=forms&amp;form=donations">Donations Form</a>
</td>
<td style="vertical-align: top; text-align: center;"><a  href="?content=forms&amp;form=membership">Membership Form</a>
</td>
</tr>
</tbody>
</table>

<?
//<a  href="?content=forms&amp;form=feedback">Feedback Form</a>&nbsp;&nbsp;
?>
<br>
      
<?

  
if($_GET[form]){ 
echo "<div style=\"text-align: left;\"> <b>$_GET[form] form:</b></div><br>"; 
@include("forms/$_GET[form].php");

}else{
echo "<div style=\"text-align: left;\"> <b>reservation form:</b></div><br>"; 
include("forms/reservation.php");}


?>