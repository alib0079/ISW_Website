<style type="text/css">
@import './modules/nopopup/DOMinclude.css';
#g{position:absolute;top:1em;right:1em}
</style>

<script type="text/javascript" 
  src="./modules/nopopup/DOMinclude_config.js"></script>
<script type="text/javascript" 
  src="./modules/nopopup/DOMinclude.js"></script>