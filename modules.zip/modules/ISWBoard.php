<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
  <meta http-equiv="Content-Type"
 content="text/html; charset=iso-8859-1">
  <title>ISW Boards</title>

</head>
<body>
<b>ISW Board Members
</b>
<table align="center" border="0" cellpadding="0" cellspacing="0"
 width="100%">
  <tbody>
    <tr>
      <td bgcolor="#e0d2b7" width="307">
      <div class="style5" align="center">Board of Trustee [BOT]</div>
      </td>
      <td bgcolor="#e0d2b7" width="260">
      <div class="style5" align="center">Board of Education [BOE]</div>
      </td>
    </tr>
    <tr>
      <td><a href="mailto:afarhat@cox.net">Dr.Assem Farhat</a> - <font
 size="2">( President)</font></td>
      <td><a href="mailto:waris@cox.net">Waris Jaffery Director<br>
      </a></td>
    </tr>
    <tr>
      <td bgcolor="#ffeea8"><a href="mailto:alfraih4@yahoo.com">Ahmad
Alfraih</a> - <font size="2">(ISW activities coordinator)</font></td>
      <td bgcolor="#ffeea8"><font face="Arial" size="2"><span
 style="font-size: 10pt; font-family: Arial;"><a
 href="mailto:vorasumaya@sbcglobal.net"><span class="SpellE"></span><span
 class="SpellE"></span></a><span style=""><br>
      </span></span></font></td>
    </tr>
    <tr>
      <td><a href="mailto:fadela@evansbldg.com">Fadel Alsuadi </a>- <font
 size="2">(Long-term Projects)</font></td>
      <td><font face="Arial" size="2"><span
 style="font-size: 10pt; font-family: Arial;"><a
 href="mailto:selimasha@yahoo.com"><span class="SpellE"></span><span
 class="GramE"></span></a></span></font><a href="mailto:ssikder@cox.net"><font
 face="Arial"><span style="font-size: 10pt; font-family: Arial;"><span
 class="GramE"></span></span></font></a><br>
      </td>
    </tr>
    <tr>
      <td bgcolor="#ffeea8"><a href="mailto:karimrabiul@yahoo.com">Rabiul
Karim</a> - <font color="#000000" size="2">(Treasurer)</font></td>
      <td bgcolor="#ffeea8"><font face="Arial" size="2"><span
 style="font-size: 10pt; font-family: Arial;"><a
 href="mailto:khilalusa@yahoo.com"><span style=""></span></a></span></font><br>
      </td>
    </tr>
    <tr>
      <td><font face="Arial" size="2"><span
 style="font-size: 10pt; font-family: Arial;"><a
 href="mailto:Madi_hussam@hotmail.com">Hussam Madi BOA Director</a> </span></font></td>
      <td><font face="Arial" size="2"><span
 style="font-size: 10pt; font-family: Arial;"><a
 href="mailto:kimtranquillity@hotmail.com"><span style=""></span></a> </span></font><br>
      </td>
    </tr>
    <tr>
      <td bgcolor="#ffeea8"><a href="mailto:rozinashah@yahoo.com">Dr.
Rozina Shah </a>- <font size="2">(Secretary) </font></td>
      <td bgcolor="#ffeea8"><font face="Arial" size="2"><span
 style="font-size: 10pt; font-family: Arial;"><a
 href="mailto:cjesri@yahoo.com"><span class="SpellE"><span class="GramE"></span></span><span
 class="GramE"><span style=""></span></span></a></span></font><br>
      </td>
    </tr>
    <tr>
      <td><a href="mailto:hfarhoud@cox.net">Dr. Hussam Farhoud </a>-<font
 size="2"> (Member) </font></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td bgcolor="#ffeea8"><font face="Arial" size="2"><a
 href="mailto:usmani@noornet.com">Mohammad Usmani</a> - <font size="2">(Communication
/ Publication)</font></font></td>
      <td bgcolor="#ffeea8">&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td bgcolor="#e0d2b7">
      <div class="style6" align="center"><font face="Arial" size="2"><span
 style="font-size: 10pt; font-family: Arial;"><strong>BOC C</strong></span></font><span
 class="style1"><strong><span style="font-family: Arial;">ommunication</span></strong></span></div>
      </td>
      <td bgcolor="#e0d2b7">
      <div class="style6" align="center"><strong><strong>Board of
Administration [BOA]</strong></strong></div>
      </td>
    </tr>
    <tr>
      <td><font face="Arial" size="2"><span
 style="font-size: 10pt; font-family: Arial;"><a
 href="mailto:rozinashah@yahoo.com">Dr. Rozina <span class="GramE">Shah<span
 style="">&nbsp; </span>Director</span></a></span></font></td>
      <td><font face="Times New Roman" size="3"><span
 style="font-size: 12pt;"><a href="mailto:madi_hussam@hotmail.com">Hussam
Madi</a> (boa director, Masjed Committee)</span></font></td>
    </tr>
    <tr>
      <td bgcolor="#ffeea8"><font face="Arial" size="2"><span
 style="font-size: 10pt; font-family: Arial;"><br>
      </span></font></td>
      <td bgcolor="#ffeea8"><a href="mailto:ajesri@sbcglobal.net"><font
 face="Times New Roman" size="3"><span style="font-size: 12pt;">Ammar
Jesri</span></font></a> ( Maintenance Committee)<br>
      </td>
    </tr>
    <tr>
      <td><font face="Arial" size="2"><span
 style="font-size: 10pt; font-family: Arial;"><a
 href="mailto:tsabr@aol.com"><span class="SpellE"><span class="GramE"></span></span></a></span></font><br>
      </td>
      <td><font face="Times New Roman" size="3"><span
 style="font-size: 12pt;"><a href="mailto:bouhouch6@netzero.net">Ali
Bouhouch</a> (Youth Committee)<br>
      </span></font></td>
    </tr>
    <tr>
      <td bgcolor="#ffeea8"><br>
      </td>
      <td bgcolor="#ffeea8"><font face="Times New Roman" size="3"><span
 style="font-size: 12pt;"><a href="mailto:erinelhani@yahoo.com">Erin
ALhani</a> (Sisters Committee)<br>
      </span></font></td>
    </tr>
    <tr>
      <td valign="top"><font face="Arial" size="2">&nbsp;</font></td>
      <td valign="top"><font face="Times New Roman" size="3"><span
 style="font-size: 12pt;"><a href="mailto:sssaf000@yahoo.com">Salman
Ashfaq</a> (Burial Committee)<br>
      </span></font></td>
    </tr>
    <tr>
      <td bgcolor="#ffeea8" valign="top"><font face="Arial" size="2">&nbsp;</font></td>
      <td bgcolor="#ffeea8" valign="top"><font face="Times New Roman"
 size="3"><span style="font-size: 12pt;"><a
 href="mailto:eljied@sbcglobal.net">Mohammad Awad</a> (Finance
Committee)<br>
      </span></font></td>
    </tr>
    <tr>
      <td valign="top">&nbsp;</td>
      <td valign="top"><font face="Times New Roman" size="3"><span
 style="font-size: 12pt;"> <a href="mailto:ahmedharoual71@hotmail.com">Ahmad
Haroual</a> (Dawaa Committee)<br>
      </span></font></td>
    </tr>
    <tr>
      <td valign="top">&nbsp;</td>
      <td valign="top">&nbsp;<a href="mailto:mshah3945@sbcglobal.ne">Dr.Shah</a></td>
    </tr>
    <tr>
      <td colspan="2" valign="top">
      <p align="justify">&nbsp;</p>
      </td>
    </tr>
    <tr>
      <td colspan="2" valign="top">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="2"><br>
      </td>
    </tr>
  </tbody>
</table>
<b><a href="mailto:bouhouch6@netzero.com">Add/delete members email
administrator click here</a>
</b>
</body>
</html>
