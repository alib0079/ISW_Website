<? 
include("./modules/$_GET[content]/actions.php");
include("./wiki/codered.php");
//end links start display
if($_GET[action]){include("./modules/$_GET[content]/$_GET[action].php");}else{


$result = $db_object->query(" SELECT * FROM `news` WHERE `sid` =$_GET[sid] LIMIT 1 ");

if (DB::isError($result)) {
		echo "I can not do result";
	}

$_result= $result->fetchRow();

?>


<h3 style="text-align: left;"><? echo "$_result[title]";?></h3>
<hr style="width: 100%; height: 2px;">
<table style="width: 100%; text-align: left;" border="0" cellpadding="2"
cellspacing="2">
<tbody>
<tr>
<td style="vertical-align: top;">&nbsp;&nbsp;&nbsp; <br>
</td>
<td style="vertical-align: top;">
<small>By :<? echo "$_result[author]";?> </small><br>

<table style="width: 100%; text-align: left;" border="0" cellpadding="2"
cellspacing="2">
<tbody>
<tr>
<td style="vertical-align: top;">

<? if( $_result[image] AND file_exists("./pics/news/$_result[image]")) {?>
<img src="./pics/thumb.php?src=<? echo "$_result[image]"; ?>&x=400&y=400&f=0&dir=news  " style="border: 0px solid ;  "  align="top">
<?}?>
</td>
<td style="width: 20px; vertical-align: top;"><br>
</td>
<td style="border: 1px dashed rgb(0, 0, 0); padding: 5px; width: 400px;  vertical-align: top;"> <br>
<ul>
<li><a
href="?content=mod_news&amp;action=submit_news&amp;sid=<? echo "$_GET[sid]";?>">Submit News</a>&nbsp;
<br>
</li>
<li><a
href="?content=mod_news&amp;action=submit_news_comment&amp;sid=<? echo "$_GET[sid]";?>">Submit
Comment</a>&nbsp; <br>
</li>
<li><a
href="?content=mod_news&amp;action=tell_a_friend&amp;sid=<? echo "$_GET[sid]";?>">Tell a friend</a>&nbsp;
<br>
</li>
</ul>



</td>
</tr>
</tbody>
</table>
<br><br>
<? echo "$_result[story]";?>
<br>
<br>
</td>
</tr>
</tbody>
</table>
<div style="text-align: left;">


<br>
<b>Comments on Story:</b> | <a href="?content=mod_news&amp;action=submit_news_comment&amp;sid=<? echo "$_GET[sid]";?>">Submit Comment</a>
<hr style="width: 100%; height: 1px;">

<br>
<? $result = $db_object->query(" SELECT * FROM `news_comments` WHERE `news_id` =$_GET[sid] AND `approved`=1 ORDER BY `comid` ASC 

 ");

if (DB::isError($result)) {
		echo "I can not do result";
	}
$numRows  = $result->numRows();

if ($numRows > 0 ){
for($i=0;$i<$numRows;$i++){
	$_result= $result->fetchRow();



echo "<b>$_result[author]:</b> $_result[comment]";


echo "<br>-----------------------------------------------------------------------------------------------------------------------<br>";

}//end if $i

}//end if numRows > 0




}//end if no action
?>
</div>

