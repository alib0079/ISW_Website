<div style="text-align: left;"><b>Multimedia:</b> | <a
 href="http://www.islamicsocietyofwichita.com/?content=mod_news&amp;action=submit_news_comment&amp;sid=53nt">Submit
Comment</a><br>
<hr style="width: 100%; height: 2px;"><br>


<a href="/?content=islamic_library">Click to view a list of book and
other materials available in the <big><span style="font-weight: bold;">ISW
Islamic Library</span></big></a><br>
<br>


Please select <a
href="http://www.islamicsocietyofwichita.com/?content=multimedia&amp;datatype=audio&amp;change_cat=true">Audio</a>
, <a
href="http://www.islamicsocietyofwichita.com/?content=multimedia&amp;datatype=video&amp;change_cat=true">Video
</a>or <a
href="http://www.islamicsocietyofwichita.com/?content=multimedia&amp;datatype=flash">Flash</a>
to view contents.</div>

<br>
<br>
<br>
<a href="?content=multimedia&amp;datatype=audio&amp;change_cat=true"><img
 alt="Audio"
 src="http://www.islamicsocietyofwichita.com/pics/icons/audio.JPG"
 style="border: 0px solid ; width: 100px; height: 120px;"></a>&nbsp;|
&nbsp;&nbsp;&nbsp;<a
 href="?content=multimedia&amp;datatype=video&amp;change_cat=true"><img
 alt="Video"
 src="http://www.islamicsocietyofwichita.com/pics/icons/video.JPG"
 style="border: 0px solid ; width: 100px; height: 118px;"></a>
| &nbsp;&nbsp;&nbsp;<a href="?content=multimedia&amp;datatype=flash"><img
 alt="Flash"
 src="http://www.islamicsocietyofwichita.com/pics/icons/flash.JPG"
 style="border: 0px solid ; width: 100px; height: 122px;"></a> |
 &nbsp;&nbsp;&nbsp;<a href="?content=multimedia&amp;datatype=ebook"><img
 alt="Flash"
 src="http://www.islamicsocietyofwichita.com/pics/icons/ebook.JPG"
 style="border: 0px solid ; width: 100px; height: 122px;"></a> |

<br>
<br>
<br>
<div style="text-align: left;"><b>Comments About Multimedia Link:</b> | <a
 href="http://www.islamicsocietyofwichita.com/?content=mod_news&amp;action=submit_news_comment&amp;sid=53nt">Submit
Comment</a><br>
<hr style="width: 100%; height: 2px;"><br>
<br>
<? $result = $db_object->query(" SELECT * FROM `news_comments` WHERE `news_id` =53 AND `approved`=1 ORDER BY `comid` ASC 

 ");

if (DB::isError($result)) {
		echo "I can not do result";
	}
$numRows  = $result->numRows();

if ($numRows > 0 ){
for($i=0;$i<$numRows;$i++){
	$_result= $result->fetchRow();



echo "<b>$_result[author]:</b> $_result[comment]";


echo "<br>-----------------------------------------------------------------------------------------------------------------------<br>";

}//end if $i

}//end if numRows > 0
?>