<script language="javascript"><!--
function popupWindow(url) {
  window.open(url,'popupWindow','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,width=1000,height=500,screenX=150,screenY=150,top=150,left=150')
}
//--></script>
<table
style="background-color: rgb(204, 204, 204); width: 100%; text-align: left;"
border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="vertical-align: top; text-align: center;">
<a href="javascript:popupWindow('http://www.islamicsocietyofwichita.com/calendar1/events/index.php')"></a>
</td>
<td style="vertical-align: top; text-align: center;">
<a href="./?content=forms&form=reservation"> [Maintained By ISW office manager]</a> 
</td>
<td style="vertical-align: top; text-align: center;">
<a href="http://www.islamicsocietyofwichita.com/?content=forms&form=reservation">[ MCC Reservation Form ]</a>
</td>
</tr>
</tbody>
</table>
<br><?

include("./modules/calendar1/full.php");

?>