<?
include("./login/loginckeck.php");
if ($logged_in == 1) {

$brief =$_POST[brief];

$brief = removeEvilTags("$brief");
$brief = removeEvilAttributes("$brief");
$brief = addslashes("$brief");





if ($_POST[submit] AND $_POST[contact] AND $_POST[brief] AND $_POST[story] AND $_POST[title]){
//do query
$insertdata = $db_object->query(" 
INSERT INTO `news` ( `sid` , `author` , `contact` , `title` , `brief` , `story` , `user_id` , `created`,`expiretion`)
VALUES (
NULL , '$_POST[author]', '$_POST[contact]', '$_POST[title]','$brief', '$_POST[story]', '0',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP
)");
echo "$insertdata";
if (DB::isError($insertdata)) {
		echo"I can't add this data now";
	}else{ //echo "listing succesful------------- OK <br>";
}

$returen_id = mysql_insert_id();
$msg="$_POST[author] have submitted news to the ISW website. Please review it and see if it is important and needs to be approved at http://islamicsocietyofwichita.com/members/?content=mod_news ";
mail("$_configure[news_mailto]","New sent to ISW website ",$msg);

}else{$error="set";}

if($returen_id){

include("add_image_form.php");

}

if($_POST[image_uploaded]){
include("check_picture_query.php");
exit;
}




?>


<?if(!$_POST[submit] OR $error ){
if ($error){echo "<br><b>All field are Required</b><br>";}?>
<form action="" method="POST">
<table style="width: 100%; text-align: left;" border="0" cellpadding="2"
cellspacing="2">
<tbody>
<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Contact info: </span><br>
</td>
<td style="vertical-align: top;"><input  size="40" value="Email: <? echo "$_SESSION[useremail] tel: $_SESSION[userphone]";?>"
name="contact">&nbsp; <small><span style="font-weight: bold;"></span></small><br>
</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Your Name:</span><br>
</td>
<td style="vertical-align: top;"><input readonly="readonly" size="32" value="<?
if($_SESSION[userlastname] OR  $_SESSION[userfirstname] ){ echo "$_SESSION[userfirstname] $_SESSION[userlastname]";
}else{echo "Anonymous";}?>"
name="author"></td>
</tr>
<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Story Title:</span><br>
</td>
<td style="vertical-align: top;"><input size="32" value="<? echo "$_POST[title]";?>"
name="title"></td>
</tr>
<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Small Briefing For homepage<br>( no HTML Allowed):</span><br>
</td>
<td style="vertical-align: top;"><textarea maxlength="200"
rows="5" name="brief" cols="50"  >
<? echo "$_POST[brief]";?>
</textarea></td>
</tr>


<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">New or Story Body:<br>(HTML IS Allowed)</span><br>
</td>
<td style="vertical-align: top;"><textarea 
rows="20" name="story" cols="50" id="news" >
<? echo "$_POST[story]";?>
</textarea>
<script language="javascript1.2">
  generate_wysiwyg('news');
</script>



</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: right;"><br>
</td>
<td style="vertical-align: top;"><input 
name="submit" value="Submit News" type="submit"> </td>
</tr>
</tbody>
</table></form>
<?}}?>
