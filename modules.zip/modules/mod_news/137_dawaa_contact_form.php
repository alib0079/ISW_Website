<?

include("./modules/encrypt_decrypt_functions.php");


if ($_POST[submit] AND $_POST[comment] AND $_POST[email] AND $_POST[author] AND $_POST[phone]){
if ($_POST[verification_code] == $_SESSION['image_random_value']) {
//do query




$_comment="
(Name :$_POST[author] )  
(from Ip: $_SERVER[REMOTE_ADDR] )  
(contact: $_POST[email]): phone $_POST[phone])  
(best time to call : $_POST[best_time_to_call])  
(reason : $_POST[reason])  
(comment : $_POST[comment])
";


$_info="
(Name :$_POST[author] )  <br>
(from Ip: $_SERVER[REMOTE_ADDR] )<br>  
(Contact: $_POST[email]: phone $_POST[phone]) <br> 
(Best time to call : $_POST[best_time_to_call])  <br>
(Reason : $_POST[reason])  <br>
(Comment : $_POST[comment])<br>
";



$insertdata = $db_object->query(" 
INSERT INTO `news_comments` ( `comid` , `news_id` , `comment` , `author` , `user_id`,`email`,`approved` )
VALUES (
NULL , '$_POST[new_id] ', '$_info', '$_POST[author]','$_SESSION[userid]','$_POST[email]','1')");

if (DB::isError($insertdata)) {
		echo"I can't add this data now";
	}else{ //echo "listing succesful------------- OK <br>";
}

$returen_id = mysql_insert_id();
$msg="$_comment";
mail("$_configure[dawaa_contact_form]","To Information Committee ISW ",$msg);
echo "<b>Thanks you for contacting us, We will try to get back with you as soon as possible</b><br><br><br><br><br>";
}else{$error="set";}
}else{$error="set";}




?>


<?if(!$_POST[submit] OR $error ){

// generate  5 digit random number
$rand = rand(10000, 99999);

// create the hash for the random number and put it in the session
$_SESSION['image_random_value'] = $rand;


if ($error){echo "<center><b>All field are Required<br>Also type the verification code in text filed</b><br> </center>";}?>

<form action="" method="POST">
<input type="hidden" name="new_id" value="137">
<table
style="background-color: rgb(204, 204, 204); width: 100%; text-align: left;"
border="0" cellpadding="2" cellspacing="2">
<tbody>
<tr><td></td></tr>
<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Your Name:</span><br>
</td>
<td style="vertical-align: top;"> <input size="32" value="<?
if($_SESSION[userlastname] OR  $_SESSION[userfirstname] ){ echo "$_SESSION[userfirstname] $_SESSION[userlastname]";
}else{echo "Your name";}?>"
name="author"></td>
</tr>



<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Email *: </span><br>
</td>
<td style="vertical-align: top;"><input   size="40" value="<? echo "$_SESSION[useremail]";?>"
name="email">&nbsp; <small><span style="font-weight: bold;">( if not correct please email website maintainer)</span></small><br>
</td>
</tr>



<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Phone:</span><br>
</td>
<td style="vertical-align: top;"> <input size="32" value="<? echo "$_POST[phone]";?>"
name="phone"></td>
</tr>

<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Best time to call:</span><br>
</td>
<td style="vertical-align: top;"> <input size="32" value="<? echo "$_POST[best_time_to_call]";?>"
name="best_time_to_call"></td>
</tr>


<tr>
<td></td>
<td style="vertical-align: top; text-align: left;">


<STRONG>What do you want from us ?</STRONG>:<br><br>
<INPUT TYPE="radio" NAME="reason" VALUE="I want to schedule visit to ISW. Please write in the comments section below how many people are in your group and the date and time you wish to visit.">I want to schedule visit to ISW. Please write in the comments section below how many people are in your group and the date and time you wish to visit.
<br><INPUT TYPE="radio" NAME="reason" VALUE="I just want to ask basic questions about Islam.">I just want to ask basic questions about Islam.
<br><INPUT TYPE="radio" NAME="reason" VALUE="I need help with a project for school. ">I need help with a project for school 
<br><INPUT TYPE="radio" NAME="reason" VALUE="I would like to schedule a speaker to come speak to a group.  Please provide date and time you would like to schedule a speaker in the comments section below.">I would like to schedule a speaker to come speak to a group.  Please provide date and time you would like to schedule a speaker in the comments section below.
<br><INPUT TYPE="radio" NAME="reason" VALUE="I have been studying about Islam on my own and wish to convert.">I have been studying about Islam on my own and wish to convert.

</td>
</tr>


<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Comments: *</span><br>
</td>
<td style="vertical-align: top;"><textarea maxlength="200"
rows="10" name="comment" cols="50">
<? if ($_POST[comment]){ echo "$_POST[comment]";}else{?>
<?}?> 
</textarea>
<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;"></span>
</td>
<td style="vertical-align: top;">

<b>Enter This code than hit submit:</b>
<img src="./modules/image_verification/randomImage.php?code=<? echo "$_SESSION[image_random_value]"; ?>" >
<input size="10" value="" type="text" id="txtNumber" name="verification_code" >
</td>
</tr>

</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: right;"><br>
</td>
<td style="vertical-align: top;"><input 
name="submit" value="Submit " type="submit"> </td>
</tr>
</tbody>
</table></form>
<?}?>