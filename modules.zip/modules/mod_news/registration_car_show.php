<table
style="margin-left: auto; margin-right: auto; text-align: left; width: 665px; height: 129px;"
border="0" cellpadding="2" cellspacing="2">
<tbody>
<tr>
<td
style="vertical-align: top; background-color: rgb(51, 204, 0);"><br>
</td>
<td
style="text-align: right; vertical-align: top; background-color: rgb(51, 204, 0); font-weight: bold;"><big><big><span
style="color: rgb(255, 255, 0);">Car show </span><br>
</big></big></td>
<td
style="vertical-align: top; background-color: rgb(51, 204, 0); font-weight: bold;"><big><big><span
style="color: rgb(255, 255, 0);">&nbsp;Registration</span><br>
</big></big></td>
<td
style="vertical-align: top; background-color: rgb(51, 204, 0);"><br>
</td>
</tr>
<tr>
<td style="vertical-align: top;"><img alt=""
src="http://www.islamicsocietyofwichita.com/pics/ali/Car-Show-0315.jpg"
style="width: 168px; height: 111px;"><br>
</td>
<td style="vertical-align: top;"><img alt=""
src="http://www.islamicsocietyofwichita.com/pics/ali/Car-Show-0441.jpg"
style="width: 169px; height: 113px;"><br>
</td>
<td style="vertical-align: top;"><img alt=""
src="http://www.islamicsocietyofwichita.com/pics/ali/Car-Show-0980.jpg"
style="width: 173px; height: 115px;"><br>
</td>
<td style="vertical-align: top;"><img alt=""
src="http://www.islamicsocietyofwichita.com/pics/ali/Car-Show-191.jpg"
style="width: 176px; height: 117px;"><br>
</td>
</tr>
</tbody>
</table>











<?

include("./modules/encrypt_decrypt_functions.php");


if ($_POST[submit] AND $_POST[comment] AND $_POST[email] AND $_POST[author] AND $_POST[phone]){
if ($_POST[verification_code] == $_SESSION['image_random_value']) {
//do query

$_POST[comment]="$_POST[comment]";


$insertdata = $db_object->query(" 
INSERT INTO `news_comments` ( `comid` , `news_id` , `comment` , `author` , `user_id`,`email` )
VALUES (
NULL , '$_POST[new_id] ', '$_POST[comment]', '$_POST[author]','$_SESSION[userid]','$_POST[email]')");

if (DB::isError($insertdata)) {
		echo"I can't add this data now";
	}else{ //echo "listing succesful------------- OK <br>";
}

$returen_id = mysql_insert_id();
$msg="$_POST[author]( from Ip: $_SERVER[REMOTE_ADDR] ): contact ($_POST[email]): phone $_POST[phone] : Requests a registration for this car : $_POST[comment] ";
mail("$_configure[comment_mailto]","Car Show Registration ",$msg);
echo "<b><big><br>Thank you for registring<br> We will try to contact you before the show day<br> If we don't contact you, just bring your car to the show day.</big> </b>";
}else{$error="set";}
}else{$error="set";}




?>


<?if(!$_POST[submit] OR $error ){

// generate  5 digit random number
$rand = rand(10000, 99999);

// create the hash for the random number and put it in the session
$_SESSION['image_random_value'] = $rand;


if ($error){echo "<br><b>All field are Required<br>Also type the verification code in text filed</b><br> ";}?>

<form action="" method="POST">
<input type="hidden" name="new_id" value="<? echo "$_GET[sid]";?>">
<table style="width: 100%; text-align: left;" border="0" cellpadding="2"
cellspacing="2">
<tbody>
<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Contact Email *: </span><br>
</td>
<td style="vertical-align: top;"><input   size="40" value="<? echo "$_SESSION[useremail]";?>"
name="email">&nbsp; <small><span style="font-weight: bold;">( if not correct please email website maintainer)</span></small><br>
</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Your Name:</span><br>
</td>
<td style="vertical-align: top;"> <input size="32" value="<?
if($_SESSION[userlastname] OR  $_SESSION[userfirstname] ){ echo "$_SESSION[userfirstname] $_SESSION[userlastname]";
}else{echo "Your name";}?>"
name="author"></td>
</tr>

<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Phone:</span><br>
</td>
<td style="vertical-align: top;"> <input size="32" value="<? echo "$_POST[phone]";?>"
name="phone"></td>
</tr>

<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;"></span>
</td>
<td style="vertical-align: top;">

<b>Enter This code:</b>
<img src="./modules/image_verification/randomImage.php?code=<? echo "$_SESSION[image_random_value]"; ?>" >
<input size="10" value="" type="text" id="txtNumber" name="verification_code" >
</td>
</tr>

<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Car Description: *</span><br>
</td>
<td style="vertical-align: top;"><textarea maxlength="200"
rows="20" name="comment" cols="50">
<? if ($_POST[comment]){ echo "$_POST[comment]";}else{?>

Year:
Make:
Model:
Genera info:
<?}?> 
</textarea>

</td>
</tr>
<tr>
<td style="vertical-align: top; text-align: right;"><br>
</td>
<td style="vertical-align: top;"><input 
name="submit" value="Submit Registration" type="submit"> </td>
</tr>
</tbody>
</table></form>
<?}?>