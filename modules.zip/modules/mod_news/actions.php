<table style="width: 100%; text-align: left;" border="0" cellspacing="2">
<tbody>
<tr>
<td class=tablelinks>
<a href="?content=<? echo "$_GET[content]"; ?>&action=submit_news&sid=<?echo "$_GET[sid]";?>">Submit News</a>&nbsp;&nbsp;|
<a href="?content=<? echo "$_GET[content]"; ?>&action=submit_news_comment&sid=<? echo "$_GET[sid]";?>">Submit Comment</a>&nbsp;&nbsp;|
<a href="?content=<? echo "$_GET[content]"; ?>&action=tell_a_friend&sid=<? echo "$_GET[sid]";?>">Tell a friend</a>&nbsp;&nbsp;|

</td>
</tr>
</tbody>
</table>


