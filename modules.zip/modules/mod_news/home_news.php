<link rel="stylesheet" type="text/css" href="./modules/tabber_links/tabcontent.css" />

<script type="text/javascript" src="./modules/tabber_links/tabcontent.js"></script>
<? if($_GET[content]==home_news){ include("./modules/mod_news/news_verification.html");}?>
<?
//<br>
//<ul id="maintab" class="shadetabs">
//<li><a href="http://www.islamicsocietyofwichita.com/?content=home_news&news=isw">Community News</a> </li>
//<li><a href="http://www.islamicsocietyofwichita.com/?content=home_news&feed_rss_xml=http://www.kansas.com/mld/kansas/news/rss.xml">Local News</a> </li>
//<li><a href="http://www.islamicsocietyofwichita.com/?content=home_news&feed_rss_xml=http://rss.news.yahoo.com/rss/politics">US News</a> </li>
//<li><a href="http://www.islamicsocietyofwichita.com/?content=home_news&feed_rss_xml=http://newsrss.bbc.co.uk/rss/newsonline_uk_edition/world/rss.xml">World News</a> </li>
//</ul>
//<hr style="width: 100%; height: 2px;">
//<br>

if($_GET[news]=='isw' OR !$_GET[feed_rss_xml]){
$result = $db_object->query("SELECT  * FROM news WHERE `expiretion` >= CURRENT_TIMESTAMP AND `approved` =1 AND `archive` =0 ORDER BY `created` DESC  LIMIT 6");

	if (DB::isError($result)) {
		echo"I can't get main categories";
	}

$numRows  = $result->numRows();


?>
<table style="width: 100%; text-align: left;" border="0" cellspacing="2">
<tbody>
<tr>
<td
style="background-color: rgb(204, 204, 204); vertical-align: top;"><span
style="font-weight: bold; text-decoration: underline=no; color: rgb(0, 0, 153);">Community
News and Announcement : <a href="?content=mod_news&action=submit_news">   <small style="color: rgb(204, 0, 0);">(Submit Your News For Approval)</small></a></span><br>
</td>
</tr>
<tr>
<td>
<?
if($numRows < 1){ echo "<BR><big><b>There is no News or Announcement Please <a href=\"?content=mod_news&action=submit_news\"> Click here </a> to submit news !!</b></big> "; }
?>
</td>
</tr>
<tr>
<td style="vertical-align: top;">

<?
if ($numRows > 0 ){


for($i=0;$i<$numRows;$i++){
	$_result= $result->fetchRow();
?>
<table style="width: 100%; text-align: left;" border="0" cellpadding="2"
cellspacing="2">
<tbody>
<tr>
<td style="vertical-align: top;">&nbsp;&nbsp;&nbsp; <br>
</td>
<td style="width: 100%; vertical-align: top;">
<? if( $_result[image] AND file_exists("./pics/news/$_result[image]")) {?>
<a href="?content=mod_news&amp;sid=<? echo "$_result[sid]"; ?>"><img alt="No Image" src="./pics/thumb.php?src=<? echo "$_result[image]"; ?>&x=100&y=100&f=0&dir=news  " style="border: 0px solid ; width: 100px;"  align="left"></a> 
<?}else{echo "";}

?>

<b><? echo "$_result[title]"; ?> </b>
<small>By : <? echo "$_result[author]"; ?></small><br>
<? echo "$_result[brief]"; ?> ...><a href="?content=mod_news&amp;sid=<? echo "$_result[sid]"; ?> ">Read More</a>
<br>
</td>
</tr>
</tbody>
</table>
<hr style="width: 100%; height: 1px;">

<? }}?>

</td>
</tr>
</tbody>
</table>

<?}

//if($_GET[feed_rss_xml]){include("./modules/rss.php");}

?>
