<form enctype="multipart/form-data" action="" method="POST">

<input type="hidden" name="image_uploaded" value="true" >
<input type="hidden" name="image_id" value="<? if($_POST[image_id]){echo"$_POST[image_id]";}else{ echo "$returen_id"; }?>" >
<input type="hidden" name="add_product" value="end" >
<table style="width: 100%; text-align: left;" border="1" cellpadding="2"
cellspacing="0">
<tbody>
<tr>
<td style="vertical-align: top;"><b>Add a Picture Story:</b><br>
<input size=70 name="uploadedfile" type="file" />
<input type="submit" name="uploaded"  size="70" value="Upload File">
</td>
</tr>
</tbody>
</table>
</form> 
