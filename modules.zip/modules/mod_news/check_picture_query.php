<?

if( $_POST[image_id] ){





$ext = strtolower(end(explode('.', basename($_FILES[uploadedfile][name]))));

if ($ext == 'jpg' || $ext == 'jpeg') {
    
} else if ($ext == 'png') {
    
# Only if your version of GD includes GIF support
} else if ($ext == 'gif') {
    
} else {
$error= "set";
echo "<br><BR>Image has to be <b>.jpeg </b>, <b>.jpg</b> , <b>.png</b> OR <b> .gif </b>Only please uploade other image<br>";

include("add_image_form.php");

exit;

}




$uploaddir="./pics/news/";
$imagename="$_POST[image_id]_";
$imagename.= basename($_FILES['uploadedfile']['name']);
$uploadfile = $uploaddir . $imagename;




if (move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $uploadfile)) {

  echo "<br><b>Thank you for your contribution </b><br><br>";

}else{echo "Image was not copied";}
//add image name to the database

$insertdata = $db_object->query("UPDATE `news` SET `image` = '$imagename',`modified` = NOW( )  WHERE `sid` =$_POST[image_id] LIMIT 1 ; ");

if (DB::isError($insertdata)) {
		echo"I can't add this data now";
	}else{
//resize pictures link 


echo "<img src=\"./pics/thumb.php?src=$imagename&amp;x=400&amp;y=400&amp;f=1&amp;dir=news&amp;dest=$imagename\">";
echo "<img src=\"./pics/thumb.php?src=$imagename&amp;x=400&amp;y=400&amp;f=0&amp;dir=news&amp;dest=$imagename\">";
echo "<br><b>Your Image Was Sent. Thank you</b>";

//echo "<A HREF=\"./pics/index.php?pic=$imagename&cat=$_POST[id_category]&f=news\" ><img alt=\"Continue\" src=\"./pics/buttons/continue.gif\" style=\"width: 73px;  border: 0px  height: 19px;\"> </A>";

}

}
?>
