<?

if($_POST[Submit]){
$msg = "Donation Information\n";
$msg .= "Please Enter Amount of Donation:   :\t$_POST[Amount]\n";
$msg .="How often :\t$_POST[period]\n";
$msg .= "Full Name : \t$_POST[name]\n";
$msg .= "Address  :\t$_POST[address]\n";
$msg .= "Address  :\t$_POST[address]\n";
$msg .= "City :\t$_POST[city]\n";
$msg .= "State  :\t$_POST[State]\n";
$msg .= "Zip Code :\t$_POST[Zip_Code]\n";
$msg .= "Contact Phone Number :\t$_POST[Contact_Phone]\n";
$msg .= "Work Phone Number :\t$_POST[Work]\n";
$msg .= "E.Mail Address :\t$_POST[email]\n";
mail("$_configure[donation_mailto]","Donation Form",$msg);


echo "<BR><BR><BR><BR><b>Your form has been submited, Thanks</b>";



}else{
?>



<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
  <meta http-equiv="Content-Type"
 content="text/html; charset=iso-8859-1">
  <title>Donations form</title>
  <style type="text/css">
<!--
.style10 {color: #000000}
-->
  </style>
  <script language="JavaScript" type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
  } if (errors) alert('The following error(s) occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
}
//-->
  </script>
</head>
<body>
<table
 style="width: 687px; text-align: left; margin-left: auto; margin-right: auto;"
 border="0" cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
      <td width="568">
      <div align="left">
      <p align="justify">&nbsp;</p>
      <p align="center"><br>
      <em><font color="#0000ff">We are looking forward for generous
contribution to this cause. Please<br>
use one of the methods listed below.<img alt="" src="pics/aya2.gif"
 style="width: 470px; height: 92px;"></font></em></p>
      <p style="text-align: center;"><img alt=""
 src="pics/donations.gif" usemap="#Map2"
 style="border: 0px solid ; width: 450px; height: 400px;"> </p>
      </div>
      </td>
    </tr>
    <tr>
      <td style="vertical-align: top; text-align: center;">
      <div align="left">
      <table style="width: 684px; height: 483px;" border="0"
 cellpadding="0" cellspacing="0">
        <tbody>
          <tr>
            <td valign="top" width="466">
            <div align="center">
            <form method="post"
 onsubmit="MM_validateForm('select2','','R','state2','','R','Zip2','','RisNum','Contact_Phone','','R');return document.MM_returnValue"
 action="">
              <p align="left"><font color="#3366cc"><strong>Islamic
Society of Wichita Pledge Form</strong></font></p>
              <div align="left">
              <table align="center" border="1" bordercolor="#ff9933"
 cellpadding="0" cellspacing="0" width="466">
                <tbody>
                  <tr bgcolor="#ecdbbf" valign="top">
                    <td colspan="4">
                    <div class="style10" align="left"><font size="2">I
pledge to the Islamic Society of Wichita to donate the amount indicated
below.</font></div>
                    </td>
                  </tr>
                  <tr>
                    <td width="222"><br>
                    </td>
                    <td colspan="3"><br>
                    </td>
                  </tr>
                  <tr>
                    <td>
                    <div align="left">Please Select Amount of Donation:
                    </div>
                    </td>
                    <td colspan="2">
                    <div align="left"> <input id="select2"
 maxlength="15" size="15" name="Amount"> </div>
                    </td>
                  </tr>
                  <tr>
                    <td>
                    <div align="left">How often</div>
                    </td>
                    <td colspan="2"><input checked="checked"
 value="One Time" name="period" type="radio"> <font size="2">One Time <input
 value="monthly" name="period" type="radio"> <font size="2">Monthly</font></font></td>
                  </tr>
                  <tr>
                    <td>
                    <div align="left">Full Name</div>
                    </td>
                    <td colspan="2">
                    <div align="left"> <input id="Name" name="Name"> </div>
                    </td>
                  </tr>
                  <tr>
                    <td>
                    <div align="left">Address:</div>
                    </td>
                    <td colspan="2">
                    <div align="left"> <input id="Address"
 name="Address"> </div>
                    </td>
                  </tr>
                  <tr>
                    <td>
                    <div align="left">City:</div>
                    </td>
                    <td colspan="3"><input id="City" name="City"> </td>
                  </tr>
                  <tr>
                    <td>
                    <div align="left">State</div>
                    </td>
                    <td width="50"><input id="state2" maxlength="2"
 size="2" value="KS" name="State"></td>
                    <td width="186">Zip Code <input id="Zip2"
 maxlength="5" size="5" name="Zip_Code"></td>
                  </tr>
                  <tr>
                    <td>
                    <div align="left">Contact Phone Number</div>
                    </td>
                    <td colspan="2"><input id="Contact_Phone"
 name="Contact_Phone"></td>
                  </tr>
                  <tr>
                    <td>
                    <div align="left">Alt. Phone Number</div>
                    </td>
                    <td colspan="2"><input id="work" name="work"></td>
                  </tr>
                  <tr>
                    <td>
                    <div align="left">E.Mail </div>
                    </td>
                    <td colspan="2"><input id="email" name="email"> <font
 color="#ff0000" size="2"><br>
Leave it blank if no email available</font></td>
                  </tr>
                  <tr bgcolor="#ecdbbf">
                    <td colspan="3"><br>
                    </td>
                  </tr>
                  <tr>
                    <td>
                    <div align="left"> <input value="Submit"
 name="Submit" type="submit"> </div>
                    </td>
                    <td colspan="2"><input value="Reset" name="Submit2"
 type="reset"></td>
                  </tr>
                </tbody>
              </table>
              </div>
              <p align="center">&nbsp;</p>
            </form>
            <p align="center">&nbsp; </p>
            </div>
            </td>
          </tr>
        </tbody>
      </table>
      <div align="center"> <map name="Map2">
      <area shape="RECT" coords="296,341,383,358" href="Donations.doc">
      <area shape="RECT" coords="298,362,380,382" href="donation.pdf">
      </map>
      <font face="Arial" size="3"><span
 style="font-size: 12pt; font-family: Arial;"><br>
      </span></font></div>
      </div>
      </td>
    </tr>
    <tr>
      <td colspan="1"><br>
      </td>
    </tr>
  </tbody>
</table>
</body>
</html>
<?
}
?>
