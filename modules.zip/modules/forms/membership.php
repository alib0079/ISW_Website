<?  if($_POST[submit]){


$msg = "Membership form Information\n";
$msg.="Membership type :\t$_POST[membership]\n";
$msg .= "Name is  :\t$_POST[name]\n";
$msg .= "Address  :\t$_POST[address]\n";
$msg .= "City :\t$_POST[City]\n";
$msg .= "State  :\t$_POST[state]\n";
$msg .= "Zip Code :\t$_POST[zip]\n";
$msg .="Phone Number :\t$_POST[phone]\n";
$msg .= "Work Phone  :\t$_POST[work]\n";
$msg .= "Fax Number  :\t$_POST[fax]\n";
$msg .= "occupation :\t$_POST[occupation]\n";
$msg .= "Email  :\t$_POST[email]\n";
$msg .= "Gender  :\t$_POST[gender]\n";
$msg .= "Status  :\t$_POST[status]\n";
$msg .= "Spouse Name  :\t$_POST[sname]\n";
$msg .= "Spouse Occupation  :\t$_POST[soccupation]\n";
$msg .= "Number of Children  :\t$_POST[children]\n";
$msg .= "Do you want the above information published in the wichita Muslim Directory :\t$_POST[publish]\n";
$msg .= "Message : \t$_POST[message]\n";
$msg .= "Subject :\t$_POST[subject]\n";

mail("$_configure[membership_mailto]","Membership Form",$msg);



echo "<BR><BR><BR><BR><BR><BR> Your information has been submited.";



}else{
?>
 <b><big> Important Note: This is not the official form.  The purpose of this form is to get your information, so we can contact you about your membership. The membership committee has a process that you must go through in order for you to become a member.</b>     
<br>
<DIV align=justify></DIV>
      <P align=justify><FONT color=#ff0000 size=2>Please fill the form below</FONT></P>
      </div>
                  <FORM 
onsubmit="MM_validateForm('name','','R','address','','R','city','','R','state2','','R','Zip2','','R','home','','R','work','','R','occupation','','R','email','','RisEmail');return document.MM_returnValue" 
action="" method=post>
                    <TABLE width=472 border=1 align="center" cellPadding=0 cellSpacing=0 borderColor=#ff9933>
                      <TBODY>
                        <TR>
                          <TD width=226><div align="left">
                            <INPUT type=radio CHECKED value=Family name=membership>
                              <FONT 
size=2>Family Membership (<?echo "$$_configure[annual_membership_fees_family]";?>/ Year)</FONT></div></TD>
                          <TD colSpan=2><div align="left"><FONT size=2>
                              <INPUT type=radio value=single name=membership>
              Single Membership (<?echo "$$_configure[annual_membership_fees_single]";?> /Year)</FONT></div></TD>
                        </TR>
                        <TR>
                          <TD><div align="left">Full Name</div></TD>
                          <TD colSpan=2>
                              <div align="left">
                                <INPUT id=name name=name>
                              </div></TD>
                        </TR>
                        <TR>
                          <TD><div align="left">Address:</div></TD>
                          <TD colSpan=2>
                              <div align="left">
                                <INPUT id=address name=address>
                              </div></TD>
                        </TR>
                        <TR>
                          <TD><div align="left">City:</div></TD>
                          <TD colSpan=3><div align="left">
                            <INPUT id=city name=city>
                              </div></TD>
                        </TR>
                        <TR>
                          <TD><div align="left">State</div></TD>
                          <TD width=23><div align="left">
                            <INPUT id=state2 maxLength=2 size=2 value=KS name=state>
                          </div></TD>
                          <TD width=215><div align="left">Zip Code
                                <INPUT id=Zip2 maxLength=5 size=5 name=Zip>
                          </div></TD>
                        </TR>
                        <TR>
                          <TD><div align="left">Phone Number(home)</div></TD>
                          <TD colSpan=2><div align="left">
                            <INPUT id=home name=home>
                          </div></TD>
                        </TR>
                        <TR>
                          <TD><div align="left">Phone Number(Work)</div></TD>
                          <TD colSpan=2><div align="left">
                            <INPUT id=work name=work>
                          </div></TD>
                        </TR>
                        <TR>
                          <TD><div align="left">Fax Number</div></TD>
                          <TD colSpan=2><div align="left">
                            <INPUT id=fax name=fax>
                          </div></TD>
                        </TR>
                        <TR>
                          <TD><div align="left">Occupation</div></TD>
                          <TD colSpan=2><div align="left">
                            <INPUT id=occupation name=occupation>
                          </div></TD>
                        </TR>
                        <TR>
                          <TD vAlign=top><div align="left">E.Mail </div></TD>
                          <TD colSpan=2><div align="left">
                            <INPUT id=email name=email>
                                <FONT color=#ff0000 size=2><BR>
                              </FONT></div></TD>
                        </TR>
                        <TR>
                          <TD><div align="left">
                  <INPUT id=gender type=checkbox CHECKED value=male name=gender>
              Male -
                <INPUT 
id=gender type=checkbox value=Female name=gender>
              Female</div></TD>
                          <TD colSpan=2><div align="left">
                  <INPUT id=status type=checkbox CHECKED value=Single name=status>
              Single -
                <INPUT id=status type=checkbox value=Married name=status>
              Married</div></TD>
                        </TR>
                        <TR>
                          <TD colSpan=3><div align="left">If married please complete the following:</div></TD>
                        </TR>
                        <TR>
                          <TD><div align="left">Spouse Name</div></TD>
                          <TD colSpan=2><div align="left">
                            <INPUT id=sname name=sname>
                          </div></TD>
                        </TR>
                        <TR>
                          <TD><div align="left">Occupation</div></TD>
                          <TD colSpan=2><div align="left">
                            <INPUT id=soccupation name=soccupation>
                          </div></TD>
                        </TR>
                        <TR>
                          <TD><div align="left">No. of children (If any)</div></TD>
                          <TD colSpan=2><div align="left">
                            <INPUT id=children size=2 name=children>
                          </div></TD>
                        </TR>
                        <TR vAlign=top>
                          <TD colSpan=3><div align="left"><FONT size=2>Do you want the above information published in the wichita Muslim Directory </FONT></div></TD>
                        </TR>
                        <TR>
                          <TD><div align="left"><FONT size=2>Yes :
                                  <INPUT type=radio CHECKED value=Yes name=publish>
                          </FONT></div></TD>
                          <TD colSpan=2><div align="left">No:
                                <INPUT type=radio value=No name=publish>
                          </div></TD>
                        </TR>
                        <TR>
                          <TD><div align="left"></div></TD>
                          <TD colSpan=2><div align="left"></div></TD>
                        </TR>
                                                <TR>
                          <TD colSpan=3 height=21><div align="left"></div></TD>
                        </TR>
                        <TR>
                          <TD height=26><div align="left">
                            <INPUT type=submit value=Submit name=submit>
                          </div></TD>
                          <TD 
colSpan=2><div align="left">
                            <INPUT type=reset value=Reset name=Submit2>
                          </div></TD>
                        </TR>
                      </TBODY>
                    </TABLE>
                    </FORM>
                  
<?
}
?>

