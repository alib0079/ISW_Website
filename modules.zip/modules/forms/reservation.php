<?php  
if($_POST[Submit]){
//if ($_POST[verification_code] == $_SESSION['image_random_value']) {
$msg = "Reservation form Information\n";
$msg.="Organization :\t$_POST[Organization]\n";
$msg.="Title:\t$_POST[title]\n";
$msg .= "Name is  :\t$_POST[name]\n";
$msg .= "Address  :\t$_POST[Address]\n";
$msg .= "City :\t$_POST[city]\n";
$msg .= "State  :\t$_POST[state]\n";
$msg .= "Zip Code :\t$_POST[zip]\n";
$msg .="Phone Number :\t$_POST[phone]\n";
$msg .= "Fax Number  :\t$_POST[Fax]\n";
$msg .= "Reservation Day:\t$_POST[day]\n";
$msg .= "Reservation Month:\t$_POST[month]\n";
$msg .= "Reservation year:\t$_POST[year]\n";
$msg .= "Reservation Time  From: :\t$_POST[timefrom]\n";
$msg .= "Reservation Time  To: :\t$_POST[timeto]\n";
$msg .= "Comments  :\t$_POST[comments]\n";
$msg .= "Subject :\t$_POST[subject]\n";
mail("$_configure[reservation_mailto]", "Reservation Form from Ip: $_SERVER[REMOTE_ADDR] ",$msg);

echo "<BR><BR><br> Thank you, for your reservation we will contact you soon"; exit;
//}else{ echo "Code is not correction"; $error="set";}

}
?>














<? if(!$_POST[submit] OR $error ){ ?>




<table align="center" border="0" cellpadding="0" cellspacing="0"
 width="666">
  <tbody>
    <tr>
      <td colspan="6">
      <div align="left">
      <p align="justify"><font color="#ff0000">Welcome to the Wichita
Muslim Community Center reservation page. We are delighted to have you
here and hope to serve you with all your needs. If you would like to
reserve the Community Center, please fill out the following form
completely and accurately.</font><font color="#ff0000"><br>
      <font color="#0000ff">Before renting the MCC facility, you must
read and abide by the following rules and guidelines. </font></font> </p>
      <p align="justify"><font color="#ff0000">MCC Rules and
Regulations:</font></p>
      <ul>
        <li>
          <div align="justify"> MCC (Muslim Community Center) must be
reserved for any activity. This can be done by filling the form on the
ISW website, or by obtaining a hard copy from one of the board of
Administration members.</div>
        </li>
        <li>
          <div align="left">Electronic form can be submitted ,also a
hard copy can be submitted to any of the board members or can be
dropped off in the drop box at MCC.</div>
        </li>
        <li>
          <div align="left">All dues and deposits must be made before
renting. </div>
        </li>
        <li>
          <div align="left">Everyone must evacuate the building once
the activity is over. Lights must be turned off upon leaving. All trash
must be dumped in the dumpsters located south west of the building.</div>
        </li>
        <li>
          <div align="left">Hourly cost of MCC is $20/hr for members
and $40 for non members. With a $100 deposit which will be returned
within one week from the end of the activity. </div>
        </li>
        <li>
          <div align="left">Chairs and tables can be provided. Setup
and Cleanup is rental party&#8217;s responsibility and must be conducted
within the rented time. Building must be left the way it was given. </div>
        </li>
        <li>
          <div align="left">Every Rental must have a responsible person
and will be responsible for any damages caused during that activity. </div>
        </li>
        <li>
          <div align="left">MCC rental contract should be filled for
renting MCC. </div>
        </li>
        <li>
          <div align="left">Responsible person(s) for any activity must
ensure that Islamic manners and conduct is upheld during the activity. </div>
        </li>
        <li>
          <div align="left">BOA reserves the right of rescheduling an
activity for community interest with due notice.</div>
        </li>
        <li>
          <div align="left">Prior Cancellation notice of 72 hours must
be given to BOA to avoid cancellation charge of $25. </div>
        </li>
        <li>
          <div align="left">All activities must have BOA approval. </div>
        </li>
        <li>
          <div align="left">Instrumental music is NOT allowed at MCC.</div>
        </li>
        <li>
          <div align="left">Proper Islamic dressing shall be observed
at all times.</div>
        </li>
        <li> The school lobby, north of gymnasium, is off limits except
to authorize personnel </li>
      </ul>
      </div>
      </td>
    </tr>
    <tr>
      <td colspan="6" valign="top">
      <div align="left">
      <form name="form1" method="post" action="">
        <table align="center" border="1" bordercolor="#ff9900"
 cellpadding="0" cellspacing="0" width="454">
          <tbody>
            <tr bgcolor="#e9d6c5">
              <td colspan="4"><span class="style10">Please provide the
following contact information:</span></td>
            </tr>
            <tr>
              <td width="153">&nbsp;</td>
              <td colspan="3" width="295"><br>
              </td>
            </tr>
            <tr>
              <td>Name</td>
              <td colspan="3"><input name="name" id="name" type="text" value="<? echo "$_POST[name]";?>"  ></td>
            </tr>
            <tr>
              <td>Title</td>
              <td colspan="3"><input name="Title" id="Title" type="text" value="<? echo "$_POST[Title]";?>" ></td>
            </tr>
            <tr>
              <td>Organization</td>
              <td colspan="3"><input name="Organization"
 id="Organization" type="text" value="<? echo "$_POST[Organization]";?>" ></td>
            </tr>
            <tr>
              <td height="26">Address</td>
              <td colspan="3"><input name="Address" value="<? echo "$_POST[Address]";?>" id="Address"
 type="text"></td>
            </tr>
            <tr>
              <td>City</td>
              <td colspan="3"><input name="city" value="<? echo "$_POST[city]";?>" id="city" type="text"></td>
            </tr>
            <tr>
              <td>State</td>
              <td colspan="3"><input name="state" value="<? echo "$_POST[state]";?>" id="state" type="text"></td>
            </tr>
            <tr>
              <td>Zip Code</td>
              <td colspan="3"><input name="zip" id="zip" value="<? echo "$_POST[zip]";?>" type="text"></td>
            </tr>
            <tr>
              <td> Phone</td>
              <td colspan="3"><input name="phone"  value="<? echo "$_POST[phone]";?>" id="phone" type="text"></td>
            </tr>
            <tr>
              <td>FAX</td>
              <td colspan="3"><input name="Fax"  value="<? echo "$_POST[Fax]";?>" id="Fax" type="text"></td>
            </tr>
            <tr>
              <td>E-mail</td>
              <td colspan="3">
              <h6> <input name="email" id="email"  value="<? echo "$_POST[email]";?>"  type="text"> </h6>
              </td>
            </tr>
            <tr bgcolor="#e9d6c5">
              <td colspan="4"><span class="style11">Please tell us what
day/days of the week you want to reserve the center:</span></td>
            </tr>
            <tr>
              <td>Res. Date:</td>
              <td colspan="3">Day
              <select name="day" id="day">
              <option selected="selected" value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              <option value="11">11</option>
              <option value="12">12</option>
              <option value="13">13</option>
              <option value="14">14</option>
              <option value="15">15</option>
              <option value="16">16</option>
              <option value="17">17</option>
              <option value="18">18</option>
              <option value="19">19</option>
              <option value="20">20</option>
              <option value="21">21</option>
              <option value="22">22</option>
              <option value="23">23</option>
              <option value="24">24</option>
              <option value="25">25</option>
              <option value="26">26</option>
              <option value="27">27</option>
              <option value="28">28</option>
              <option value="29">29</option>
              <option value="30">30</option>
              <option value="31">31</option>
              </select>
Month
              <select name="month" id="month">
              <option value="">[Month] </option>
              <option value="ja">January </option>
              <option value="fe">February </option>
              <option value="ma">March </option>
              <option value="ap">April </option>
              <option value="my">May </option>
              <option value="jn">June </option>
              <option value="jl">July </option>
              <option value="ag">August </option>
              <option value="se">September </option>
              <option value="oc">October </option>
              <option value="no">November </option>
              <option value="de">December </option>
              </select>
Year
              <select name="year" id="year">
              
              <option value="2006">2006</option>
              <option value="2007">2007</option>
              <option value="2008">2008</option>
              </select>
              </td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td colspan="3">&nbsp;</td>
            </tr>
            <tr>
              <td>Res. Time:</td>
              <td colspan="3">From:
              <select name="timefrom" id="timefrom">
              <option value="12:00am">12:00am</option>
              <option value="1:00am">1:00am</option>
              <option value="2:00am">2:00am</option>
              <option value="3:00am">3:00am</option>
              <option value="4:00am">4:00am</option>
              <option value="5:00am">5:00am</option>
              <option value="6:00am">6:00am</option>
              <option value="7:00am">7:00am</option>
              <option value="8:00am">8:00am</option>
              <option value="9:00am">9:00am</option>
              <option value="10:00am">10:00am</option>
              <option value="11:00am">11:00am</option>
              <option value="12:00pm">12:00pm</option>
              <option value="1:00pm">1:00pm</option>
              <option value="2:00pm">2:00pm</option>
              <option value="3:00pm">3:00pm</option>
              <option value="4:00pm">4:00pm</option>
              <option value="5:00pm">5:00pm</option>
              <option value="6:00pm">6:00pm</option>
              <option value="7:00pm">7:00pm</option>
              <option value="8:00pm">8:00pm</option>
              <option value="9:00pm">9:00pm</option>
              <option value="10:00pm">10:00pm</option>
              <option value="11:00pm">11:00pm</option>
              </select>
To:
              <select name="timeto" id="timeto">
              <option value="12:00am">12:00am</option>
              <option value="1:00am">1:00am</option>
              <option value="2:00am">2:00am</option>
              <option value="3:00am">3:00am</option>
              <option value="4:00am">4:00am</option>
              <option value="5:00am">5:00am</option>
              <option value="6:00am">6:00am</option>
              <option value="7:00am">7:00am</option>
              <option value="8:00am">8:00am</option>
              <option value="9:00am">9:00am</option>
              <option value="10:00am">10:00am</option>
              <option value="11:00am">11:00am</option>
              <option value="12:00pm">12:00pm</option>
              <option value="1:00pm">1:00pm</option>
              <option value="2:00pm">2:00pm</option>
              <option value="3:00pm">3:00pm</option>
              <option value="4:00pm">4:00pm</option>
              <option value="5:00pm">5:00pm</option>
              <option value="6:00pm">6:00pm</option>
              <option value="7:00pm">7:00pm</option>
              <option value="8:00pm">8:00pm</option>
              <option value="9:00pm">9:00pm</option>
              <option value="10:00pm">10:00pm</option>
              <option value="11:00pm">11:00pm</option>
              </select>
              </td>
            </tr>
            <tr>
              <td colspan="4">Res. Detail</td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td colspan="3"><textarea name="comments" cols="45"
 rows="5" id="comments">Detail description of activity during
reservation  : <? echo "$_POST[comments]";?></textarea></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td colspan="3">&nbsp;</td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td colspan="3"><b>Enter this code 
<?// generate  5 digit random number
$rand = rand(10000, 99999);

// create the hash for the random number and put it in the session
$_SESSION['image_random_value'] = $rand;?>
<img src="./modules/image_verification/randomImage.php?code=<? echo "$_SESSION[image_random_value]"; ?>" >
in this box</b><input size="10" value="" type="text" id="txtNumber" name="verification_code" >
<br>



<input name="Submit" value="Submit"
 type="submit"> <input name="Submit2" value="Reset" type="reset"></td>
            </tr>
            <tr>
              <td colspan="4">&nbsp;</td>
            </tr>
          </tbody>
        </table>
      </form>
      <font face="Arial" size="3"><span
 style="font-size: 12pt; font-family: Arial;"><br>
      </span></font></div>
      </td>
    </tr>
  </tbody>
</table>






<?
}
?>    










