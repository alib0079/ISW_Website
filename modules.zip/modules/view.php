<link rel="stylesheet" type="text/css" href="modules/tabber_links/tabcontent.css" />

<script type="text/javascript" src="modules/tabber_links/tabcontent.js"></script>


<div style="text-align: center; font-weight: bold;"><big><big><span
style="color: rgb(51, 204, 0);"><?echo"<big><b>$_GET[cat_name]</b></big>";?></span>
</big></big></div>
<br>
<?

$maincat = $db_object->query("SELECT  * FROM wiki_info WHERE active=1 AND cat_id=$_GET[cat]  OR  parent_cats_id= $_GET[cat]");

	if (DB::isError($maincat)) {
		echo"error 1";
	}

$numRows  = $maincat->numRows();


//this is for tabber_links
echo "<ul id=\"maintab\" class=\"shadetabs\">";

for($i=0;$i<$numRows;$i++){
	$_maincat= $maincat->fetchRow();

 echo "<li><a href=\"?content=view&amp;cat=$_GET[cat]&amp;cat_name=$_GET[cat_name]&amp;content_title=$_maincat[content_title]\">$_maincat[content_title]</a></li> ";



}
echo "</ul>";










if($_GET[content_title]){$andcontent_title=" AND `content_title` LIKE '$_GET[content_title]' ";}

//if(!$_GET[content_title]){$andcontent_title=" AND `content_home`=1 ";}


$maincat = $db_object->query("SELECT  * FROM wiki_info WHERE active=1 $andcontent_title AND cat_id=$_GET[cat]  OR  parent_cats_id= $_GET[cat] LIMIT 1");

	if (DB::isError($maincat)) {
		echo"error 2";
	}

$numRows  = $maincat->numRows();

echo"<hr style=\"width: 100%; height: 2px;\">";

for($i=0;$i<$numRows;$i++){
	$_maincat= $maincat->fetchRow();
//echo"<hr style=\"width: 100%; height: 2px;\">";
echo"<div style=\"text-align: left; margin-left: 40px;\"><b><u><big><big>$_maincat[content_title]:</big></big></u></b><small> [Maintained By:$_maincat[maintainer]]</small></div>";
echo "<div style=\"text-align: left; \"><br>";


include("wiki/$_maincat[content]");

echo   "</div><br><br>";
echo"<div style=\"text-align: right; \"><a href=\"mailto:$_maincat[maintainer_email]\"> [Maintained By:$_maincat[maintainer]</a>] <a href=\"./edit_content.php?wikiid=$_maincat[content]&wiki_title=$_maincat[content_title]\">[Edit this content]</a>";
echo"<hr style=\"width: 100%; height: 2px;\">";




}



?>