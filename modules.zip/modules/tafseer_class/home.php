<?

$_GET[datatype]="ebook";
$_GET[subject]="Tafseer Class Questions";


if($_GET[datatype]){

include("main_poits.php");

}else{include("$_GET[content]/multimedia_home.php");}?>