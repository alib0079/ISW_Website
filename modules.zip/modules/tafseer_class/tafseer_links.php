<script language='JavaScript' type='text/javascript' src='http://ksdeals.com/ads/adx.js'></script>
<script language='JavaScript' type='text/javascript'>
<!--
   if (!document.phpAds_used) document.phpAds_used = ',';
   phpAds_random = new String (Math.random()); phpAds_random = phpAds_random.substring(2,11);
   
   document.write ("<" + "script language='JavaScript' type='text/javascript' src='");
   document.write ("http://ksdeals.com/ads/adjs.php?n=" + phpAds_random);
   document.write ("&amp;what=zone:4&amp;target=_parent");
   document.write ("&amp;exclude=" + document.phpAds_used);
   if (document.referrer)
      document.write ("&amp;referer=" + escape(document.referrer));
   document.write ("'><" + "/script>");
//-->
</script><noscript><a href='http://ksdeals.com/ads/adclick.php?n=ad4b8087' target='_parent' ><img src='http://ksdeals.com/ads/adview.php?what=zone:4&amp;n=ad4b8087' border='0' alt=''></a></noscript>