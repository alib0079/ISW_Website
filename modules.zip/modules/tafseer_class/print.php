<body onload="window.print(); ">
<A HREF="javascript:window.print()">[print page]</a><br><br>
<?
include("$_GET[print]");

?>

<body>