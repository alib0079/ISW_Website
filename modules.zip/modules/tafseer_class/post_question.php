
<?

if ($_POST[submit]  AND $_POST[name] AND $_POST[description]){

$msg="[Name: $_POST[name]]--[Email : $_POST[email]]--[Question:$_POST[description]]";

mail("$_config[email_tafseer_class_question_to]","Tafseer Class: Post Question",$msg);

echo "<b>Thanks For your question. We will try to have an answer posted on this page</b>";

}else{$error="set";}





?>


<?if(!$_POST[submit] OR $error ){
if ($error){echo "<br><b>All field are Required</b><br>";}?>

<form action="" method="POST">

<table style="width: 100%; text-align: left;" border="0" cellpadding="2"
cellspacing="2">
<tbody>
<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Your Name:</span><br>
</td>
<td style="vertical-align: top;"><input  size="40" value="<? echo "$_POST[name]";?>" name="name"></td>
</tr>

<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Your Email: </span><br>
</td>
<td style="vertical-align: top;"><input  size="40" value="<? echo "$_POST[email]";?>"
name="email">&nbsp; <small><span style="font-weight: bold;"></span></small><br>
</td>
</tr>

<tr>
<td style="vertical-align: top; text-align: right;"><span
style="font-weight: bold;">Type Question:</span><br>
</td>
<td style="vertical-align: top;"><textarea maxlength="200"
rows="10" name="description" cols="40">
<? if ($_POST[description]){echo "$_POST[description]";}?>
</textarea></td>
</tr>
<tr>
<td style="vertical-align: top; text-align: right;"><br>
</td>
<td style="vertical-align: top;"><input 
name="submit" value="Post Question" type="submit"> </td>
</tr>
</tbody>
</table></form>

<?}?>


