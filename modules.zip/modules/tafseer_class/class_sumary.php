<?

$_GET[datatype]="ebook";
$_GET[subject]="Tafseer Class Summary";


if($_GET[datatype]){?>





<? 
//end links start display
if($_GET[index]){
$andstring1= "AND `index`=$_GET[index]";
}
if($_GET[language]){
$andstring2= "AND `language` LIKE '$_GET[language]'";

}
if($_GET[subject]){
$andstring3= "AND `subject` LIKE '$_GET[subject]'";

}

$result = $db_object->query(" SELECT * FROM `library_data` WHERE `datatype` LIKE '$_GET[datatype]' $andstring1 $andstring2 $andstring3 ORDER BY `library_data`.`optionzero` ASC   LIMIT 30 ");

if (DB::isError($result)) {
		echo "I can not do result";
	}

$numRows  = $result->numRows();

if ($numRows > 0 ){

for($i=0;$i<$numRows;$i++){
	$_result= $result->fetchRow();

?>
<div style="text-align: left;">


<? if($_result[image]){?>
<img alt="No Image"
src="http://www.islamicsocietyofwichita.com/pubinformation/pics/news/<? echo "$_result[image]";?>" align="left">
<?}?>
<h5 style="text-align: left;">
<a href="?content=<? echo "$_GET[content]"; ?>&action=<? echo "$_GET[action]"; ?>&datatype=<? echo "$_GET[datatype]";?>&index=<? echo "$_result[index]";?>"><? echo "$_result[title]";?></a>

</h5>
<? if($_GET[index]){

echo "<div style=\"text-align: right;\"><a href=\"./modules/tafseer_class/print.php?print=$_result[location]\"  target=\"_blank\" ><img src=\"http://www.islamicsocietyofwichita.com/pics/icons/printer.jpg\" align=\"middle\" style=\"border: 0px solid ; width: 61px; height: 61px;\">[ Print This Content ]</a></div>";

include ("$_result[location]");
} }}
?>
</div>

<?}else{include("$_GET[content]/multimedia_home.php");}?>