<?

print ('Your IP is: '.$_SERVER['REMOTE_ADDR'].'.');

?>