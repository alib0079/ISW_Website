<?
function is_valid_name($input)	## Checks whether the directory- or filename is valid
{
 if (strstr($input, "\\"))
  return FALSE;
 else if (strstr($input, "/"))
  return FALSE;
 else if (strstr($input, ":"))
  return FALSE;
 else if (strstr($input, "?"))
  return FALSE;
 else if (strstr($input, "*"))
  return FALSE;
 else if (strstr($input, "\""))
  return FALSE;
 else if (strstr($input, "<"))
  return FALSE;
 else if (strstr($input, ">"))
  return FALSE;
 else if (strstr($input, "|"))
  return FALSE;
 else
  return TRUE;
}



/**
* Allow these tags
*/
$allowedTags = '<h1><b><i><a><ul><li><br><p><hr><blockquote><img>';

/**
* Disallow these attributes/prefix within a tag
*/
$stripAttrib = 'javascript:|onclick|ondblclick|onmousedown|onmouseup|onmouseover|'.
'onmousemove|onmouseout|onkeypress|onkeydown|onkeyup';

/**
* @return string
* @param string
* @desc Strip forbidden tags and delegate tag-source check to removeEvilAttributes()
*/
function removeEvilTags($source)
{
global $allowedTags;
$source = strip_tags($source, $allowedTags);
return preg_replace('/<(.*?)>/ie', "'<'.removeEvilAttributes('\\1').'>'", $source);
}

/**
* @return string
* @param string
* @desc Strip forbidden attributes from a tag
*/
function removeEvilAttributes($tagSource)
{
global $stripAttrib;
return stripslashes(preg_replace("/$stripAttrib/i", 'forbidden', $tagSource));
}

// Will output: <a href="forbiddenalert(1);" target="_blank" forbidden =" alert(1)">test</a>
//$_POST['content'] = removeEvilTags("$_POST[content]");
//$_POST['content'] = removeEvilAttributes("$_POST[content]");
?>
