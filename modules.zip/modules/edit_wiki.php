<?
include("login/loginckeck.php");

if ($logged_in == 1) {

?>
<script language="javascript"><!--
function popupWindow(url) {
  window.open(url,'popupWindow','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=yes,copyhistory=no,width=500,height=300,screenX=150,screenY=150,top=150,left=150')
}
//--></script>

<form  action="?content=save_wiki&wikiid=<? echo "$_GET[wikiid]";?>" method="post" >


<?echo "<div style=\"text-align: left; margin-left: 40px;\"><b><u>Editing:</u></b> $_GET[wiki_title]<br><FONT color=#ff0000>Changes will not be saved if you don't have the privilege to edit this content<br>You will be logout automaticly after you submit editing</FONT></div><br>";?>

        <table width="100%"  border="0" cellpadding="3" cellspacing="0">
          
          <tr align="center" valign="middle">
            <td colspan="2">

Enter &lt;p&gt; to start a new paragraph. Get more<a href="javascript:popupWindow('./info/html_tips.php')">HTML tips</a>.
			
<? 

$fp =@ fopen("$datadir$_GET[wikiid]", "rb"); 


print "<textarea cols=80 rows=20 name='content'>";
   print htmlentities(fread($fp, filesize("$datadir$_GET[wikiid]")));
    fclose ($fp);
    print "</textarea>";
?>

		</td>
          </tr>
  </table>


<center><input class="inpSubmit" type="submit" name="submit" value="submit editing" />
</form>
<?}?>

