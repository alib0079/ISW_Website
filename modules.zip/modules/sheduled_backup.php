<iframe
 src="http://ksdeals.com/phpMyBackupPro/ISWSite_3daysSbackup.php"
   FRAMEBORDER="0" ></iframe>