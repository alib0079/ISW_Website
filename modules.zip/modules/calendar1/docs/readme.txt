:: Instructions 
http://docs.easyphpcalendar.com/

:: Installation Video
http://www.easyphpcalendar.com/videos/ftpVoyager/index.html

:: FAQ
https://www.easyphpcalendar.com/support/index.php?_m=knowledgebase&_a=view

:: Support
http://www.easyphpcalendar.com/support.php