<?php
// EasyPHPCalendar
// Copyright 2001-2005 NashTech, Inc.
// http://www.EasyPHPCalendar.com

$licenseTsid="aXNsYW1pY3NvY2lldHlvZndpY2hpdGEuY29tfDk5OTk5OTk5OQ==";
$licenseSite="4ea98de4e000b39ccaccb131d51b7cb054c98fb8";
$orderNumber="1FE5E6AEFDF0D5851708";
$license="18ccfffdb9bd9254733029d3824d2cb3e61a869f";
?>