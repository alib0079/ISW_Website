<!--head-->
<style type="text/css">
<!--
.tableListings {
	width: 680px;
	border: 1px solid #006699;
	margin: 0px;
	padding: 0px;
}
.tableEdit {
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #000000;
	width: 30px;
	text-align: center;
	vertical-align: middle;
	font-weight: normal;
	padding: 2px;
}
.tableDate {
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #000000;
	width: 170px;
	text-align: left;
	vertical-align: middle;
	font-weight: normal;
	padding: 2px;
}
.tableTitle {
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #004262;
	width: 480px;
	text-align: left;
	vertical-align: middle;
	font-weight: bold;
	padding: 2px;
}
.tableCategory {
	width: 8px;
}
.tableDescr {
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #383838;
	text-align: left;
	vertical-align: middle;
	font-weight: normal;
}
.tableTime {
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #295569;
	font-weight: normal;
}
.styleEdit {
	font-size: 9px;
	color: #CC0000;
}
.descrOverflow {
	text-overflow:ellipsis;
	overflow:hidden;
	white-space:nowrap;
	width: 450px;
}
-->
</style>
<table border="0" class="tableListings">
<!--head-->


<!--body-->
  <tr>
    <td width="20" bgcolor="#F7EEEE" class="tableEdit styleEdit"><a href="[edit]"><img src="../images/edit.gif" width="16" height="16" border="0"></a></td>
    <td bgcolor="#EBF2FA" class="tableDate">[date]<br>
    <span class="tableTime">[time]</span></td>
    <td bgcolor="#FFFDF2" class="tableCategory s2[category]">&nbsp;</td>
    <td bgcolor="#FFFDF2" class="tableTitle">[title]<br>
    <div class="descrOverflow"><span class="tableDescr">[descr]</span></div></td>
  </tr>
<!--body-->


<!--foot-->
</table>
<!--foot-->


<!--empty-->
<table border="0" class="tableListings tableTime">
  <tr>
    <td bgcolor="#FFFDF2"><center>There are no events to display for this time period.</center></td>
  </tr>
</table>
<!--empty-->